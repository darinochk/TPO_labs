/*! For license information please see letter-a28c1261e562efcc2722.bundle2.js.LICENSE.txt */
(self.webpackChunk_mail_octavius=self.webpackChunk_mail_octavius||[]).push([[6075],{28652:function(e,t,a){var r,n;r=[a(18440)],void 0===(n=function(e){return e.smartParse(e.__FEAST_TEMPLATE__`<div qa:id="attach-list">
	<fn:var name="attachCount" value="{attrs.models.length}" />
	<fn:var name="isSticky" value="{_this.isStickyEnabled()}"/>
	<fn:var name="isMobileAttaches" value="{_this.isMobileAttaches()}" />
	<fn:var name="showSaveToCloud" value="{!attrs['disable-save-to-cloud'] && _this.hasSaveToCloudAll()}" />
	<fn:var name="attachSafetyStatusLocator" value="attach-safety-status:{attrs['safety-status']}"/>
	<fn:var name="canSaveAttachesList" value="{_this.isSaveBtnEnabled()}" />

	<bem:mod name="hidden" test="!attrs.showAttachList"/>
	<bem:mod name="mobile" test="attrs.mobile"/>
	<bem:mod name="expanded" test="attrs.expanded && !attrs.mobile || attrs['preview-mode']"/>
	<bem:mod name="preview-mode" test="attrs['preview-mode']"/>

	<div>
		<div bem:elem="container"  ref="container">
			<div bem:elem="thumbs" ref="thumbs" qa:id="thumbs">
				<fn:for data="attrs.models" as="attachment" key="idx">
					<b:attach-thumb
						key="{attachment.id}"
						model="{attachment}"
						full="{!isMobileAttaches && attachCount <= _this.fullLimit()}"
						responsive="{!isMobileAttaches && attrs.mobile && attachCount === 1}"
						mobile-attaches="{isMobileAttaches}"
						save-to-cloud="{attrs['save-to-cloud'] && !attrs['disable-save-to-cloud'] && !attrs.mobile}"
						dark-mode="{attrs['dark-mode']}"
						remit:download="thumb-download"
						remit:cloud="thumb-cloud"
						remit:open="thumb-open"
						remit:thumb-item-rendered="thumb-rendered"
						remit:toggle-ics="toggle-ics"
						use:mediator:byname="attachments-manager"
					/>
				</fn:for>
			</div>

			<div
				fn:if="attrs.showmore && !attrs.mobile && !attrs.expanded && !attrs['preview-mode']"
				bem:elem="more"
				remit:click="expand"
			>
				<div
					bem:elem="expand"
					bem:mod="gradient"
				>
				</div>
				<div bem:elem="expand-container">
					<div
						bem:elem="expand-center"
						qa:id="more"
					>
						<div bem:elem="attach-icon"><b:ico name="attach"/></div>
						<div bem:elem="all">{i18n(\'все\')}</div>
						<div bem:elem="attach-count" qa:id="attach-count">{attachCount}</div>
					</div>
				</div>
			</div>
		</div>

		<div bem:elem="controls" qa:id="attach-list-controls">
			<div bem:elem="controls-element" fn:if="!isMobileAttaches">
				<bem:mod
					name="type"
					value="info"
					test="attrs.showAttachSafetyStatus && (attrs['attach-safety-status-position'] === 'start')"
				/>
				<span bem:elem="controls-element-count" qa:id="attach-count">
					<fn:value mod="fileCount">attachCount</fn:value>
				</span>

				<div
					bem:elem="controls-element-safety-status"
					qa:id="{attachSafetyStatusLocator}"
					fn:if="attrs.showAttachSafetyStatus && (attrs['attach-safety-status-position'] === 'start')"
					remit:click="attaches-status-click"
					remit:mouseenter="attaches-status-hover"
				>
					<!-- span обёрнут в div, чтобы span перестал быть flex-item-ом.
					Тогда ему можно применить правильное вертикальное выравнивание -->
					<div>
						<span bem:elem="controls-element-spacer">&bullet;&ThinSpace;</span>
					</div>
					<b:react-async
						component="AttachSafetyStatus"
						safetyStatus="{attrs['safety-status']}"
						hasBackground="{attrs['has-attach-safety-status-background']}"
						attachCount="{attachCount}"
						mobile="{attrs.mobile}"
					/>
				</div>
			</div>

			<div
				bem:elem="controls-element"
				fn:if="canSaveAttachesList"
			>
				<a
						bem:elem="controls-element-download"
						data-name="{attachCount === 1 ? 'download-link' : null}"
						href="{attrs['download-link']}"
						qa:id="download-link"
						remit:click="download-link">
					<bem:mod name="disabled" test="attrs['offline-mode']"/>
					{_this.getDownloadTitle()}
				</a>
				<span
					bem:elem="controls-element-size"
					fn:if="attrs['total-size']">
					(<fn:value mod="fileSize">attrs['total-size']</fn:value>)
				</span>
			</div>

			<div bem:elem="controls-element" fn:if="showSaveToCloud">
				<span
						bem:elem="controls-element-cloud"
						remit:click="attach-list-cloud"
						qa:id="save-to-cloud-link"
						event:details="attrs.models">
					<bem:mod name="disabled" test="attrs['offline-mode']"/>
					<fn:if test="attrs.mobile && !attrs['enable-b2b-cloud-name']">{i18n(\'В Облако\')}</fn:if>
					<fn:if test="attrs.mobile && attrs['enable-b2b-cloud-name']">{i18n(\'В Диск\')}</fn:if>
					<fn:if test="!attrs.mobile && !attrs['enable-b2b-cloud-name']">{i18n(\'Сохранить в Облако\')}</fn:if>
					<fn:if test="!attrs.mobile && attrs['enable-b2b-cloud-name']">{i18n(\'Сохранить в Диск\')}</fn:if>
				</span>
			</div>

			<div bem:elem="controls-element">
				<div
					bem:elem="controls-element-safety-status"
					qa:id="{attachSafetyStatusLocator}"
					fn:if="attrs.showAttachSafetyStatus && (isMobileAttaches || attrs['attach-safety-status-position'] === 'end')"
					remit:click="attaches-status-click"
					remit:mouseenter="attaches-status-hover"
				>
					<b:react-async
						component="AttachSafetyStatus"
						safetyStatus="{attrs['safety-status']}"
						hasBackground="{attrs['has-attach-safety-status-background']}"
						attachCount="{attachCount}"
						mobile="{attrs.mobile}"
					/>
				</div>
			</div>

		</div>
	</div>

	<div>
		<div
			fn:if="!attrs.mobile && attrs.expanded && !attrs['preview-mode']"
			bem:elem="less"
			remit:click="collapse"
			qa:id="less"
		>
			<bem:mod name="sticky" test="isSticky"/>
			<div bem:elem="collapse-container">
				<div bem:elem="collapse-center">
					<b:ico name="arrow-up"/>
				</div>
			</div>
		</div>
	</div>
</div>
`,"./app/ui-block/attach-list/attach-list.html")}.apply(t,r))||(e.exports=n)},53526:function(e,t,a){var r,n;r=[a(18440)],void 0===(n=function(e){return e.smartParse(e.__FEAST_TEMPLATE__`<div qa:id="{_this.getQaId()}">
	<fn:var name="hasNoTopbar" value="{_this.hasNoTopbar()}"/>
	<fn:var name="canOpenInCloud" value="{_this.canOpenInCloud()}"/>
	<fn:var name="canSaveToCloud" value="{_this.canSaveToCloud()}"/>
	<fn:var name="isMobileAttaches" value="{attrs['mobile-attaches']}" />
	<fn:var name="isSquare" value="{!isMobileAttaches && !attrs.responsive && !attrs.full && hasNoTopbar}"/>
	<fn:var name="isInfected" value="{_this.isInfected()}" />
	<fn:var name="attachWarningTooltip" value="{attrs['attach-warning-tooltip'] && isInfected}" />

	<fn:attr name="title" value="{attrs.mainTitle}"/>

	<bem:mod name="full" test="attrs.full"/>
	<bem:mod name="responsive" test="attrs.responsive"/>

	<bem:mod name="top-free" test="hasNoTopbar"/>
	<bem:mod name="normal" test="!isMobileAttaches && !attrs.responsive && !attrs.full && !hasNoTopbar"/>
	<bem:mod name="square" test="isSquare"/>
	<bem:mod name="hide-link" test="isSquare"/>

	<div bem:elem="thumb-elem" qa:id="{_this.getParams().filename.name}">
		<b:react-async
			component="AttachThumb"
			componentClass="{_this.getComponent()}"
			title="{_this.getParams().filename.name}"
			preview="{_this.getThumbImage()}"
			fullPreview="{_this.isImage() && !attachWarningTooltip}"
			downloadBtnTitle="{_this.getTitles().downloadTitle}"
			uploadBtnTitle="{_this.getTitles().uploadTitle}"
			downloadBtnTooltip="{_this.getTitles().downloadTooltip}"
			uploadBtnTooltip="{_this.getTitles().uploadTooltip}"
			onDownloadClick="{_this.onDownload}"
			disableCloudUpload="{!attrs['save-to-cloud'] || !canSaveToCloud}"
			disableOpenInCloud="{!canOpenInCloud}"
			onCloudUploadClick="{_this.onCloudUpload}"
			onOpenClick="{_this.onOpen}"
			testId="thumb"
			iconType="{_this.getIcon()}"
			isLink="{_this.isBigAttach()}"
			isCloudAttach="{_this.isCloud()}"
			linkTitle="{_this.getTitles().mainTitle}"
			darkMode="{attrs['dark-mode']}"
			link="{_this.getDownloadUrl()}"
			attachWarningTooltip="{attachWarningTooltip}"
		/>
	</div>

</div>
`,"./app/ui-block/attach-thumb/attach-thumb.html")}.apply(t,r))||(e.exports=n)},18156:function(e,t,a){var r,n;r=[a(18440)],void 0===(n=function(e){return e.smartParse(e.__FEAST_TEMPLATE__`<div qa:id="{attrs['dates-metadata'] ? 'calendar:metadata:create' : 'calendar:create'}">
    <b:button2
        remit:click="calendar:create"
        event:details="{model: attrs.model, createContent:'web_email_letter_footer'}"
        radar-id="{_this._getRadarPrefix()}"
        text="{!attrs['sticky-reduce-one-text'] && _this._getCalendarButtonText()}"
		ico="calendar-month"
        base
        pure
        touch="{attrs.touch}"
        model="{attrs.model}"
        disabled="{attrs['disable-edit']}"
        centered="{attrs['sticky-reduce-one-text']}"
    />
</div>
`,"./app/ui-block/calendar-button/calendar-button.html")}.apply(t,r))||(e.exports=n)},6889:function(e,t,a){var r,n;r=[a(18440)],void 0===(n=function(e){return e.smartParse(e.__FEAST_TEMPLATE__`<div/>
`,"./app/ui-block/letter-body-amp/letter-body-amp.html")}.apply(t,r))||(e.exports=n)},88285:function(e,t,a){var r,n;r=[a(18440)],void 0===(n=function(e){return e.smartParse(e.__FEAST_TEMPLATE__`<div qa:id="letter-body">
	<!-- Переменные -->
	<fn:var
		name="hasQuotes"
		value="{!!(attrs['quotes-raw'] || attrs['quotes-formatted'].length)}"
	/>

	<fn:var
		name="bodyRaw"
		value="{attrs['body-raw']}"
	/>

	<fn:var
		name="darkMode"
		value="{attrs['dark-mode']}"
	/>

	<fn:var
		name="message"
		value="{attrs['message']}"
	/>

	<fn:var
		name="search"
		value="{attrs['search']}"
	/>

	<!-- Модификаторы -->
	<bem:mod name="mobile" test="attrs.mobile"/>

	<bem:mod
		name="formatted-quotes"
		test="!attrs['quotes-mode-raw'] && attrs['quotes-formatted'].length"
	/>

	<bem:mod
		name="raw-quotes"
		test="attrs['quotes-mode-raw'] && attrs['quotes-raw']"
	/>

	<bem:mod
		name="quotes"
		test="hasQuotes"
	/>

	<bem:mod name="dark-mode" test="darkMode"/>
	<bem:mod name="enable-min-width" test="attrs['enable-min-width']"/>

	<!-- Содержимое -->
	<div bem:elem="body" qa:id="body">
		<bem:mod name="no-scroll" test="attrs['preview-mode']"/>
		<div bem:elem="body-wrapper" ref="body">
			<div bem:elem="body-content" tabindex="-1" ref="js-body">
				<!-- отрисовка письма всего один раз и навсегда -->
				<b:html-parser
					id="body-parser"
					fn:if="bodyRaw"
					content="{bodyRaw}"
					darkosha="{_this.getOrCreateDarkosha()}"
					message="{message}"
					dark-mode="{darkMode}"
					remit:zoom="letter:zoom"

					analyticsIndex="{attrs.analyticsIndex}"
				/>
			</div>
		</div>
	</div>

	<!-- Есть цитаты? -->
	<fn:if test="hasQuotes">
		<!-- Тоглер сворачивания цитат -->
		<fn:if test="attrs.collapsable">
			<div bem:elem="badge">
				<b:button2
					badge
					secondary
					ico="navigation:more"
					remit:click="blockquote:toggle"
					qa:id="blockquote-toggler"
					centered
				/>
			</div>
		</fn:if>

		<!-- Когда свернуть нельзя, просто подписываем -->
		<fn:if test="!attrs.collapsable">
			<div
				bem:elem="title"
				qa:id="blockquote-title"
			>{i18n(\'вся переписка\')}</div>
		</fn:if>

		<!-- Тело цитат -->
		<div
			ref="blockquotes"
			bem:elem="blockquotes"
			qa:id="blockquotes">
			<!-- Если цитаты развернуты -->
			<fn:if test="!attrs.collapsable || !_this.isCollapsed()">
				<!-- Старые цитаты -->
				<fn:if test="attrs['quotes-mode-raw']">
					<div bem:elem="blockquotes-raw" qa:id="raw">
						<b:html-parser
							id="quote-parser"
							content="{attrs['quotes-raw']}"
							darkosha="{_this.getOrCreateDarkosha()}"
							message="{message}"
						/>
					</div>
				</fn:if>

				<!-- Новые цитаты -->
				<fn:if test="!attrs['quotes-mode-raw']">
					<fn:for data="attrs['quotes-formatted']" as="blockquote" key="key">
						<b:letter-blockquote
							key="{key}"
							index="{key}"
							blockquote="{blockquote}"
							ponymode="{attrs.ponymode}"
							message="{message}"
							search="{search}"
							darkosha="{_this.getOrCreateDarkosha()}"
							remit:blockquote-zoom="letter:zoom"
							use:mediator="user-info"
						/>
					</fn:for>
				</fn:if>
			</fn:if>
		</div>
	</fn:if>
</div>
`,"./app/ui-block/letter-body/letter-body.html")}.apply(t,r))||(e.exports=n)},96284:function(e,t,a){var r,n;r=[a(18440)],void 0===(n=function(e){return e.smartParse(e.__FEAST_TEMPLATE__`<div qa:id="letter-calendar">
	<fn:var
		name="darkMode"
		value="{attrs['dark-mode']}"
	/>

	<fn:value output="raw">attrs.html</fn:value>
</div>
`,"./app/ui-block/letter-calendar/letter-calendar.html")}.apply(t,r))||(e.exports=n)},43148:function(e,t,a){var r,n;r=[a(18440)],void 0===(n=function(e){return e.smartParse(e.__FEAST_TEMPLATE__`<div
	qa:id="category:{attrs.name}"
	promo:id="{attrs.promoid || ''}"
>
	<bem:mod name="{attrs.name}"/>

	<b:badge
		transparent="{attrs.flat}"
		text="{_this.getText()}"
		title="{_this.getTitle()}"
		ico="{_this.getIco()}"
		short="{attrs.short}"
		size="{attrs.size || 'l'}"/>
</div>
`,"./app/ui-block/letter-category/letter-category.html")}.apply(t,r))||(e.exports=n)},62593:function(e,t,a){var r,n;r=[a(18440)],void 0===(n=function(e){return e.smartParse(e.__FEAST_TEMPLATE__`<div qa:id="confirm-receipt">

	<bem:mod name="mobile" test="attrs.mobile"/>

	<div bem:elem="icon">
		<b:ico name="categories:mail" size="s" />
	</div>

	<div bem:elem="icon-touch">
		<div bem:elem="icon-touch-wrapper">
			<b:ico name="categories:mail" size="s" />
		</div>
	</div>

	<div bem:elem="wrapper">
		<div bem:elem="info">
			{i18n(\'Отправитель письма запросил подтверждение о прочтении.\')}
			<b:link
				fn:if="!attrs['hide-help-link']"
				href="{attrs['help-link']}"
				text="{i18n(\'Что это?\')}"
				target="_blank"
				secondary
				qa:id="help-link"
			/>
		</div>

		<div fn:if="!attrs.mobile" bem:elem="confirm">
			<b:button-link
				remit:click="confirm"
				text="{i18n(\'Подтвердить, что прочитано\')}"
				qa:id="confirm-button"
			/>
		</div>

		<div fn:if="attrs.mobile" bem:elem="confirm-touch">
			<b:button2
					remit:click="confirm"
					text="{i18n(\'Подтвердить прочтение\')}"
					primary
					nowrap
					text-overflow
					qa:id="confirm-button"
			/>
		</div>
	</div>
</div>
`,"./app/ui-block/letter-confirm-receipt/letter-confirm-receipt.html")}.apply(t,r))||(e.exports=n)},7005:function(e,t,a){var r,n;r=[a(18440)],void 0===(n=function(e){return e.smartParse(e.__FEAST_TEMPLATE__`<div>
    <fn:if test="attrs.showSkeleton">
        <div ref="skeleton" class="skeleton">
            <b:react-async
                component="LetterMetaSkeleton"
                darkMode="{attrs['dark-mode']}"
                animateContent="{attrs['start-animation']}"
                onMount="{_this.onSkeletonMount}"
            />
        </div>
    </fn:if>
    <div ref="container" class="letter-meta-container">
        <fn:add-class name="letter-meta-container-with-skeleton" test="attrs.showSkeleton"/>
    </div>
</div>
`,"./app/ui-block/letter-meta/letter-meta.html")}.apply(t,r))||(e.exports=n)},48254:function(e,t,a){var r,n;r=[a(18440)],void 0===(n=function(e){return e.smartParse(e.__FEAST_TEMPLATE__`<div qa:id="letter-tooltip:{attrs.type}">
	<!-- Переменные -->
	<fn:var name="disabled" value="{attrs.loading}"/>
	<fn:var name="ponymode" value="{attrs.ponymode}"/>

	<!-- В мобильном Октавиусе переносим кнопку вниз FMAIL-21900 -->
	<fn:var name="webviewMobileMode" value="{_this.isWebviewMobileMode()}" />

	<!-- Модификаторы -->
	<bem:mod name="pony-mode" test="ponymode" />
	<bem:mod name="disabled" test="disabled" />
	<bem:mod name="mobile" test="attrs.mobile"/>

	<div bem:elem="wrapper">
		<div bem:elem="title">
			<fn:value>attrs['title-text']</fn:value>
		</div>

		<!-- Правый край -->
		<div bem:elem="right">
			<fn:if test="!webviewMobileMode">
				<!-- Кнопка действия (ссылка) -->
				<div bem:elem="action">
					<b:button-link
						qa:id="action"
						remit:click="action"
						disabled="{disabled}"
						ponymode="{ponymode}"
						text="{attrs['action-text']}"
					/>
				</div>
			</fn:if>

			<!-- Кнопка закрыть (крестик) -->
			<div bem:elem="close">
				<b:button2
					qa:id="close"
					remit:click="close"

					compact="{attrs.ponymode}"
					ico="actions:close"
					secondary
					short
					size="s"
					centered
				/>
			</div>
		</div>
	</div>

	<fn:if test="webviewMobileMode && !!attrs['action-text']">
		<div bem:elem="wrapper">
			<div bem:elem="title">
				<!-- Кнопка действия (ссылка) -->
				<div bem:elem="action">
					<b:button-link
						qa:id="action"
						remit:click="action"
						disabled="{disabled}"
						ponymode="{ponymode}"
						text="{attrs['action-text']}"
					/>
				</div>
			</div>
		</div>
	</fn:if>
</div>
`,"./app/ui-block/letter-tooltip/letter-tooltip.html")}.apply(t,r))||(e.exports=n)},75320:function(e,t,a){var r,n;r=[a(18440)],void 0===(n=function(e){return e.smartParse(e.__FEAST_TEMPLATE__`<div>
	<!-- Переменные -->
	<fn:var name="useReactMigrLetterBody" value="{_this.useReactMigrLetterBody()}" />
	<fn:var name="message" value="{attrs.model}"/>
	<fn:var name="search" value="{attrs.search}"/>

	<fn:var name="messageFolder" value="{message.getFolder()}"/>
	<fn:var name="search" value="{attrs.search}"/>
	<fn:var name="hasAttach" value="{attrs.model.is('attaches.list.length') && _this.isEnableAttach()}"/>
	<fn:var name="hasReplyAll" value="{_this.hasReplyAll(message)}"/>

	<fn:var name="draftReply" value="{message.get('drafts.reply')}"/>
	<fn:var name="draftReplyAll" value="{message.get('drafts.replyall')}"/>
	<fn:var name="draftForward" value="{message.get('drafts.forward')}"/>

	<fn:var name="folders" value="{attrs.folders}"/>
	<fn:var name="ponyMode" value="{attrs.ponymode}"/>

	<!-- Есть ли AMP-контент? -->
	<fn:var name="hasAmp" value="{_this.isAMPLetter()}"/>

	<!-- Есть ли ошибки в AMP-письме? -->
	<fn:var name="hasAmpErrors" value="{attrs['amp-error']}"/>

	<fn:var name="letterMetaType" value="{_this.getLetterMetaHeaderType(message)}" />
	<fn:var name="showPhishingDie" value="{message.get('flags.maybe_phishing')}" />

	<fn:var name="enableFakeCreateTodo" value="{_this.isShowFakeCreateTodo()}" />
	<fn:var name="showAttachList" value="{attrs.showAttachList}" />

	<fn:var name="showNotesBtnForMailings" value="{attrs['enable-notes-button'] && _this._showUnsubscribeButton()}" />
	<fn:var name="showNotesBtnForLetterToMyself" value="{attrs['enable-notes-button'] && attrs.model.attributes.auth_results.email === attrs['current-user'].getEmail()}" />
	<fn:var name="showNotesBtnForMailingsOrLetterToMyself" value="{showNotesBtnForMailings || showNotesBtnForLetterToMyself}" />

	<!-- Модификаторы -->
	<bem:mod name="priority" value="{attrs.model.get('priority')}"/>
	<bem:mod name="unread" value="{attrs.model.get('flags.unread')}"/>
	<bem:mod name="attach" value="{hasAttach}"/>
	<bem:mod name="single" test="attrs.single"/>
	<bem:mod name="first" test="attrs.first"/>
	<bem:mod name="last" test="attrs.last"/>

	<bem:mod name="touch" test="attrs.touch"/>
	<bem:mod name="compact" test="attrs.compact"/>
	<bem:mod name="fluid" test="!attrs.compact"/>
	<bem:mod name="sticky" test="attrs.sticky"/>
	<bem:mod name="native-sticky" test="attrs['native-sticky']"/>

	<bem:mod name="hover-support" test="attrs['hover-support']" />
	<bem:mod name="expanded-next" test="attrs['expanded-next']" />

	<bem:mod name="light-mode" test="!_this.isDarkMode()" />

	<bem:mod name="mobile" test="attrs.mobile" />

	<fn:var name="useSharingDropdown" value="{_this.useSharingDropdown()}" />

	<!-- Иконка AMP -->
	<fn:match name="amp-icon">
		<span bem:elem="amp-icon" qa:id="amp-icon">
			<b:ico name="status:breaking" size="s"/>

			<bem:mod name="error" test="hasAmpErrors"/>

			<fn:attr name="title" value="{i18n(\'Это письмо поддерживает динамический контент\')}" fn:if="!hasAmpErrors"/>
			<fn:attr name="title" value="{i18n(\'При отображении динамического контента письма возникли ошибки\')}" fn:if="hasAmpErrors"/>
		</span>
	</fn:match>

	<!-- FMAIL-6259: плашка о возможном фишинге -->
	<!-- FMAIL-11501: Плашка о протухаемых аттачах -->
	<div bem:elem="letter-meta-container" fn:if="letterMetaType">
		<bem:mod name="phishing" test="showPhishingDie" />
		<bem:mod name="mobile" test="attrs.mobile" />
		<b:letter-meta
				type="{letterMetaType}"
				model="{message}"
				ponymode="{attrs.ponymode}"
				remit:attaches-cloud-save="attaches:cloud:all"
				use:mediator:byname="letters-actions pony-mode"
		/>
	</div>

	<!-- Поле "Кому" -->
	<fn:match name="correspondents" args="contacts, dir, limit, mode, isMultiline">
		<fn:var name="contactList" value="{limit ? contacts.slice(0, limit) : contacts}"/>

		<fn:for data="contactList" as="contact" key="contactKey">
			<fn:var name="isCurrent" value="{contact.email == attrs['current-user'].getEmail()}"/>
			<fn:var name="isLast" value="{contactKey + 1 === contactList.length}"/>
			<b:letter-contact
				folder="{messageFolder}"
				key="{'contact-' + contactKey}"
				remit:click.prevent.stop="contact:click"
				event:details="contact"
				use:mediator:byname="contact-selection"
				contact="{contact}"
				dir="{dir}"
				isCurrent="{isCurrent}"
				dangerous="{dir === 'from' && _this.isProbablyPhishing()}"
				pony-mode="{ponyMode}"
				searchWords="{search ? search.getSearchCorrespondentsAndQuery(_this.getCorrespondentDirection(dir)) || [] : []}"
				isLast="{isLast}"
				mode="{mode}"
				isMultiline="{isMultiline}"
			/>
		</fn:for>
	</fn:match>

	<!-- Дропдаун меток -->
	<fn:match name="add-tag">
		<div bem:elem="tags">
			<b:dropdown
					fn:if="!attrs['preview-mode']"
					title="{i18n(\'Добавить метку\')}"
					ico="status:tag"
					qa:id="add-tag"
					secondary
					short
					expand-left
					touch="{attrs.touch && !attrs.mobile}"
			>
				<fn:match name="items">
					<b:react-async
							component="TagsPicker"
							model="{attrs.model}"
							tags="{attrs.model.get('flags.tags')}"
							xrayFrom="message_icon_menu"
					/>
				</fn:match>
			</b:dropdown>
		</div>
	</fn:match>

	<!-- Пометка прочитанным -->
	<fn:match name="status-unread">
		<div bem:elem="unread" qa:id="unread">
			<bem:mod name="plain" test="!(message.is('flags.forward') || message.is('flags.reply'))"/>
			<b:letter-status2
					remit:button-click.prevent="togglestatus:unread"
					event:details="{model: attrs.model, state: message.is('flags.unread')}"

					disabled="{attrs['disable-edit']}"
					name="unread"
					compact="{!attrs.compact}"
					small="{attrs.compact}"
					forward="{message.is('flags.forward')}"
					reply="{message.is('flags.reply')}"
					state="{message.is('flags.unread')}"/>
		</div>
	</fn:match>

	<!-- Переключение тёмного/светлого режима -->
	<fn:match name="dark-mode-toggle">
		<div bem:elem="dark-mode-toggle" qa:id="dark-mode-toggle">
			<b:letter-status2
				fn:if="!attrs['preview-mode']"
				remit:button-click.prevent="dark-mode:toggle"
				name="dark-mode"
				state="{attrs['dark-mode-enabled']}"
			/>
		</div>
	</fn:match>

	<fn:match name="print">
		<div bem:elem="print" qa:id="print-btn" on-click="_this._stopPropagationDuringOffline(evt)">
			<b:button2
					event:details="{model: attrs.model}"
					remit:click.prevent="print"
					radar-id="head-print"
					title="{i18n(\'Распечатать\')}"
					ico="actions:print"
					base
					secondary
					touch="{attrs.touch}"
					model="{attrs.model}"
					disabled="{!_this.isEnablePrint()}"
					centered
			/>
		</div>
	</fn:match>

	<!-- Пометка важным -->
	<fn:match name="status-flag">
		<div bem:elem="flag" qa:id="flag">
			<b:letter-status2
					fn:if="!attrs['preview-mode']"
					remit:button-click.prevent="togglestatus:flagged"
					event:details="{model: attrs.model, state: message.is('flags.flagged')}"
					disabled="{!_this.isEnableMark()}"
					name="flagged"
					state="{message.is('flags.flagged')}"/>
		</div>
	</fn:match>

	<!-- Предложить звонок -->
	<fn:match name="invite-call">
		<div bem:elem="flag" qa:id="calls:invite" promo:id="letter-head-calls-button">
			<b:button2
				fn:if="!attrs['preview-mode']"
				remit:click.prevent="calls:invite"
				event:details="attrs.model"
				radar-id="head-call"
				title="{i18n(\'Предложить звонок\')}"
				ico="categories:camera"
				base
				secondary
				touch="{attrs.touch && !attrs.mobile}"
				model="{attrs.model}"
				disabled="{!_this.isEnableCall()}"
				centered
			/>
		</div>
	</fn:match>

	<!-- Поделиться письмом -->
	<fn:match name="share-letter">
		<div bem:elem="flag" qa:id="letter:share" promo:id="letter-head-share-button" on-click="_this._stopPropagationDuringOffline(evt)">
			<fn:choose>
				<fn:when test="useSharingDropdown">
					<b:react-async
							component="LetterShareDropdown"
							componentClass="{_this.lazyLetterShareDropdown()}"
							model="{attrs.model}"
					/>
				</fn:when>
				<fn:otherwise>
					<b:button2
						fn:if="!attrs['preview-mode']"
						remit:click.prevent="letter:share"
						event:details="attrs.model"
						radar-id="head-share"
						title="{i18n(\'Поделиться письмом\')}"
						ico="{_this._getHeadShareIcon()}"
						base
						secondary
						touch="{attrs.touch && !attrs.mobile}"
						model="{attrs.model}"
						disabled="{!_this.isEnableShare()}"
						centered
					/>
				</fn:otherwise>
			</fn:choose>
		</div>
	</fn:match>

	<!-- Создать событие -->
	<fn:match name="calendar-create">
		<div bem:elem="flag" qa:id="calendar:create" promo:id="letter-head-calendar-button">
			<b:button2
				fn:if="!attrs['preview-mode']"
				remit:click.prevent="calendar:create"
				event:details="{model:attrs.model, createContent:'web_email_letter_header'}"
				radar-id="head-calendar"
				title="{i18n(\'Создать событие\')}"
				ico="calendar-month"
				base
				secondary
				touch="{attrs.touch && !attrs.mobile}"
				model="{attrs.model}"
				disabled="{attrs['disable-edit']}"
				centered
			/>
		</div>
	</fn:match>

	<!-- Создать чат -->
	<fn:match name="chat-create">
		<div bem:elem="flag" qa:id="chat:create">
			<b:button2
				fn:if="!_this.isShareTake() && _this.isShowCreateChat()"
				remit:click.prevent="chat:create"
				event:details="{model:attrs.model}"
				title="{i18n(\'Создать чат\')}"
				ico="message"
				base
				secondary
				touch="{attrs.touch && !attrs.mobile}"
				model="{attrs.model}"
				disabled="{attrs['disable-edit'] || attrs['offline-mode']}"
				centered
			/>
		</div>
	</fn:match>

	<!-- Аватарка -->
	<fn:match name="avatar-wrap">
		<fn:var name="contact" value="{message.get('correspondents.from.0')}"/>
		<div bem:elem="avatar-wrap">
			<fn:apply-match name="status-unread" fn:if="!attrs.compact"/>
			<div bem:elem="avatar"
				 qa:id="avatar"
				 remit:click.prevent.stop="clickavatar"
				 event:details="contact">
				<b:notification-badge
						show="{attrs.isOnline}"
						colorMode="success"
						bottom="4"
						right="4"
						test-id="{attrs.isOnline && 'online-badge'}"
				>
					<fn:match name="content" bem:block="widget">
								<b:avatar
										size="{attrs.compact ? 'm' : 's'}"
										src="{message.get('correspondents.from.0.avatars.default')}"
										touch="{attrs.touch}"/>
					</fn:match>
				</b:notification-badge>
			</div>
			<fn:apply-match name="status-unread" fn:if="attrs.compact"/>
		</div>
	</fn:match>

	<!-- Бейдж папки -->
	<fn:match name="folder">
		<fn:if test="message.isHigh()">
			<fn:var name="name" value="important"/>
		</fn:if>

		<fn:if test="!attrs['disable-category'] && message.get('transaction_category') && !messageFolder.isSpam()">
			<fn:var name="name" value="{message.get('transaction_category')}"/>
		</fn:if>

		<fn:if test="attrs.showfolder">
			<fn:var name="text" value="{messageFolder.get('name')}"/>
		</fn:if>

		<div bem:elem="folder" bem:mod="{!!(text || name)}">
			<b:letter-category
				short="{!text}"
				name="{name}"
				text="{text}"
				size="l"/>
		</div>
	</fn:match>

	<fn:match name="revoke-status">
		<div bem:elem="revoke-status">
			<b:react-async
				component="ListLetterRevokeStatus"
				isRevoked="{message.is('flags.was_recalled')}"
				isReplaced="{message.is('flags.was_replaced')}"
			/>
		</div>
	</fn:match>

	<!-- Время отправки письма -->
	<fn:match name="date">
		<div bem:elem="date" qa:id="date">
			<fn:value mod="getLocaleDateFull">message.get('date')</fn:value>
		</div>
	</fn:match>

	<!-- Поле Кому -->
	<fn:match name="recipients">
		<!-- стандартный свёрнутый вид -->
		<div bem:elem="recipients" bem:mod="short" qa:id="recipients:short"
			 fn:if="!attrs['details-expanded'] && !attrs['show-extended-correspondents-list']">
			<fn:var name="recipients" value="{_this.getMessageCorrespondents()}"/>
			<fn:var name="showNames" value="{recipients.length > 3 ? 2 : recipients.length}"/>
			<fn:var name="moreCount" value="{recipients.length - showNames}"/>

			<span bem:elem="recipient-type">{_this.texts.to}:</span><fn:apply-match name="correspondents" args="recipients, 'to', showNames"/>
			<a bem:elem="recipients-short-expand" fn:if="recipients.length > 3" remit:click.prevent="details:expand"
				qa:id="recipients:short-expand">{i18n(\'и ещё\')}
				<fn:value fn:if="attrs.touch">moreCount</fn:value>
				<fn:value fn:if="!attrs.touch" mod="correspondentsCount">moreCount</fn:value>
			</a>
		</div>

		<!-- расширенный свёрнутый вид show-extended-correspondents-list -->
		<div bem:elem="recipients" bem:mod="short" qa:id="recipients:short"
			 fn:if="!attrs['details-expanded'] && attrs['show-extended-correspondents-list']">
			<fn:var name="allRecipients" value="{_this.getMessageCorrespondents()}"/>
			<fn:var name="recipientsData" value="{attrs.recipientsData}"/>
			<fn:var name="to" value="{recipientsData.showTo}"/>
			<fn:var name="cc" value="{recipientsData.showCc}"/>
			<fn:var name="moreCountText" value="{recipientsData.moreCountText}"/>

			<span bem:elem="recipient-type" fn:if="to.length > 0 || cc.length === 0">
				<bem:mod name="extended-correspondents-list"/>
				<bem:mod name="secondary" test="cc.length === 0"/>
				{_this.texts.to}:</span><fn:apply-match name="correspondents" args="to, 'to', '', '', true"/>

			<span fn:if="cc.length > 0">
				<span bem:elem="recipient-type">
					<bem:mod name="extended-correspondents-list"/>
					{_this.texts.cc}:</span><fn:apply-match name="correspondents" args="cc, 'cc', '', '', true"/>
			</span>

			<a bem:elem="recipients-short-expand" fn:if="moreCountText.length > 0" remit:click.prevent="details:expand"
				qa:id="recipients:short-expand">{moreCountText}
			</a>
		</div>

		<!-- развёрнутый вид -->
		<div bem:elem="recipients" qa:id="recipients:expanded" fn:if="attrs['details-expanded']">
   			<bem:mod name="expanded" test="!attrs['show-extended-correspondents-list']"/>
		<!-- remit:click.prevent="details:collapse" для поля выше ^ -->
			<fn:var name="hasBcc" value="{attrs.model.get('correspondents.bcc.length')}"/>
			<fn:var name="hasCc" value="{attrs.model.get('correspondents.cc.length')}"/>

			<div bem:elem="header-details-recipient">
				<span bem:elem="correspondents-container">
					<bem:mod name="expanded" test="attrs['show-extended-correspondents-list']"/>
					<span bem:elem="recipient-type">
						<bem:mod name="extended-correspondents-list" test="attrs['show-extended-correspondents-list']"/>
						{_this.texts.to}:</span><fn:apply-match name="correspondents" args="message.get('correspondents.to'), 'to', '', '', attrs['show-extended-correspondents-list']"/>
				</span>
				<a bem:elem="recipients-short-collapse" remit:click.prevent="details:collapse" fn:if="!hasCc && !hasBcc"
				   qa:id="recipients:short-collapse">
				   <bem:mod name="newline" test="attrs['show-extended-correspondents-list']"/>{_this.texts.hide}
				</a>
			</div>

			<div bem:elem="header-details-recipient" fn:if="hasCc">
				<span bem:elem="correspondents-container">
					<bem:mod name="expanded" test="attrs['show-extended-correspondents-list']"/>
					<span bem:elem="recipient-type">
						<bem:mod name="extended-correspondents-list" test="attrs['show-extended-correspondents-list']"/>
						{_this.texts.cc}:</span><fn:apply-match name="correspondents" args="message.get('correspondents.cc'), 'cc', '', '', attrs['show-extended-correspondents-list']"/>
				</span>
				<a bem:elem="recipients-short-collapse" remit:click.prevent="details:collapse" fn:if="!hasBcc"
				   qa:id="recipients:short-collapse">
				   <bem:mod name="newline" test="attrs['show-extended-correspondents-list']"/>{_this.texts.hide}
				</a>
			</div>

			<div bem:elem="header-details-recipient" fn:if="hasBcc">
				<span bem:elem="correspondents-container">
					<bem:mod name="expanded" test="attrs['show-extended-correspondents-list']"/>
					<span bem:elem="recipient-type">
						<bem:mod name="extended-correspondents-list" test="attrs['show-extended-correspondents-list']"/>
						{_this.texts.bcc}:</span><fn:apply-match name="correspondents" args="message.get('correspondents.bcc'), 'bcc', '', '', attrs['show-extended-correspondents-list']"/>
				</span>
				<a bem:elem="recipients-short-collapse" remit:click.prevent="details:collapse"
				   qa:id="recipients:short-collapse">
				   <bem:mod name="newline" test="attrs['show-extended-correspondents-list']"/>{_this.texts.hide}
				</a>
			</div>
		</div>
	</fn:match>

	<!-- Меню Ещё -->
	<fn:match name="more">
		<fn:if test="!attrs.mobile">
			<div bem:elem="more" qa:id="more">
				<b:dropdown-actions
						fn:if="!attrs.readonly"
						text="{i18n(\'Ещё\')}"
						ico="more-hor"
						secondary
						expand-left

						disable-edit="{attrs['disable-edit']}"
						offline-mode="{attrs['offline-mode']}"

						model="{message}"
						parentThread="{attrs.parentThread}"
						folders="{folders}"
						folder="{messageFolder}"
						read="{message.is('flags.unread') ? true : null}"
						unread="{!message.is('flags.unread') ? true : null}"
						flag="{!message.is('flags.flagged') ? true : null}"
						unflag="{message.is('flags.flagged') ? true : null}"
						archive="{!messageFolder.isArchive()}"
						spam="{_this._showSpam()}"
						selectedLettersIds="{[message.get('id')]}"
						unsubscribe="{_this._showUnsubscribeInMoreMenu()}"
						unspam="{messageFolder.isSpam()}"
						dark-mode="{_this.isDarkMode()}"
						metathreads="{attrs.metathreads}"

						create-event="{_this._showDropdownCalendarButton()}"
						create-filter="{_this._showFilterButton()}"
						category-feedback="{attrs['category-feedback'] && !attrs.touch}"
						translate="{!attrs['disable-translate']}"

						more
						remove
						move
						readletter
						print
						report-suspicious-email="{_this._showReportSuspiciousEmail()}"
						reply="{hasReplyAll?'all':true}"
						radar-id="more"
						use:mediator:byname="layout-manager letters-selection unsubscribe-actions"
				/>
			</div>
		</fn:if>
	</fn:match>

	<!-- Отписка из письма -->
	<fn:match name="unsubscribe">
		<div bem:elem="footer-button" qa:id="unsubscribe">
			<fn:var name="letterId" value="{message.get('id')}"/>
			<fn:var name="senderFrom" value="{message.get('correspondents.from')[0].email}"/>
			<b:unsubscribe
					use:mediator:byname="unsubscribe-actions"
					touch="{attrs.touch}"
					senderFrom="{senderFrom}"
					letterId="{letterId}"
					position-right
					short="{hasReplyAll}"
					promoId="octavius-tooltip-unsubscribe-button"
					disabled="{attrs['offline-mode']}"
			/>
		</div>
	</fn:match>

	<!-- Шапка письма -->
	<div bem:elem="head" remit:click="clickhead" qa:id="head">
		<bem:mod name="sticky" test="attrs['sticky-head']"/>
		<bem:mod name="sticky-fade" test="attrs['sticky-head-fade']"/>

		<div bem:elem="header-row">
			<fn:if test="!attrs['use-react-letter-header']">
				<fn:apply-match name="avatar-wrap"/>

				<div bem:elem="header-details" qa:id="head:details">
					<div bem:elem="author">
						<fn:apply-match name="correspondents" args="message.get('correspondents.from'), 'from', '', 'name-with-email'"/>
						<fn:apply-match name="date" fn:if="!attrs.compact"/>
						<fn:apply-match name="folder" fn:if="!attrs.compact"/>
						<fn:apply-match name="revoke-status" fn:if="attrs['enable-revoke-letter']"/>
						<fn:apply-match name="amp-icon" fn:if="(hasAmp && !attrs['preview-mode'] || hasAmpErrors) && !attrs.compact"/>
					</div>

					<fn:apply-match name="recipients" fn:if="_this.getMessageCorrespondents().length"/>
					<fn:apply-match name="folder" fn:if="attrs.compact"/>
					<fn:apply-match name="date" fn:if="attrs.compact"/>
					<fn:apply-match name="amp-icon" fn:if="(hasAmp && !attrs['preview-mode'] || hasAmpErrors) && attrs.compact"/>
				</div>
			</fn:if>
			<b:react-async
				fn:if="attrs['use-react-letter-header']"
				component="LetterHeader"
				componentClass="{this.lazyLetterHeader()}"
				class-name="header-wrapper"
				message="{message}"
				compact="{attrs.compact}"
				isOnline="{attrs.isOnline}"
				touch="{attrs.touch}"
				ponyMode="{ponyMode}"
				showFolder="{attrs.showfolder}"
				hasAmp="{hasAmp}"
				search="{search}"
				hasAmpErrors="{hasAmpErrors}"
				previewMode="{attrs['preview-mode']}"
				disableEdit="{attrs['disable-edit']}"
				disableCategory="{attrs['disable-category']}"
				detailsExpanded="{attrs['details-expanded']}"
				showExtendedCorrespondentsList="{attrs['show-extended-correspondents-list']}"
				currentUser="{attrs['current-user']}"
				enableRevokeLetter="{attrs['enable-revoke-letter']}"
			/>

			<div bem:elem="controls" qa:id="controls">
				<fn:apply-match name="status-flag" />
				<fn:apply-match name="dark-mode-toggle" fn:if="_this.isDarkModePossible()" />
				<fn:apply-match name="share-letter" fn:if="_this._showHeadShareButton()" />
				<fn:apply-match name="calendar-create" fn:if="_this._showHeadCalendarButton()" />
				<fn:apply-match name="chat-create" />
				<fn:apply-match name="print" fn:if="!attrs['disable-head-print'] && !attrs.selectMode"/>
				<fn:apply-match name="add-tag" fn:if="attrs['enable-tags']"/>
				<fn:apply-match name="more" />
			</div>
		</div>
	</div>

	<div bem:elem="before-letter-body">
		<!-- FMAIL-16605: Метки -->
		<fn:if test="attrs['enable-tags']">
			<b:react-async
					component="LetterTags"
					tags="{attrs.model.get('flags.tags')}"
					model="{attrs.model}"
			/>
		</fn:if>

		<div bem:elem="confirm-receipt" fn:if="_this.isEnableConfirmationReceipt()">
			<b:letter-confirm-receipt
				id="confirm-receipt"
				model="{message}"
				mobile="{attrs.mobile}"
				remit:confirm="confirmreceipt"
			/>
		</div>
		<!-- Кнопка подтверждение прочтение письма -->

		<!-- Переводчик -->
		<div bem:elem="translator" fn:if="_this.isTranslatorVisible()">
			<b:translator
				id="translator"
				remit:hide="translator:hide:click"
				remit:close="translator:close:click"
				remit:original="translator:original:click"
				remit:retry="translator:retry:click"
				remit:translate="translator:translate:click"

				letterId="{message.id}"
				error="{attrs['is-translator-error']}"
				compact="{attrs.compactTranslator}"
				from-default-selected="{attrs['translator-default-from']}"
				loading="{attrs['is-translator-loading']}"
				ponymode="{ponyMode}"
				to-default-selected="{attrs['translator-default-to']}"
				is-translator-visible="{attrs['is-translator-visible']}"
				translated="{_this.isLetterTranslated()}"
			/>
		</div>

		<!-- FMAIL-27305: Upmetric. Баннер над чеками внутри письма (хардкод) -->
		<fn:if test="_this.isEnableUpmetricPromo()">
			<b:react-async
				component="UpmetricPromo"
				componentClass="{_this.components.UpmetricPromo}"
				data="{_this.getUpmetricPromoData()}"
			/>
		</fn:if>
	</div>

	<!-- Блок-подсказка под шапкой письма -->
	<div bem:elem="tooltip" fn:if="!_this.isTranslatorVisible() && _this.isTooltipVisible()">
		<!-- Подсказка об отключенных картинках в папке "Спам" (с возможностью включить для письма) -->
		<fn:if test="_this.isImagesHiddenTooltipVisible()">
			<b:letter-tooltip
				type="images-hidden-tooltip"
				ponymode="{ponyMode}"
				mobile="{attrs.mobile}"
				title-text="{i18n(\'Мы скрыли изображения в письме, чтобы защитить аккаунт\')}"
				action-text="{i18n(\'Показать изображения\')}"
				remit:action="letter-tooltip:show-images:click"
				remit:close="letter-tooltip:close"
			/>
		</fn:if>
		<fn:if test="_this.isUntrustedSenderForCorp()">
			<b:letter-tooltip
					type="untrusted-sender-tooltip"
					ponymode="{ponyMode}"
					mobile="{attrs.mobile}"
					title-text="{i18n(\'Отправитель пишет вам впервые. Будьте внимательнее к ссылкам и вложениям\')}"
					remit:close="letter-tooltip:close"
			/>
		</fn:if>
	</div>

	<!-- Панель вложений -->
	<fn:if test="hasAttach">
		<div bem:elem="attach-list">
			<bem:mod name="hidden" test="!showAttachList"/>
			<b:attach-list
				offline-mode="{attrs['offline-mode']}"
				letter-length="{attrs.model.get('body.text').length}"
				models="{attrs.model.get('attaches.list')}"
				total-size="{attrs.model.getAttachmentsTotalSize()}"
				download-link="{_this.getAttachmentsDowloadLink()}"
				preview-mode="{attrs['preview-mode']}"
				use:mediator:byname="layout-manager attachments-manager"
				dark-mode="{_this.isDarkMode()}"
				showAttachList="{showAttachList}"
				showAttachSafetyStatus="{attrs['show-attach-safety-status'] && _this.getAttachSafetyStatus() && !messageFolder.isSpam()}"
				safety-status="{_this.getAttachSafetyStatus()}"
				has-attach-safety-status-background="{attrs['has-attach-safety-status-background']}"
				attach-safety-status-position="{attrs['attach-safety-status-position']}"
				remit:attach-list-expanded="attaches:expanded"
				remit:attach-list-collapsed="attaches:collapsed"
				remit:attach-list-cloud="attaches:cloud:all"
				remit:thumb-open="attaches:open"
				remit:thumb-cloud="attaches:cloud:one"
			/>
		</div>
	</fn:if>

	<!-- Тело письма -->
	<div bem:elem="body" qa:id="body">
		<!-- Показ приглашения если есть ics -->
		<!-- Скрываем приглашение, если есть плашка адреса мероприятия -->
		<b:letter-calendar
			key="{_this.isDarkMode()}"
			dark-mode="{_this.isDarkMode()}"
			fn:if="!(attrs['address-header-calendar'] && message.getJsonLdEvent() || attrs['smart-card-ics'] && _this.hasSmartCardIcsMeta(message))"
			calendars="{message.getCalendarFromAttach()}"
		/>

		<fn:choose>
			<fn:when test="hasAmp && !attrs['preview-mode']">
				<b:letter-body-amp
						ref="letter-body"
						dark-mode="{_this.isDarkMode()}"
						model="{message}"
						remit:error="amp:error"
						remit:force-recalc="letter-force-recalc"
						remit:change-css-selector-theme="amp:change-css-selector-theme"

						analyticsIndex="{attrs.analyticsIndex}"
				/>
			</fn:when>
			<fn:otherwise>
				<!-- Содержимое письма -->

				<fn:choose>
					<fn:when test="useReactMigrLetterBody">
						<b:react-async
							component="LetterBody"
							componentClass="{_this.components.LetterBody}"
							ref="letter-body"
							key="{_this.getLetterBodyKey()}"
							id="{_this.getLetterBodyKey()}"
							bodyHtml="{_this.getLetterBody()}"
							collapsed-default="{attrs['quotes-collapsed-default']}"
							ponymode="{ponyMode}"
							dark-mode="{_this.isDarkMode()}"
							message="{message}"
							preview-mode="{attrs['preview-mode']}"
							current-user="{attrs['current-user']}"
							remitEvents="{_this.remitEvents.LetterBody}"
							broadcastEvent="{_this.broadcastFromReact.bind(_this)}"
							updateRemitEventsName
							search="{search}"
							useMediators="{['layout-manager', 'features', 'flags', 'thread-scroller']}"
							analyticsIndex="{attrs.analyticsIndex}"
						/>
					</fn:when>

					<fn:otherwise>
						<b:letter-body
							ref="letter-body"
							key="{_this.getLetterBodyKey()}"
							id="{_this.getLetterBodyKey()}"
							bodyHtml="{_this.getLetterBody()}"
							collapsed-default="{attrs['quotes-collapsed-default']}"
							ponymode="{ponyMode}"
							dark-mode="{_this.isDarkMode()}"
							message="{message}"
							preview-mode="{attrs['preview-mode']}"
							current-user="{attrs['current-user']}"
							search="{search}"
							remit:resize="resize"
							remit:blockquote="blockquote"
							remit:allowedattrclick="letter:body:allowedattrclick"
							remit:data-attr-click="letter:body:data-attr:click"
							remit:tomyselfclick="letter:body:tomyself"
							remit:force-recalc="letter-force-recalc"
							remit:vktioslinkclick="letter:body:vktioslinkclick"
							use:mediator:byname="layout-manager features flags"
							analyticsIndex="{attrs.analyticsIndex}"
						/>
					</fn:otherwise>
				</fn:choose>
			</fn:otherwise>
		</fn:choose>
	</div>

	<!-- Подвал-->
	<div bem:elem="footer" qa:id="footer" fn:if="!attrs.readonly && _this.isShowFooter()">
		<bem:mod name="sticky" test="attrs['sticky-footer']"/>
		<bem:mod name="sticky-fade" test="attrs['sticky-footer-fade']"/>
		<bem:mod name="new-toolbar"/>

		<div bem:elem="footer-background">
			<fn:var name="hasStickyUnsubscribeButton" value="{_this.hasUnsubscribeButton()}" />
			<fn:var name="hideStickyChatButtonText" value="{_this.isShowStickyByLetterContext() && !hasStickyUnsubscribeButton ? attrs['sticky-reduce-reply'] : attrs['sticky-reduce-one-text']}" />
			<fn:var name="isMarusiaEnabled" value="{attrs['marusia-portal-enabled'] && _this.isMarusiaReadLetterEnabled()}" />
			<fn:var name="isMarusiaAllEnabled" value="{attrs['marusia-portal-enabled'] && attrs['marusia-read-all-letters']}" />
			<fn:var name="isSmartReplyEnabled" value="{attrs.smart_replies && _this.isEnableReply()}" />
			<fn:var name="marusiaRadarPrefix" value="{_this.getMarusiaReadLetterRadarPrefix()}" />

			<!-- Кнопки ответа на письмо или Маруся для фичи контекстных стиков -->
			<div bem:elem="footer-buttons" qa:id="footer-buttons">
				<div bem:elem="footer-left">
					<span bem:elem="marusia-rl" fn:if="isMarusiaAllEnabled && _this.isShowStickyByLetterContext()">
						<fn:add-class name="ready" />
						<b:marusia-rl-button
							model="{attrs.model}"
							hidebutton="{attrs['sticky-reduce-one-text']}"
							ponymode="{attrs.ponymode}"
							use:mediator:byname="marusia-manager"
							radar-prefix="{marusiaRadarPrefix}"
							qa:id="marusia-rl-button"
						/>
					</span>

					<div bem:elem="footer-button" fn:if="hasReplyAll && !_this.isShowStickyByLetterContext()">
						<fn:choose>
							<fn:when test="draftReplyAll">
								<b:dropdown
										use:mixin="shortcut-title"
										shortcut="shift+r"
										radar-id="replyall"
										text="{i18n(\'Ответить всем\')}"
										ico="reply-all"
										base
										pure
										touch="{attrs.touch && !attrs.mobile}"
										disabled="{!_this.isEnableReply()}"
								>
									<fn:match name="items">
										<b:list>
											<b:list-item
													event:details="{model: attrs.model, draftId: draftReplyAll}"
													remit:click="letter:draft:replyall"
											>
												{i18n(\'Есть черновик, продолжить с ним\')}
											</b:list-item>
											<b:list-item
													event:details="attrs.model"
													remit:click="compose:replyall">
												{i18n(\'Новое письмо\')}
											</b:list-item>
										</b:list>
									</fn:match>
								</b:dropdown>
							</fn:when>
							<fn:otherwise>
								<b:button2
										use:mixin="shortcut-title"
										shortcut="shift+r"
										remit:click="compose:replyall"
										event:details="attrs.model"
										radar-id="replyall"
										text="{i18n(\'Ответить всем\')}"
										ico="reply-all"
										base
										pure
										touch="{attrs.touch && !attrs.mobile}"
										model="{attrs.model}"
										disabled="{!_this.isEnableReply()}"
								/>
							</fn:otherwise>
						</fn:choose>
					</div>

					<div bem:elem="footer-button" fn:if="!_this.isShowStickyByLetterContext()">
						<fn:var name="shortReply" value="{hasReplyAll && attrs['sticky-reduce-reply']}"/>

						<fn:choose>
							<fn:when test="draftReply">
								<b:dropdown
										use:mixin="shortcut-title"
										shortcut="r"
										radar-id="reply"
										text="{i18n(\'Ответить\')}"
										ico="reply"
										base
										pure
										touch="{attrs.touch && !attrs.mobile}"
										disabled="{!_this.isEnableReply()}"
										short="{shortReply}"
								>
									<fn:match name="items">
										<b:list>
											<b:list-item
													event:details="{model: attrs.model, draftId: draftReply}"
													remit:click="letter:draft:reply"
											>
												{i18n(\'Есть черновик, продолжить с ним\')}
											</b:list-item>
											<b:list-item
													event:details="attrs.model"
													remit:click="compose:reply">
												{i18n(\'Новое письмо\')}
											</b:list-item>
										</b:list>
									</fn:match>
								</b:dropdown>
							</fn:when>
							<fn:otherwise>
								<b:button2
										use:mixin="shortcut-title"
										shortcut="r"
										remit:click="compose:reply"
										event:details="attrs.model"
										radar-id="reply"
										text="{i18n(\'Ответить\')}"
										ico="reply"
										base
										pure
										touch="{attrs.touch && !attrs.mobile}"
										model="{attrs.model}"
										disabled="{!_this.isEnableReply()}"
										short="{shortReply}"
								/>
							</fn:otherwise>
						</fn:choose>
					</div>

					<div bem:elem="footer-button" fn:if="!_this.isShowStickyByLetterContext()">
						<fn:choose>
							<fn:when test="draftForward">
								<b:dropdown
										use:mixin="shortcut-title"
										shortcut="f"
										event:details="attrs.model"
										radar-id="forward"
										text="{i18n(\'Переслать\')}"
										ico="forward"
										base
										pure
										touch="{attrs.touch && !attrs.mobile}"
										disabled="{!_this.isEnableForward()}"
								>
									<fn:match name="items">
										<b:list>
											<b:list-item
													event:details="{model: attrs.model, draftId: draftForward}"
													remit:click="letter:draft:forward"
											>
												{i18n(\'Есть черновик, продолжить с ним\')}
											</b:list-item>
											<b:list-item
													event:details="attrs.model"
													remit:click="compose:forward">
												{i18n(\'Новое письмо\')}
											</b:list-item>
										</b:list>
									</fn:match>
								</b:dropdown>

							</fn:when>
							<fn:otherwise>
								<b:button2
										remit:click="compose:forward"
										use:mixin="shortcut-title"
										shortcut="f"
										event:details="attrs.model"
										radar-id="forward"
										text="{i18n(\'Переслать\')}"
										ico="forward"
										base
										pure
										touch="{attrs.touch && !attrs.mobile}"
										model="{attrs.model}"
										disabled="{!_this.isEnableForward()}"
								/>
							</fn:otherwise>
						</fn:choose>
					</div>

					<div bem:elem="footer-button" fn:if="_this.isRevokeEnabled()">
						<fn:if test="!message.is('flags.was_recalled')">
							<b:button2
								promoId="revoke-letter"
								remit:click="letter:revoke"
								event:details="{model: attrs.model}"
								radar-id="revoke"
								text="{i18n(\'Отозвать\')}"
								ico="actions:message_revoke"
								touch="{attrs.touch && !attrs.mobile}"
								model="{attrs.model}"
								data-test-id="revoke-button"
								disabled="{attrs['offline-mode']}"
								base
								pure
							/>
						</fn:if>
						<fn:if test="message.is('flags.was_recalled') && !message.is('flags.was_replaced')">
							<b:button2
								remit:click="letter:replace"
								event:details="{model: attrs.model}"
								radar-id="replace"
								text="{i18n(\'Заменить\')}"
								ico="actions:message_replace"
								touch="{attrs.touch && !attrs.mobile}"
								model="{attrs.model}"
								data-test-id="replace-button"
								disabled="{attrs['offline-mode']}"
								base
								pure
							/>
						</fn:if>
					</div>
				</div>

				<div bem:elem="footer-right">
					<b:button2
							fn:if="showNotesBtnForMailingsOrLetterToMyself || attrs['default-enable-save-note-button']"
							remit:click="save:notes"
							use:mixin="shortcut-title"
							qa:id="saveNote"
							event:details="{radarLetterType: showNotesBtnForMailings ? 'mailings' : showNotesBtnForLetterToMyself ? 'letters_to_myself' : 'default'}"
							text="{!attrs['sticky-reduce-all-texts'] && i18n(\'Сохранить в заметку\')}"
							promoId="{showNotesBtnForMailingsOrLetterToMyself ? 'octavius-tooltip-save-notes' : null}"
							ico="categories:notes:outline"
							base
							pure
							touch="{attrs.touch && !attrs.mobile}"
							model="{attrs.model}"
							disabled="{attrs['offline-mode']}"
					/>

					<fn:if test="!_this._showUnsubscribeButton() && !_this.isDatesMetadataEnabled() && !_this.isShowStickyByLetterContext()">
						<fn:if test="enableFakeCreateTodo">
							<div class="letter__footer-button">
								<b:react-async
										component="CreateTodo"
										compact="{attrs['sticky-reduce-one-text']}"
										letterId="{message.get('id')}"
										ponyMode="{ponyMode}"
								/>
							</div>
						</fn:if>

						<!-- Кнопки Предложить звонок и Создать событие показываем только, если нет кнопки рассылки и метадаты для кнопки календаря -->
						<div bem:elem="footer-button" fn:if="!attrs['disable-create-event'] && !attrs['disable-footer-calendar']">
							<b:calendar-button
									model="{attrs.model}"
									sticky-reduce-one-text="{attrs['sticky-reduce-one-text']}"
									use:mediator:byname="calendar-manager"
							/>
						</div>
					</fn:if>
					<fn:if test="_this._showVkMessengerButton()">
						<div bem:elem="vk-chat-button" promo:id="toolbar-vk-chat">
							<fn:var name="vkMessengerParams" value="{_this._getVkMessengerParams()}" />
							<b:button2
								qa:id="vk-messenger:open"
								remit:click="vk-messenger:open"
								event:details="vkMessengerParams.href"
								radar-id="footer-vk"
								text="{!hideStickyChatButtonText && vkMessengerParams.text}"
								title="{vkMessengerParams.text}"
								ico="social:vk"
								base
								clean
								touch="{attrs.touch && !attrs.mobile}"
								model="{attrs.model}"
								centered="{hideStickyChatButtonText}"
							/>
						</div>
					</fn:if>

					<!-- Отписка из письма справа -->
					<fn:if test="hasStickyUnsubscribeButton">
						<fn:apply-match name="unsubscribe"/>
					</fn:if>

					<!-- Если есть дата для письма - приоритизируем кнопку создания события -->
					<fn:if test="this.isDatesMetadataEnabled() && !_this.isShowStickyByLetterContext()">
						<div bem:elem="footer-button" fn:if="!attrs['disable-create-event'] && !attrs['disable-footer-calendar']">
							<b:calendar-button
									model="{attrs.model}"
									dates-metadata="{attrs['dates-metadata']}"
									sticky-reduce-one-text="{attrs['sticky-reduce-one-text']}"
									use:mediator:byname="calendar-manager"
							/>
						</div>
					</fn:if>

					<fn:if test="!_this.isShareTake() && _this.isShowCreateChat()">
						<div bem:elem="footer-button">
							<b:button2
								qa:id="chat:create"
								remit:click="chat:create"
								event:details="{model:attrs.model}"
								text="{i18n(\'Создать чат\')}"
								title="{i18n(\'Создать чат\')}"
								ico="message"
								base
								pure
								touch="{attrs.touch && !attrs.mobile}"
								model="{attrs.model}"
								centered="{attrs['sticky-reduce-one-text']}"
							/>
						</div>
					</fn:if>
				</div>
			</div>

			<div bem:elem="footer-controls" fn:if="(isMarusiaAllEnabled || isSmartReplyEnabled) && _this.isShowSmartReplyAndMarusia()" qa:id="footer-controls">
				<fn:add-class name="single-line single-line_{ponyMode ? 'compact' : 'medium'}" test="_this.isFooterControlsSingleLine()"/>
				<span bem:elem="marusia-rl" fn:if="isMarusiaEnabled || isMarusiaAllEnabled">
					<fn:add-class name="ready" test="attrs.smart_replies_ready || isMarusiaAllEnabled"/>
					<b:marusia-rl-button
						model="{attrs.model}"
						ponymode="{attrs.ponymode}"
						use:mediator:byname="marusia-manager"
						radar-prefix="{marusiaRadarPrefix}"
						qa:id="marusia-rl-button"
					/>
				</span>

				<fn:if test="isSmartReplyEnabled">
					<fn:for data="attrs.smart_replies" as="value" key="key">
						<span bem:elem="smart-reply" key="{key}" qa:id="smart-reply">
							<fn:add-class name="ready" test="attrs.smart_replies_ready"/>
							<bem:mod name="ponymode" test="attrs.ponymode"/>
							<b:button2
								remit:click="compose:smartreply"
								event:details="{model: attrs.model, key: key}"
								text="{value}"
								compact="{attrs.ponymode}"
								medium="{!attrs.ponymode}"
								shadowless
								invert
								radar-id="smart-reply{message.is('flags.smart_reply_stage') ? '_stage' : ''}"
							/>
						</span>
					</fn:for>
				</fn:if>
			</div>
		</div>
	</div>
</div>
`,"./app/ui-block/letter/letter.html")}.apply(t,r))||(e.exports=n)},6073:function(e,t,a){var r,n;r=[a(18440)],void 0===(n=function(e){return e.smartParse(e.__FEAST_TEMPLATE__`<div>
	<bem:mod name="ponymode" test="attrs.ponymode"/>

	<img
		bem:elem="img" src="{_this.getLogoSrc()}"
		remit:click="marusia:rl:button:click"
		event:details="{model: attrs.model}"
	/>
		
	<b:ico
		name="actions:play"
		mod="internal-play"
		size="xs"
		remit:click="marusia:rl:button:click"
		event:details="{model: attrs.model}"
		fn:if="attrs.hidebutton"
	/>

	<div bem:elem="button" fn:if="!attrs.hidebutton">
        <bem:mod name="ponymode" test="attrs.ponymode"/>
		<b:button2
			text="{i18n(\'Прочитать письмо\')}"
			ico="actions:play"
			icoSize="xs"
			shadowless
			invert
			remit:click="marusia:rl:button:click"
			event:details="{model: attrs.model}"
			centered
            compact="{attrs.ponymode}"
            medium="{!attrs.ponymode}"
		/>
	</div>
</div>
`,"./app/ui-block/marusia-read-letter-button/marusia-read-letter-button.html")}.apply(t,r))||(e.exports=n)},70045:function(e,t,a){var r,n;r=[a(18440)],void 0===(n=function(e){return e.smartParse(e.__FEAST_TEMPLATE__`<div>
	<b:select
		remit:item-click="language-change"
		selected-index="{_this.getSelectedIndex()}"
		disabled-index="{_this.getDisabledIndex()}"
		items="{_this.getItems()}"
	>
		<fn:match
			name="control"
			args="selectedText, selectedItem, selectedIndex, expanded"
		>
			<div
				bem:elem="custom_control"
				remit:click="control-click"
				disabled="{attrs.disabled}"
			>
				<bem:mod name="pressed" test="expanded" />
				<bem:mod name="pony-mode" test="attrs.ponymode" />
				<bem:mod name="compact" test="attrs.compact" />

				<span bem:elem="text" qa:id="folder-name-filter">
					<fn:value>_this.getText(selectedText)</fn:value>
				</span>

				<!-- Стрелка -->
				<div bem:elem="icon">
					<b:ico name="navigation:drop_down_small" size="s" />
				</div>
			</div>
		</fn:match>
	</b:select>
</div>
`,"./app/ui-block/translator-select/translator-select.html")}.apply(t,r))||(e.exports=n)},93798:function(e,t,a){var r,n;r=[a(18440)],void 0===(n=function(e){return e.smartParse(e.__FEAST_TEMPLATE__`<div qa:id="translator" xmlns:b="http://www.w3.org/1999/html" ref="translator">
	<!-- Переменные -->
	<fn:var name="disabled" value="{attrs.loading}" />
	<fn:var name="ponymode" value="{attrs.ponymode}" />
	<fn:var
		name="enableHideTranslator"
		value="{_this.getEnableHideTranslator()}"
	/>

	<!-- Модификаторы -->
	<bem:mod name="pony-mode" test="ponymode" />
	<bem:mod name="disabled" test="disabled" />

	<div bem:elem="wrapper">
		<!-- Ошибка -->
		<fn:if test="attrs.error">
			<div bem:elem="error">{i18n(\'Не удалось перевести текст\')}</div>
		</fn:if>

		<!-- Выбор языка перевода -->
		<fn:if test="!attrs.error">
			<div bem:elem="title">{i18n(\'Перевод\')}:</div>

			<b:translator-select
				remit:language-change="from:change"
				selected="{attrs['from-selected']}"
				disabled="{disabled}"
				disabled-item="{_this.getTo()}"
				compact="{attrs.compact}"
				containerRef="{_this.refs.translator}"
				id="from"
				qa:id="from"
				ponymode="{ponymode}"
			/>

			<b:button2
				remit:click="reverse:click"
				qa:id="swap"
				ico="navigation:arrow_swipe"
				ponymode="{ponymode}"
				pure
				disabled="{disabled}"
				centered
				compact
			/>

			<b:translator-select
				remit:language-change="to:change"
				selected="{attrs['to-selected']}"
				disabled="{disabled}"
				disabled-item="{_this.getFrom()}"
				compact="{attrs.compact}"
				containerRef="{_this.refs.translator}"
				id="to"
				qa:id="to"
				ponymode="{ponymode}"
			/>

			<div bem:elem="spinner">
				<bem:mod name="hidden" test="!disabled" />
				<b:spinner size="xxs" color="primary" />
			</div>

			<div bem:elem="translate">
				<b:button-link
					remit:click="translate:click"
					disabled="{disabled}"
					ponymode="{ponymode}"
					qa:id="translate"
					text="{_this.getText()}"
				/>
			</div>

		</fn:if>
		<div bem:elem="right">
			<div bem:elem="close">
				<b:button2
					fn:if="!enableHideTranslator"
					qa:id="close"
					remit:click="button-close:click"
					ponymode="{ponymode}"
					ico="actions:close"
					centered
					compact
					pure
				/>
				<b:dropdown
					fn:if="enableHideTranslator"
					qa:id="dropdown"
					ico="actions:close"
					ponymode
					pure
					remit:dropdown-change-state="dropdown-change"
				>
					<fn:match name="items">
						<b:list qa:id="translator-hide-list">
							<b:list-item qa:id="hide" remit:click="hide:click">
								{i18n(\'Не предлагать перевод\')}
							</b:list-item>
							<b:list-item qa:id="close" remit:click="dropdown-close:click">
								{i18n(\'Закрыть\')}
							</b:list-item>
						</b:list>
					</fn:match>
				</b:dropdown>
			</div>
		</div>
	</div>
</div>
`,"./app/ui-block/translator/translator.html")}.apply(t,r))||(e.exports=n)},47065:function(e,t,a){var r={"./AttachThumb/AttachThumb":[88758,8758],"./AttachThumbMobile/AttachThumb":[57687,1049,7450]};function n(e){if(!a.o(r,e))return Promise.resolve().then((function(){var t=new Error("Cannot find module '"+e+"'");throw t.code="MODULE_NOT_FOUND",t}));var t=r[e],n=t[0];return Promise.all(t.slice(1).map(a.e)).then((function(){return a(n)}))}n.keys=function(){return Object.keys(r)},n.id=47065,e.exports=n},46855:function(e,t,a){var r,n;!function(i,o){if(e.exports)e.exports=o();else if(1)void 0===(n="function"==typeof(r=o)?r.call(t,a,t,e):r)||(e.exports=n)}(0,(function(){var e="first",t=document,a={}.hasOwnProperty;function r(){return n.apply(null,arguments)||i.apply(null,arguments)}function n(e,t,a,n,o){if(t&&!t.nodeType&&arguments.length<=2)return!1;var s,l="function"==typeof a;if(l)s=a,a=function(e,t){return s(e.text,t.startIndex)};var d=i(t,{find:e,wrap:l?null:a,replace:l?a:"$"+(n||"&"),prepMatch:function(e,t){if(!e[0])throw"findAndReplaceDOMText cannot handle zero-length matches";if(n>0){var a=e[n];e.index+=e[0].indexOf(a),e[0]=a}return e.endIndex=e.index+e[0].length,e.startIndex=e.index,e.index=t,e},filterElements:o});return r.revert=function(){return d.revert()},!0}function i(e,t){return new o(e,t)}function o(e,t){if(!t.offset)t.offset=0;var n=t.preset&&r.PRESETS[t.preset];if(t.portionMode=t.portionMode||"retain",n)for(var i in n)if(a.call(n,i)&&!a.call(t,i))t[i]=n[i];if(this.node=e,this.options=t,this.prepMatch=t.prepMatch||this.prepMatch,this.reverts=[],this.matches=this.search(),this.matches.length)this.processMatches()}return r.NON_PROSE_ELEMENTS={br:1,hr:1,script:1,style:1,img:1,video:1,audio:1,canvas:1,svg:1,map:1,object:1,input:1,textarea:1,select:1,option:1,optgroup:1,button:1},r.NON_CONTIGUOUS_PROSE_ELEMENTS={address:1,article:1,aside:1,blockquote:1,dd:1,div:1,dl:1,fieldset:1,figcaption:1,figure:1,footer:1,form:1,h1:1,h2:1,h3:1,h4:1,h5:1,h6:1,header:1,hgroup:1,hr:1,main:1,nav:1,noscript:1,ol:1,output:1,p:1,pre:1,section:1,ul:1,br:1,li:1,summary:1,dt:1,details:1,rp:1,rt:1,rtc:1,script:1,style:1,img:1,video:1,audio:1,canvas:1,svg:1,map:1,object:1,input:1,textarea:1,select:1,option:1,optgroup:1,button:1,table:1,tbody:1,thead:1,th:1,tr:1,td:1,caption:1,col:1,tfoot:1,colgroup:1},r.NON_INLINE_PROSE=function(e){return a.call(r.NON_CONTIGUOUS_PROSE_ELEMENTS,e.nodeName.toLowerCase())},r.PRESETS={prose:{forceContext:r.NON_INLINE_PROSE,filterElements:function(e){return!a.call(r.NON_PROSE_ELEMENTS,e.nodeName.toLowerCase())}}},r.Finder=o,o.prototype={search:function(){var e,t=0,a=0,r=this.options.find,n=this.getAggregateText(),i=[],o=this;return r="string"==typeof r?RegExp(String(r).replace(/([.*+?^=!:${}()|[\]\/\\])/g,"\\$1"),"g"):r,function n(s){for(var l=0,d=s.length;l<d;++l){var c=s[l];if("string"==typeof c){if(r.global)for(;e=r.exec(c);)i.push(o.prepMatch(e,t++,a));else if(e=c.match(r))i.push(o.prepMatch(e,0,a));a+=c.length}else n(c)}}(n),i},prepMatch:function(e,t,a){if(!e[0])throw new Error("findAndReplaceDOMText cannot handle zero-length matches");return e.endIndex=a+e.index+e[0].length,e.startIndex=a+e.index,e.index=t,e},getAggregateText:function(){var e=this.options.filterElements,t=this.options.forceContext;return function a(r){if(r.nodeType===Node.TEXT_NODE)return[r.data];if(e&&!e(r))return[];var n=[""],i=0;if(r=r.firstChild)do{if(r.nodeType!==Node.TEXT_NODE){var o=a(r);if(t&&r.nodeType===Node.ELEMENT_NODE&&(!0===t||t(r)))n[++i]=o,n[++i]="";else{if("string"==typeof o[0])n[i]+=o.shift();if(o.length)n[++i]=o,n[++i]=""}}else n[i]+=r.data}while(r=r.nextSibling);return n}(this.node)},processMatches:function(){var e,t,a,r=this.matches,n=this.node,i=this.options.filterElements,o=[],s=n,l=r.shift(),d=0,c=0,m=[n];e:for(;;){if(s.nodeType===Node.TEXT_NODE){if(!t&&s.length+d>=l.endIndex)t={node:s,index:c++,text:s.data.substring(l.startIndex-d+this.options.offset,l.endIndex-d),indexInMatch:0===d?0:d-l.startIndex,indexInNode:l.startIndex-d+this.options.offset,endIndexInNode:l.endIndex-d,isEnd:!0};else if(e)o.push({node:s,index:c++,text:s.data,indexInMatch:d-l.startIndex,indexInNode:0});if(!e&&s.length+d>l.startIndex)e={node:s,index:c++,indexInMatch:0,indexInNode:l.startIndex-d+this.options.offset,endIndexInNode:l.endIndex-d,text:s.data.substring(l.startIndex-d+this.options.offset,l.endIndex-d)};d+=s.data.length}if(a=s.nodeType===Node.ELEMENT_NODE&&i&&!i(s),e&&t){if(s=this.replaceMatch(l,e,o,t),d-=t.node.data.length-t.endIndexInNode,e=null,t=null,o=[],c=0,!(l=r.shift()))break}else if(!a&&(s.firstChild||s.nextSibling)){if(s.firstChild)m.push(s),s=s.firstChild;else s=s.nextSibling;continue}for(;;){if(s.nextSibling){s=s.nextSibling;break}if((s=m.pop())===n)break e}}},revert:function(){for(var e=this.reverts.length;e--;)this.reverts[e]();this.reverts=[]},prepareReplacementString:function(t,a,r){var n=this.options.portionMode;if(n===e&&a.indexInMatch>0)return"";if(t=t.replace(/\$(\d+|&|`|')/g,(function(e,t){var a;switch(t){case"&":a=r[0];break;case"`":a=r.input.substring(0,r.startIndex);break;case"'":a=r.input.substring(r.endIndex);break;default:a=r[+t]||""}return a})),n===e)return t;if(a.isEnd)return t.substring(a.indexInMatch);else return t.substring(a.indexInMatch,a.indexInMatch+a.text.length)},getPortionReplacementNode:function(e,a){var r=this.options.replace||"$&",n=this.options.wrap,i=this.options.wrapClass;if(n&&n.nodeType){var o=t.createElement("div");o.innerHTML=n.outerHTML||(new XMLSerializer).serializeToString(n),n=o.firstChild}if("function"==typeof r)if((r=r(e,a))&&r.nodeType)return r;else return t.createTextNode(String(r));var s="string"==typeof n?t.createElement(n):n;if(s&&i)s.className=i;if(!(r=t.createTextNode(this.prepareReplacementString(r,e,a))).data)return r;if(!s)return r;else return s.appendChild(r),s},replaceMatch:function(e,a,r,n){var i,o,s=a.node,l=n.node;if(s===l){var d=s;if(a.indexInNode>0)i=t.createTextNode(d.data.substring(0,a.indexInNode)),d.parentNode.insertBefore(i,d);var c=this.getPortionReplacementNode(n,e);if(d.parentNode.insertBefore(c,d),n.endIndexInNode<d.length)o=t.createTextNode(d.data.substring(n.endIndexInNode)),d.parentNode.insertBefore(o,d);return d.parentNode.removeChild(d),this.reverts.push((function(){if(i===c.previousSibling)i.parentNode.removeChild(i);if(o===c.nextSibling)o.parentNode.removeChild(o);c.parentNode.replaceChild(d,c)})),c}else{i=t.createTextNode(s.data.substring(0,a.indexInNode)),o=t.createTextNode(l.data.substring(n.endIndexInNode));for(var m=this.getPortionReplacementNode(a,e),u=[],h=0,f=r.length;h<f;++h){var p=r[h],b=this.getPortionReplacementNode(p,e);p.node.parentNode.replaceChild(b,p.node),this.reverts.push(function(e,t){return function(){t.parentNode.replaceChild(e.node,t)}}(p,b)),u.push(b)}var g=this.getPortionReplacementNode(n,e);return s.parentNode.insertBefore(i,s),s.parentNode.insertBefore(m,s),s.parentNode.removeChild(s),l.parentNode.insertBefore(g,l),l.parentNode.insertBefore(o,l),l.parentNode.removeChild(l),this.reverts.push((function(){i.parentNode.removeChild(i),m.parentNode.replaceChild(s,m),o.parentNode.removeChild(o),g.parentNode.replaceChild(l,g)})),g}}},r}))},22702:function(e,t,a){"use strict";a.r(t),a.d(t,{blockSpec:function(){return Sr},default:function(){return Ar}});var r=a(46389),n=a(17717),i=a.n(n),o=a(73928),s=a(60033),l=a.n(s),d=a(52745),c=a(13620),m=a(27355),u=a(43845),h=a(4815),f=a(28692),p=a(71328),b=function(){return b=Object.assign||function(e){for(var t,a=1,r=arguments.length;a<r;a++)for(var n in t=arguments[a])if(Object.prototype.hasOwnProperty.call(t,n))e[n]=t[n];return e},b.apply(this,arguments)};function g(e,t,a){if(h.DOMPURIFY&&!h.QUOTATION_PARSER)return function(e,t){f.yc.time("letter-purify");var a=p.default.sanitize(e);return f.yc.timeEnd("letter-purify",b(b({},t?{dwh:{appendix:t},appendix:t}:{}),{skipPoor:!0})),a}(e,t);else return e}var v=a(25191),_=a(99892),y=a(72727),E=a(63745),k=a.n(E),T="_1-OAt1NCK63o0Yh5IJ5ksx",w="_1xxJMoAshddDsxO1O6kpP9",S="qj557W585tjFkUfo-EROj",A=function(e){var t,a,r,n,i,o,s,d,c,m,u,h,f,p,b,g,v,A=(0,E.useRef)(null),C=(0,E.useCallback)((function(){var t,a,r,n;l().send("upmetric_lb_click_action",{dwh:{letter_id:null===(t=e.data)||void 0===t?void 0:t.letterId,banner_id:null===(r=null===(a=e.data)||void 0===a?void 0:a.banner)||void 0===r?void 0:r.id}}),(0,y.default)(null===(n=e.data)||void 0===n?void 0:n.banner.link,y.OpenerTarget.blank),setTimeout((function(){var e,t;return null===(t=null===(e=A.current)||void 0===e?void 0:e.focus)||void 0===t?void 0:t.call(e)}),0)}),[A.current,null===(t=e.data)||void 0===t?void 0:t.letterId,null===(r=null===(a=e.data)||void 0===a?void 0:a.banner)||void 0===r?void 0:r.id]),L=(0,E.useCallback)((function(){var e,t;if("IFRAME"===(null===(e=document.activeElement)||void 0===e?void 0:e.tagName)&&"upmetric-banner"===(null===(t=document.activeElement)||void 0===t?void 0:t.id))C()}),[C]);(0,E.useEffect)((function(){var t,a,r;return l().send("upmetric_lb_view",{dwh:{letter_id:null===(t=e.data)||void 0===t?void 0:t.letterId,banner_id:null===(r=null===(a=e.data)||void 0===a?void 0:a.banner)||void 0===r?void 0:r.id}}),window.addEventListener("blur",L),function(){return window.removeEventListener("blur",L)}}),[]);var x=(0,E.useCallback)((function(){var t,a,r,n;l().send("upmetric_lb_pixel_track_error",{dwh:{letter_id:null===(t=e.data)||void 0===t?void 0:t.letterId,banner_id:null===(r=null===(a=e.data)||void 0===a?void 0:a.banner)||void 0===r?void 0:r.id,pixel_url:null===(n=e.data)||void 0===n?void 0:n.pixelUrl}})}),[null===(n=e.data)||void 0===n?void 0:n.pixelUrl]);if(!((null===(i=e.data)||void 0===i?void 0:i.letterId)&&(null===(s=null===(o=e.data)||void 0===o?void 0:o.banner)||void 0===s?void 0:s.id)&&(null===(c=null===(d=e.data)||void 0===d?void 0:d.banner)||void 0===c?void 0:c.link)&&(null===(u=null===(m=e.data)||void 0===m?void 0:m.banner)||void 0===u?void 0:u.url)&&(null===(p=null===(f=null===(h=e.data)||void 0===h?void 0:h.banner)||void 0===f?void 0:f.size)||void 0===p?void 0:p.width)&&(null===(v=null===(g=null===(b=e.data)||void 0===b?void 0:b.banner)||void 0===g?void 0:g.size)||void 0===v?void 0:v.height)))return null;else return k().createElement("div",{className:T},k().createElement("iframe",{src:(0,_.IZ)(e.data.banner.url),id:"upmetric-banner",className:w,style:{width:e.data.banner.size.width,height:e.data.banner.size.height}}),e.data.ordInfo&&k().createElement("span",{className:S},e.data.ordInfo),e.data.pixelUrl&&k().createElement("img",{src:(0,_.IZ)(e.data.pixelUrl),alt:"upmetric-promo-pixel",width:"0",height:"0",onError:x}),k().createElement("div",{ref:A,tabIndex:-1,style:{width:0,height:0,overflow:"hidden"}}))},C=a(64719),L=a(50987),x=a(27972),I=a(20799),R=a(82010),M=a(18440),O=a.n(M),P=a(3275),D=a(19008),N=a(44438),B=a(37030),q=a(75320),U=a.n(q),F=a(54844);var H=a(4183),Z=a(48250),z=a(83183),W=a(14077),V=a(78266),j=a(2469),G=a(88695),Q=a(29404),Y=a(34632),K=a(31086),X=a(20210),$=function(e){var t=X.ZP.lookup(e);if(0!==(null==e?void 0:e.localeCompare(t)))return".".concat(e,", .").concat(t);else return".".concat(e)},J=a(26739),ee="application/pkcs7-mime",te="application/pkcs7-signature",ae="p7m",re="p7s",ne="p7z",ie="p7c",oe="wrng",se="smime",le="".concat(se,".").concat(ae),de="".concat(se,".").concat(re),ce="".concat(se,".").concat(ne),me="".concat(se,".").concat(ie),ue=[le,de,ce,me];var he,fe=a(4872),pe=a.n(fe),be=a(33440),ge=a(39783),ve=a.n(ge),_e=a(92042),ye=a.n(_e),Ee=a(9789),ke=a(39939),Te=a(66225),we=a(69052),Se=a(63062),Ae=a(73361),Ce=a(61799),Le=a(93286),xe=a(57045),Ie=a(8387),Re=a(84427),Me=a(5587),Oe=a(26499),Pe=a(91779),De=a(28652),Ne=a.n(De),Be=function(e){return e.isCloudStock()||h.ENABLE_CLONE_CLOUD_ATTACHMENTS&&e.isCloud()||!e.isOverMaxSize()&&!e.isLink()&&!e.isCloud()},qe=a(90557),Ue=a(53526),Fe=a.n(Ue),He=a(81899),Ze=a(50),ze=a.n(Ze),We=a(5339),Ve=a(51474),je=a(61571),Ge=O().Block.extend({name:"attach-thumb",template:Fe(),blocks:{"react-async":Ve.Z},attrChanged:{"save-to-cloud":function(){if(this.thumbBlock)this.thumbBlock.setData(this.getParams()),this.thumbBlock.render()}},defaults:{"attach-warning-tooltip":h.ATTACH_WARNING_TOOLTIP},events:{},isImage:function(){return this.get("model").isImage()},isCloud:function(){return this.get("model").isCloud()},isDoc:function(){var e=this.get("model");return e.isPreviewFromDocs()||e.isCloudStock()},isBigAttach:function(){var e=this.get("model");return e.isLink()||e.isCloud()||e.isCloudStock()},getAttachSize:function(){var e=this.get("model");return(0,Pe.j)(e.get("size"))},getComponent:function(){var e,t=this.is("mobile-attaches");return(e=t,(0,u.pn)((function(){return a(47065)("./AttachThumb".concat(e?"Mobile":"","/AttachThumb")).then(qe.MV)})))()},getIcon:function(){return this.get("model").getExtension()},getDownloadUrl:function(){return this.get("model").getDownloadUrl()},downloadCloudAttachment:function(){var e=this.get("model");if(e.isCloud()){var t=e.get("href.download");We.default.getDownloadLink(t).then((function(e){if(e){var t=document.createElement("a");t.href=e,t.click(),t.remove()}}))}},getThumbImage:function(){if(!this.get("attach-warning-tooltip")||!this.isInfected()){var e=this.get("model"),t=e.isFromDocs()?ze().THUMBNAIL_SIZE_L:ze().THUMBNAIL_SIZE_M,a=e.getThumbnailUrl(t);if((this.is("full")||this.is("responsive")||this.is("mobile-attaches"))&&e.isImage()&&!e.isFromDocs())if(a=e.getThumbnailUrl(ze().THUMBNAIL_SIZE_ORIGINAL)||a,e.isPreviewFromDocs()||e.isCloudStock())a=e.getPreviewUrl()||a;if(!e.isFromDocs()||!e.isCloudStock())if(!h.DISABLE_DOCS_PREVIEWS||!e.isFromDocs()&&!e.isPreviewFromDocs()){if(h.ADD_O2_TOKEN_TO_ATTACHES_PREVIEW&&a)a=(0,He.oC)(a,h.O2_TOKEN_ATTACHES_WHITELIST_REGEXP_MAP).url;return a}}},getTitles:function(){var e=this.get("model");return{downloadTitle:i18n("Скачать"),downloadTooltip:i18n("Скачать")+" (".concat((0,Pe.j)(e.get("size")),")"),uploadTitle:h.ENABLE_B2B_CLOUD_NAME?i18n("В Диск"):i18n("В Облако"),uploadTooltip:h.ENABLE_B2B_CLOUD_NAME?i18n("Сохранить в Диск"):i18n("Сохранить в Облако"),mainTitle:e.get("duedate")?"".concat(e.get("name"),". ")+i18n("Ссылка доступна до")+" "+(0,N.FE)(e.get("duedate")):e.get("name")}},canOpenInCloud:function(){return!h.ONLY_DOWNLOAD_ATTACH},canSaveToCloud:function(){var e=this.get("model");return Be(e)},getParams:function(){var e=this.get("model");this.unsafe=e.isUnsafe(),this.extension=e.getExtension(),this.filename=e.getName();var t=e.isLink()||e.isCloud()||e.isCloudStock(),a=this.is("save-to-cloud")&&!e.isLink()&&(!e.isCloud()||h.ENABLE_CLONE_CLOUD_ATTACHMENTS),r=this.getThumbImage(),n=this.is("full")?i18n("Скачать"):"",i=i18n("Скачать")+" (".concat((0,Pe.j)(e.get("size")),")"),o=this.is("full")?h.ENABLE_B2B_CLOUD_NAME?i18n("В Диск"):i18n("В Облако"):"",s=h.ENABLE_B2B_CLOUD_NAME?i18n("Сохранить в Диск"):i18n("Сохранить в Облако"),l=e.get("duedate")?"".concat(e.get("name"),". ")+i18n("Ссылка доступна до")+" "+(0,N.FE)(e.get("duedate")):e.get("name"),d={isDeferred:!1,showFilenameTitle:!1,filename:{name:e.get("name")},imageUrl:r,icon:e.getExtension(),type:e.getPrimitiveType(),mainTitle:l,isDocument:r&&e.isFromDocs()&&!e.isImage(),controls:{bottom:{left:{items:[{block:"btn",params:{text:n,title:i,href:e.getDownloadUrl(),icon:"system_download",name:"download",mods:["bare"],target:e.isCloud()||h.VIEWER_OPEN_DOWNLOAD_IN_NEW_WINDOW?"_blank":je.ec}}]},right:{items:[]}}}};return a&&d.controls.bottom.left.items.push({block:"btn",params:{text:o,title:s,icon:"to-cloud",name:"cloud",mods:["bare"]}}),t&&d.controls.bottom.right.items.push({block:"btn",params:{title:l,icon:"compose_link",name:"link",mods:["bare","visible","round","green"]}}),d},sendAnalytics:function(e){this.broadcast("attachment:analytics",{models:[this.get("model")],event:e})},didMount:function(){this.onDownload=this.onDownload.bind(this),this.onCloudUpload=this.onCloudUpload.bind(this),this.onOpen=this.onOpen.bind(this),this.broadcast("thumb-item-rendered",this.get("model")),this.sendAnalytics("show")},downloadAttach:function(e){var t=this;this.broadcast("download",this.get("model")),this.sendAnalytics("download");var a=this.get("model"),r=a.isCloud(),n=r||h.VIEWER_OPEN_DOWNLOAD_IN_NEW_WINDOW?"_blank":je.ec;if(!h.LAYER_UNSAFE_ATTACH||!this.unsafe){if(h.IS_VK_MINI_APP)return e.preventDefault(),(0,Me.Wx)(this.getDownloadUrl(),a);if(h.DOWNLOAD_CLOUD_ATTACHES&&r)return this.downloadCloudAttachment();else return}we.default.open("unsafe-attach",{filename:this.filename,extension:this.extension},{dimmer:!0,compact:!0,resolvable:!0,"reject-on-close":!0}).then((function(e){if("ok"===(void 0===e?{resolveType:"error"}:e).resolveType){if(h.IS_VK_MINI_APP)return(0,Me.Wx)(t.getDownloadUrl(),a);window.open(t.getDownloadUrl(),n)}})).catch((function(e){if(e)throw e})),e.preventDefault()},onDownload:function(e){this.downloadAttach(e)},onCloudUpload:function(){if(this.get("model").isOverMaxLinkSize())return(0,Le.ZP)("big_attach_cl_save"),void Se.default.error({text:V.Du.UNKNOWN_ERROR});this.broadcast("cloud",this.get("model"))},onOpen:function(e){if(!h.ONLY_DOWNLOAD_ATTACH){this.sendAnalytics("open");var t=this.get("model"),a=t.getDownloadUrl();if(!h.IS_VK_MINI_APP)if(!(0,j.s9)())if(!t.isOverMaxLinkSize())this.broadcast("open",this.get("model"));else(0,y.default)(a);else(0,j.XT)();else(0,Me.Wx)(a,t)}else this.downloadAttach(e)},isInfected:function(){return this.get("model").isInfected()},getQaId:function(){var e=this.get("model");return"".concat(e.get("name")).concat(this.isInfected()?":infected":"")}}),Qe=a(12199),Ye=new K.Z,Ke=O().Block.extend((0,Ce.Z)({events:[{name:"attach-list-cloud",rename:"to-cloud"},"download-link","thumb-download","thumb-open","thumb-cloud"]})({name:"attach-list",template:Ne(),isolateEvents:!1,mods:{fileSize:Pe.j,fileCount:Oe.O},blocks:{"attach-thumb":Ge,ico:Qe.Z},events:{expand:"onExpandClick",collapse:"onCollapseClick","thumb-rendered":"onThumbRendered","download-link":"onDownloadLink","attaches-status-click":"onAttachesStatusClick","attaches-status-hover":"onAttachesStatusHover"},attrChanged:{expanded:function(e){var t=e?"attach-list-expanded":"attach-list-collapsed";this.broadcast(t),this.showMore()}},defaults:{models:[],"disable-save-to-cloud":h.DISABLE_SAVE_TO_CLOUD,"total-size":0,"download-link":"",itemsRendered:0,"disable-save-in-archive":h.DISABLE_SAVE_IN_ARCHIVE,"enable-b2b-cloud-name":h.ENABLE_B2B_CLOUD_NAME},didMount:function(){var e=this.showMore.bind(this);if(this.el&&Ye.set((function(){setTimeout(e,200)})),this.downloadBtn=this.el.querySelector('[data-name="download-link"]'),this.downloadBtn)this.downloadBtn.addEventListener("click",this.onDownload.bind(this),!0)},didUpdate:function(){this.broadcast("force-recalc")},didUnmount:function(){Ye.unbind()},onExpandClick:function(){this.set("expanded",!0)},onCollapseClick:function(){this.set("expanded",!1)},hasSaveToCloudAll:function(){return this.is("save-to-cloud")&&this.get("models").some(Be)},fullLimit:function(){return h.FULL_ATTACH_THUMB_LIMIT},onThumbRendered:function(e){var t=this.get("itemsRendered"),a=this.get("models").length;if(t++,this.set("itemsRendered",t,!0),t===a)this.showMore(),this.forceExpandedAttaches()},showMore:function(){var e=this.refs.thumbs,t=this.refs.container;if(e&&t)this.set("showmore",t.scrollWidth<e.scrollWidth)},forceExpandedAttaches:function(){if(this.get("showmore")&&h.FORCE_EXPANDED_ATTACH_LIST&&this.get("letter-length")<=h.FORCE_EXPANDED_ATTACHES_MAX_TEXT_LENGTH)this.set("expanded",!0),(0,Le.ZP)("force_expanded_attach-list")},isStickyEnabled:function(){return!h.IS_NATIVE_STICKY_DISABLED&&F.Z.capabilities["sticky-support"]},isMobileAttaches:function(){return h.USE_NEW_ATTACHES},isSaveBtnEnabled:function(){var e=this.attrs["download-link"],t=this.attrs.models.length>1,a=!h.DISABLE_SAVE_FOR_SINGLE_EL_ATTACHES&&!t,r=!h.DISABLE_SAVE_IN_ARCHIVE&&t;return e&&(a||r)},getDownloadTitle:function(){var e=this.get("models").length,t=i18n("Скачать");if(this.isMobileAttaches())return t+" ".concat((0,Oe.O)(e));else return 1===e?t:i18n("Скачать одним архивом")},onDownloadLink:function(e){if(this.attrs["offline-mode"])return e.preventDefault(),!1;if(this.broadcast("attachment:analytics",{models:this.get("models"),event:"download_archv"}),h.IS_VK_MINI_APP)if(e.preventDefault(),this.get("models").length>1)(0,Me.ck)(this.get("download-link"));else(0,Me.Wx)(this.get("download-link"),this.get("models")[0]);if((0,j.s9)())e.preventDefault(),(0,j.XT)()},onDownload:function(e){var t=this;if(1===this.get("models").length)if(h.LAYER_UNSAFE_ATTACH){var a=this.get("models")[0];if(a.isUnsafe()){var r=a.getExtension(),n=a.getName();we.default.open("unsafe-attach",{filename:n,extension:r},{dimmer:!0,compact:!0,resolvable:!0,"reject-on-close":!0}).then((function(e){if("ok"===(void 0===e?{resolveType:"error"}:e).resolveType)window.open(t.downloadBtn.getAttribute("href"),"download-frame")})).catch((function(e){if(e)throw e})),e.preventDefault()}}},onAttachesStatusClick:function(){l().send("attaches-status-click_action",{dwh:{reason:"click"}})},onAttachesStatusHover:function(){l().send("attaches-status-click_action",{dwh:{reason:"hover"}})}})),Xe=a(86450),$e=a(98039),Je=a(45114),et=a(18156),tt=a.n(et),at=a(75975),rt=O().Block.extend({name:"calendar-button",template:tt(),blocks:{button2:Je.Z},defaults:{model:null,"dates-metadata":null},attrChanged:{"dates-metadata":function(e){this.get("model").set("dates_metadata.priority_date",e)}},_getCalendarButtonText:function(){var e=this.get("dates-metadata"),t=L.Z.get("LANG");if(e){var a=new Date(1e3*e.timestamp),r=a.getTime()+(0,at.Z7)(a.getTimezoneOffset()),n=t.split("_")[0]||"ru",i=new Date(a.setTime(r)).toLocaleTimeString(n,{day:"numeric",month:"long",hour:"numeric",minute:"numeric"});if("ru"===n)i=i.replace(","," в");return i18n("Напомнить {dateWhen}",{dateWhen:i})}return i18n("Создать событие")},_getRadarPrefix:function(){return"footer-calendar"+(this.get("dates-metadata")?"_metadata":"")},didMount:function(){(0,Le.ZP)("thread_letter_footer-calendar_"+(this.get("dates-metadata")?"metadata-render":"render"))}}),nt=a(94993),it=a(43353),ot=function(e){for(var t="",a=!1,r=0;r<e.length;r++){var n=e[r];if(a)t+=n,a=!1;else if("\\"===n)t+=n,a=!0;else if(t+=n,r<e.length-1&&"\\"!==e[r+1])t+="\\s*"}return t},st=a(91445),lt=a(1037),dt=a(30178),ct=a(88285),mt=a.n(ct),ut=a(3505),ht=a(16244),ft=a(46855),pt=a.n(ft),bt=a(53785),gt=a(63231),vt=a(56882),_t=a(15498),yt=a(41108),Et=(he=function(e,t){return he=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(e,t){e.__proto__=t}||function(e,t){for(var a in t)if(Object.prototype.hasOwnProperty.call(t,a))e[a]=t[a]},he(e,t)},function(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Class extends value "+String(t)+" is not a constructor or null");function a(){this.constructor=e}he(e,t),e.prototype=null===t?Object.create(t):(a.prototype=t.prototype,new a)}),kt=function(){return kt=Object.assign||function(e){for(var t,a=1,r=arguments.length;a<r;a++)for(var n in t=arguments[a])if(Object.prototype.hasOwnProperty.call(t,n))e[n]=t[n];return e},kt.apply(this,arguments)},Tt=function(e,t,a){if(a||2===arguments.length)for(var r,n=0,i=t.length;n<i;n++)if(r||!(n in t)){if(!r)r=Array.prototype.slice.call(t,0,n);r[n]=t[n]}return e.concat(r||Array.prototype.slice.call(t))},wt=function(e){function t(){var t=null!==e&&e.apply(this,arguments)||this;return t.name="LazyError",t}return Et(t,e),t}(Error);function St(e){if((0,W.Tg)())(0,Le.ZP)({type:"lttr-opnng-".concat(e)})}var At={name:"letter-body",immutable:!0,template:mt(),defaults:{bodyHtml:"","body-raw":"",collapsed:null,collapsable:!0,"collapsed-default":null,"flags-threads":!1,"features-blockquote":!1,"features-blockquote-thread":!1,id:null,ponymode:!1,"quotes-formatted":[],"quotes-raw":"","quotes-mode-raw":!0,"dark-mode":!1,message:null,"current-user":null,"enable-min-width":!h.DISABLE_MIN_WIDTH},notVisualAttributes:{bodyHtml:!1},blocks:{button2:Je.Z,"html-parser":vt.Z,"letter-blockquote":_t.Z},events:{"blockquote:toggle":"onBlockquoteToggle","letter:zoom":"onLetterZoom"},attrChanged:{id:function(e,t){if(e&&t&&e!==t)this.renderBody()}},didMount:function(){var e,t=this,a=null===(e=this.get("message"))||void 0===e?void 0:e.get("size");null===gt.Z||void 0===gt.Z||gt.Z.startFromLetter(a),this.renderBody().then((0,qe.qh)(this,(function(){t.asyncDidMountRender()})))},asyncDidMountRender:function(){var e=this;if(this.isMounted()){var t=!h.IS_VK_MINI_APP;if(this.highlightCurrentUserMention(),Tt([],this.el.querySelectorAll('[data-id="tomyself"]'),!0).forEach((function(t){return e.$on(t,"click","handleClickToMyself")})),h.IS_VK_TEAMS&&h.IS_IOS)Tt([],this.el.querySelectorAll("a"),!0).forEach((function(t){if(!Object.values(h.LETTER_DATA_WHITE_LIST).some((function(e){return t.matches(e.selector)})))e.$on(t,"click","handleClickVktIOSLink")}));if(t)Object.entries(h.LETTER_DATA_WHITE_LIST).forEach((function(t){var a=t[0],r=t[1],n=null;if(r.limit&&r.limit>1)n=Array.from(e.el.querySelectorAll(r.selector)).slice(0,r.limit);else n=[e.el.querySelector(r.selector)];n.filter(Boolean).forEach((function(t){e.$on(t,"click",(function(t){if(r.preventEvent)t.preventDefault(),t.stopImmediatePropagation();e.broadcast("data-attr-click",kt(kt({},r),{type:a}),t)}))}))}))}},didUpdate:function(e){if(this.get("dark-mode")!=e["dark-mode"])this.applyDarkosha()},didUnmount:function(){if(this._darkosha)this._darkosha.destroy()},handleClickToMyself:function(e){this.broadcast("tomyselfclick",this,e),(0,Le.ZP)({type:"letter-body_myslf-btn_click"})},handleClickVktIOSLink:function(e){e.preventDefault(),e.stopPropagation(),this.broadcast("vktioslinkclick",this,e),(0,Le.ZP)({type:"letter-body_vkt-ios-link_click"})},getOrCreateDarkosha:function(){var e=this._createConfiguredDarkosha;if(!this._darkosha&&e)this._darkosha=e(this.el,this.is("dark-mode"));return this._darkosha},applyDarkosha:function(e){if(void 0===e)e=!1;if(e&&this._darkosha)this._darkosha.destroy(),this._darkosha=void 0;var t=this.getOrCreateDarkosha();if(t)if(this.is("dark-mode"))t.transform();else t.rollback()},setLetterBodyHtml:function(e){this.set("body-raw",e)},getSearchHighlightedElement:function(e){var t,a=this,r=null===(t=this.get("search"))||void 0===t?void 0:t.query.query;if(!r)return e;else return r.split(" ").flatMap(lt.G).reduce((function(e,t){var r=(0,st.x)(t);return a.highlightHtmlByQuery(e,new RegExp(ot(r),"gi"))}),e)},highlightHtmlByQuery:function(e,t){var a=e.cloneNode(!0),r=document.createElement("span"),n="data-qa-id",i=(0,dt.qa)("letter-body-search-highlight");if(i)r.setAttribute(n,i);if(pt()(a,{find:t,wrap:r,wrapClass:"letter-body_highlighted"}),i)a.querySelectorAll("[".concat(n,'="').concat(i,'"')).forEach((function(e){e.setAttribute(n,(0,dt.qa)("".concat(i,":").concat(e.textContent)))}));return a},renderBody:function(){var e=this,t=(0,v.p)().previousRoute?"warm":"cold";f.yc.time("letter-body-render"),f.yc.time("letter-body-show");var a,r=document.createElement("div"),n=this.get("bodyHtml").replace(/<base .*?>/g,""),i=(a=n.length/1024)<=30?"less_30K":a<=100?"less_100K":a<=500?"less_500K":a<=1e3?"less_1M":"more_1M",o=Promise.resolve((0,qe.Y0)().catch((function(e){return(0,d.coreLoggerDispatchError)(new wt("Lazy init error - darkosha"),{reason:e}),null}))).then((function(t){if(e.isMounted()){e._createConfiguredDarkosha=null==t?void 0:t.createConfiguredDarkosha,r.innerHTML=g(n,i,e.get("message")),f.yc.time("letter-blockquote-split");var a=yt.ZP.split(r),o=a.bodyEl,s=a.quoteEl,l=a.newQuotesFound;if(f.yc.timeEnd("letter-blockquote-split",{appendix:i,dwh:!0}),e.setLetterBodyHtml(o.innerHTML),e.rerenderParser("body-parser"),s){var d=e.is("flags-threads"),c=e.is("features-blockquote")&&!d||e.is("features-blockquote-threads")&&d;return e.el.classList.add((0,X.nZ)(".letter-body_hidden").replace(".","")),new Promise((function(t){(0,u.gl)((function(){if(e.isMounted()){var a=l&&c?"new":"old";(0,Le.ZP)(["quotes","show",a]),e.format(a,h.ENABLE_LETTER_BODY_SEARCH_HIGHLIGHT?e.getSearchHighlightedElement(s):s),e.el.classList.remove((0,X.nZ)(".letter-body_hidden").replace(".",""))}e.broadcast("force-recalc"),t()}))}))}else e.broadcast("force-recalc")}})).catch((function(e){St("fail"),(0,d.coreLoggerDispatchError)(e,null,"letter-body")}));return o.then((function(){var a;if(e.isMounted()){if(h.ENABLE_LETTER_BODY_SEARCH_HIGHLIGHT){if(null===(a=e.get("search"))||void 0===a?void 0:a.query.query){var n=yt.ZP.split(r).bodyEl;e.setLetterBodyHtml(e.getSearchHighlightedElement(n).innerHTML)}}e.applyDarkosha()}(0,bt.u)(e.el,"ltr-body"),(0,u.gl)((function(){var a,r,n,o,s;if(null===gt.Z||void 0===gt.Z||gt.Z.sendRenderRadar(),f.yc.timeEnd("letter-body-render",{score:ut.Z["letter:render"],appendix:i,dwh:!0}),f.yc.timeEnd("letter-body-show",{score:ut.Z["letter:render"],appendix:i,dwh:!0,skipPoor:!0}),f.yc.add("letter-ready",(0,ht.JW)(),void 0,{score:ut.Z["letter:ready"],appendix:t}),St("ready"),e.isMounted()&&null!=e.get("analyticsIndex")){var l=[(0,Y.mw)(e.get("analyticsIndex")),{dwh:{collapsed:!1,react:!1,amp:!1,quotesQty:null===(a=e.get("quotes-formatted"))||void 0===a?void 0:a.length,lastQuoteLength:null===(s=null===(o=null===(r=e.get("quotes-formatted"))||void 0===r?void 0:r[(null===(n=e.get("quotes-formatted"))||void 0===n?void 0:n.length)-1])||void 0===o?void 0:o.body)||void 0===s?void 0:s.length,quotesCollapsed:e.isCollapsed()},subAppendix:["exp"]}];(0,Y.Zp)("read-render-mes-self",l.concat({score:"latency"})).commit({router:(0,v.p)(),index:e.get("analyticsIndex")}),Y.zZ.timeEnd({index:e.get("analyticsIndex"),meta:l}).commit({router:(0,v.p)()})}}))})),o},format:function(e,t){var a=!1;if("new"===e)try{a=this.formatNew(t)}catch(e){(0,Le.ZP)(["quotes","error","format-new"]),a=this.formatFallback(t)}else a=this.formatFallback(t);a&&this.triggerBlockquoteChange()},truncateFormattedQuotes:function(e){var t,a,r=null===(t=this.get("message"))||void 0===t?void 0:t.get("body.html").length,n=null===(a=this.get("message"))||void 0===a?void 0:a.get("size"),i=e.map((function(e){return e.body.length})),o=i.reduce((function(e,t){return e+t}),0),s={i:kt({body:r,sum:o,eml:n},h.ENABLE_READ_QUOTES_TRUNCATE?{hit_r:1,body_r:r,sum_r:o,eml_r:n}:{hit_d:1,body_d:r,sum_d:o,eml_d:n}),dwh:{dryRun:!h.ENABLE_READ_QUOTES_TRUNCATE,quoteTotalSize:o,bodySize:r,emlSize:n}};if(l().send("read_quote_format",s),o<=h.READ_QUOTES_BYTES_LIMIT&&i.every((function(e){return e<=h.READ_BYTES_LIMIT_PER_QUOTE})))return l().send("read_quote_notrunc",s),e;var d=0,c=0,m=!1,u=!1;for(c=0;c<i.length;c+=1){if(i[c]>h.READ_BYTES_LIMIT_PER_QUOTE){m=!0;break}if(d+i[c]>h.READ_QUOTES_BYTES_LIMIT){u=!0;break}d+=i[c]}var f=o-d,p=i[c-1],b=i[c],g={i:kt(kt(kt({},s.i),{all:u?1:0,one:m?1:0,acc:d,trunc:f,last:null!=p?p:-1,next:b}),h.ENABLE_READ_QUOTES_TRUNCATE?{all_r:u?1:0,one_r:m?1:0,acc_r:d,trunc_r:f,last_r:null!=p?p:-1,next_r:b}:{all_d:u?1:0,one_d:m?1:0,acc_d:d,trunc_d:f,last_d:null!=p?p:-1,next_d:b}),dwh:kt(kt({},s.dwh),{hasLimitOverflow:u,hasTooLargeQuote:m,accQuoteSize:d,truncatedSize:f,lastQuoteSize:p,nextQuoteSize:b,idx:c})};if(l().send("read_quote_trunc",g),h.ENABLE_READ_QUOTES_TRUNCATE)return e.slice(0,c);else return e},formatNew:function(e){var t,a=yt.ZP.format(e);try{var r=null===(t=this.get("message"))||void 0===t?void 0:t.get("body.html").length;if((h.ENABLE_READ_QUOTES_TRUNCATE_ONLY_ANALYTICS||h.ENABLE_READ_QUOTES_TRUNCATE)&&r>=h.READ_QUOTES_BYTES_LIMIT)a=this.truncateFormattedQuotes(a)}catch(e){(0,d.coreLoggerDispatchError)(e,null)}return this.set({collapsable:this.is("flags-threads"),"quotes-mode-raw":!1,"quotes-formatted":a}),0!==a.length},formatFallback:function(e){if(e){var t=yt.ZP.formatFallback(e);return this.set({collapsable:this.is("flags-threads"),"quotes-mode-raw":!0,"quotes-raw":t}),this.rerenderParser("quote-parser"),""!==t}},rerenderParser:function(e){try{this.ids[e].rerender()}catch(t){(0,Le.ZP)(["letter-body","error",e])}},isCollapsed:function(){var e=this.get("collapsed");if(null==e)return this.is("collapsed-default");else return e},triggerBlockquoteChange:function(){this.broadcast("resize")},onBlockquoteToggle:function(){if(this.set("collapsed",!this.isCollapsed()),this.triggerBlockquoteChange(),this.applyDarkosha(!0),!this.isCollapsed())this.asyncDidMountRender()},onLetterZoom:function(){this.broadcast("resize")},highlightCurrentUserMention:function(){var e=ke.default.user.getEmail();this.el.querySelectorAll("a[data-mention]").forEach((function(t){if(t.dataset.mentionEmail===e)t.classList.add("highlighted"),t.setAttribute("data-test-highlighted","true")}))}},Ct=O().Block.extend(At),Lt=a(6889),xt=a.n(Lt),It=O().Block.extend((0,Ce.Z)({id:"amp",events:["mount","error"]})({name:"letter-body-amp",template:xt(),didUpdate:function(e){if(e["dark-mode"]!==this.attrs["dark-mode"]&&this.AMPViewer)this.AMPViewer.setTheme(this.is("dark-mode"))},didMount:function(){var e,t=this,a=this.get("model"),r=a&&a.get("body.amp");if(r)this._fallbackPixel=h.AMP_SENDER_METRICS&&a&&(null===(e=a.get("meta"))||void 0===e?void 0:e.find((function(e){return e&&"object"==typeof e&&"http://schema.org"===e["@context"]&&"Action"===e["@type"]&&"AMP4Email"===e.agent&&"ValidationError"===e.name&&"string"==typeof e.url}))),(0,qe.fA)().then((0,qe.qh)(this,(function(e){var a,n=e.createAmpViewer;if(t.isMounted()){if(t.AMPViewer=n({iframeSrc:h.AMP_IFRAME_PATH,cdnHost:"amp-lib/",proxyHost:h.AMP_PROXY_HOST,debug:h.IS_DEBUG,timeout:h.AMP_TIMEOUT,errorRadars:!0,senderMetrics:{fallback:null===(a=t._fallbackPixel)||void 0===a?void 0:a.url}}),t.AMPViewer.setup(),t.AMPViewer.on("error",t.handleError.bind(t)),t.AMPViewer.on("navigate",t.handleNavigate.bind(t)),t.AMPViewer.on("radar",t.handleRadar.bind(t)),t.AMPViewer.on("resize",(function(){if(null!=t.get("analyticsIndex")){var e=[(0,Y.mw)(t.get("analyticsIndex")),{dwh:{collapsed:!1,react:!1,amp:!0},subAppendix:["amp"]}];(0,Y.Zp)("read-render-mes-self",e.concat({score:"latency"})).commit({router:(0,v.p)(),index:t.get("analyticsIndex")}),Y.zZ.timeEnd({index:t.get("analyticsIndex"),meta:e}).commit({router:(0,v.p)()})}})),t.el.appendChild(t.AMPViewer.iframe),t.AMPViewer.onChangeCssSelectorTheme((function(e){t.broadcast("change-css-selector-theme",e)})),t.AMPViewer.setTheme(t.is("dark-mode")),t.AMPViewer.loadLetter({content:r,fromEmail:t.getFromEmail(),toEmail:t.getToEmail()}),t._fallbackPixel)l().send("amp_fallback_pixel-exists");t.broadcast("force-recalc")}})));else this.broadcast("error")},getFromEmail:function(){return this.get("model").get("correspondents.from.0.email")},getToEmail:function(){var e=ke.default.user;return e&&e.getEmail()},didUnmount:function(){if(this.AMPViewer)this.AMPViewer.teardown()},handleError:function(e){var t=this;h.IS_DEBUG&&console.error("Error from AMP Viewer",e);var a=this.getFromEmail(),r=this.getToEmail();if((0,d.coreLoggerDispatchIgnoredError)("amp-error",e,{from:"amp-log-error",fromEmail:a,toEmail:r}),/^(js|timeout|validation|message_parse|lib_untrusted)$/.test(e.type))window.setTimeout((function(){if(t._fallbackPixel)l().send("amp_fallback_tracked");else l().send("amp_fallback_untracked");t.broadcast("error")}),1)},handleNavigate:function(e){var t=e.href,a=document.createElement("a");if(a.href=t,!a.hostname)t=h.AMP_REDIRECT_URL;(0,y.default)(t)},handleRadar:function(e){var t=this.getFromEmail();(0,Le.ZP)({type:"amp_".concat(e.t),intervals:e.i,value:void 0===e.v?1:e.v,dwh:{fromEmail:t}})}})),Rt=a(96284),Mt=a.n(Rt),Ot=function(e,t,a,r){return new(a||(a=Promise))((function(n,i){function o(e){try{l(r.next(e))}catch(e){i(e)}}function s(e){try{l(r.throw(e))}catch(e){i(e)}}function l(e){var t;e.done?n(e.value):(t=e.value,t instanceof a?t:new a((function(e){e(t)}))).then(o,s)}l((r=r.apply(e,t||[])).next())}))},Pt=function(e,t){var a,r,n,i={label:0,sent:function(){if(1&n[0])throw n[1];return n[1]},trys:[],ops:[]},o=Object.create(("function"==typeof Iterator?Iterator:Object).prototype);return o.next=s(0),o.throw=s(1),o.return=s(2),"function"==typeof Symbol&&(o[Symbol.iterator]=function(){return this}),o;function s(s){return function(l){return function(s){if(a)throw new TypeError("Generator is already executing.");for(;o&&(o=0,s[0]&&(i=0)),i;)try{if(a=1,r&&(n=2&s[0]?r.return:s[0]?r.throw||((n=r.return)&&n.call(r),0):r.next)&&!(n=n.call(r,s[1])).done)return n;if(r=0,n)s=[2&s[0],n.value];switch(s[0]){case 0:case 1:n=s;break;case 4:return i.label++,{value:s[1],done:!1};case 5:i.label++,r=s[1],s=[0];continue;case 7:s=i.ops.pop(),i.trys.pop();continue;default:if(!(n=i.trys,(n=n.length>0&&n[n.length-1])||6!==s[0]&&2!==s[0])){i=0;continue}if(3===s[0]&&(!n||s[1]>n[0]&&s[1]<n[3])){i.label=s[1];break}if(6===s[0]&&i.label<n[1]){i.label=n[1],n=s;break}if(n&&i.label<n[2]){i.label=n[2],i.ops.push(s);break}if(n[2])i.ops.pop();i.trys.pop();continue}s=t.call(e,i)}catch(e){s=[6,e],r=0}finally{a=n=0}if(5&s[0])throw s[1];return{value:s[0]?s[1]:void 0,done:!0}}([s,l])}}},Dt=O().Block.extend({name:"letter-calendar",template:Mt(),defaults:{html:"","dark-mode":!1},didUpdate:function(e){if(this.get("dark-mode")!=e["dark-mode"])this.applyDarkosha()},didUnmount:function(){if(this._darkosha)this._darkosha.destroy()},didMount:function(){var e=this.get("calendars");if(e.length){var t=e.map((function(e){return e.html}));this.set("html",t.join("<br/>")),this.applyDarkosha()}},getOrCreateDarkosha:function(){return Ot(this,void 0,Promise,(function(){var e;return Pt(this,(function(t){switch(t.label){case 0:if(this._darkosha)return[3,2];else return[4,(0,qe.Y0)()];case 1:e=t.sent().createConfiguredDarkosha,this._darkosha=e(this.el,this.is("dark-mode")),t.label=2;case 2:return[2,this._darkosha]}}))}))},applyDarkosha:function(e){var t=this;if(void 0===e)e=!1;if(e&&this._darkosha)this._darkosha.destroy(),this._darkosha=void 0;this.getOrCreateDarkosha().then((function(e){if(e)if(t.is("dark-mode"))e.transform();else e.rollback()}))}}),Nt=a(43148),Bt=a.n(Nt),qt=a(4706),Ut=O().Block.extend({name:"letter-category",template:Bt(),blocks:{badge:$e.Z},defaults:{name:"default",title:"",ico:""},getIco(){var e=qt.r[this.get("name")];return e&&e.ico},getText(){var e=qt.r[this.get("name")];return this.get("text")||e&&e.text},getTitle(){var e=qt.r[this.get("name")];return e&&e.text}}),Ft=a(62593),Ht=a.n(Ft),Zt=a(96130),zt=a(72656),Wt=O().Block.extend((0,Ce.Z)({id:"confirm-receipt",events:[{name:"confirmreceipt",data:void 0}]})({name:"letter-confirm-receipt",defaults:{"hide-help-link":h.CONFIRM_RECEIPT_HELP,"help-link":h.CONFIRM_RECEIPT_HELP_URL},template:Ht(),blocks:{"button-link":Zt.Z,ico:Qe.Z,link:zt.Z}})),Vt=a(37240),jt=a(12889),Gt=a(21528),Qt=a(50421),Yt=a(19275),Kt=a(22023),Xt=a(50733),$t=a(7005),Jt=a.n($t),ea=a(75705),ta=a(31150),aa=a(75943),ra=a(66423),na=a.n(ra),ia=a(74456),oa=function(){return oa=Object.assign||function(e){for(var t,a=1,r=arguments.length;a<r;a++)for(var n in t=arguments[a])if(Object.prototype.hasOwnProperty.call(t,n))e[n]=t[n];return e},oa.apply(this,arguments)},sa=O().Block.extend({name:"letter-meta",template:Jt(),defaults:{html:"",showSkeleton:!1},loadingPlateTimer:null,constructor:function(){O().Block.apply(this,arguments),this.destroyElementOnError=this.destroyElementOnError.bind(this),this.destroySkeleton=this.destroySkeleton.bind(this)},didMount:function(){var e;if(h.TRACKING_STATUS_PLATE&&(null===(e=this.get("model").get("transaction_metadata"))||void 0===e?void 0:e.get("statement_status")))l().send("appl_state_plate_letter_open")},didUnmount:function(){this.unrenderUI(),clearTimeout(this.loadingPlateTimer),this.refs.container.removeEventListener("letter-meta-loaded",this.destroySkeleton),this.refs.container.removeEventListener("letter-meta-loading-err",this.destroyElementOnError)},didUpdate:function(){if(this.ui){var e=this.getParams();if(e)this.ui.update(e)}},attrChanged:{model:function(){this.renderUI()}},getParams:function(){var e,t=this.get("model");if(!t&&h.LOG_LETTER_META_MODEL_ERROR)return(0,d.coreLoggerDispatchError)(new Error("Undefined model in letter meta params"),oa({},this.attrs)),!1;var a=this.get("metadata")?this.get("metadata").getAttributes():null,r=null==t?void 0:t.get("messages"),n=this.is("ponymode"),o=this.is("dark-mode"),s=this.get("sender"),l=this.is("compact")||this.is("touch"),c=ke.default.user,m=this.get("calendar"),u=this.get("promoDomainPlate"),f=this.get("needHideAttach"),p=this.get("autoTaskMatchedRegexp"),b=this.get("router.model.uiLayout")||Kt.ce,g=b&&"3pane"===b.type&&b.support3pane,v=(0,Xt.$)();return{model:t,features:Gt.default,flags:i(),cfg:Yt.Z,storage:xe.ZP,octavius:!0,lang:L.Z.get("LANG"),email:c&&c.getEmail(),calendar:m,onPopupToggle:this.onPopupToggle,selector:X.nZ,dataSourceDispatch:H.default,metadata:a,message:t,messages:r,ponymode:n,isCompact:l,is3Pane:g,darkMode:o,sender:s,icsWithAttachToggle:f,onStatusClick:this.onStatusClick.bind(this),promoDomainPlate:u,onPromoDomainClose:this.onPromoDomainClose.bind(this),onBlockPhishingLetter:this.onBlockPhishingLetter.bind(this),onActualFeedback:this.onActualFeedback.bind(this),onEternalDislike:this.onEternalDislike.bind(this),onNewsletterMailingPlateChoice:this.onNewsletterMailingPlateChoice.bind(this),onCategoryFeedback:this.onCategoryFeedback.bind(this),onCategoryFeedbackPlateShow:this.onCategoryFeedbackPlateShow.bind(this),onWindowOpen:this.onWindowOpen,onAttachesCloudSave:this.onAttachesCloudSave.bind(this),onBlockFilteredLetter:this.onBlockFilteredLetter.bind(this),onApproveFilteredLetter:this.onApproveFilteredLetter.bind(this),createSmartCardConfirmPopup:this.createSmartCardConfirmPopup.bind(this),onSmartCardError:this.onSmartCardError.bind(this),onPromoPushPlateShow:this.onPromoPushPlateShow.bind(this),onPromoPush:this.onPromoPush.bind(this),onPromoPushSettings:this.onPromoPushSettings.bind(this),onDeleteMLCardSuccess:this.onDeleteMLCardSuccess.bind(this),onDeleteMLCardError:this.onDeleteMLCardError.bind(this),onToggleIcsAttachClick:this.onToggleIcsAttachClick.bind(this),onOverQuotaWarningMailBuyClick:this.onOverQuotaWarningMailBuyClick.bind(this),onOverQuotaWarningMailMemoryClick:this.onOverQuotaWarningMailMemoryClick.bind(this),MailGettersMessageMeta:be,RPC:na(),isMobile:h.TOUCH_MODE,autoTaskMatchedRegexp:p,quotaDays:v.days_left||0,isOverquotaLocked:!!v.locked,overquotaMode:h.OVERQUOTA_MODE,cloudOverquotaState:v.cloudOverquotaState,cloudOverquotaSpace:(0,Qt.I)((0,jt._p)(-v.free_quota,3)),cloudOverquotaLockDate:(0,B.p6)((null===(e=v.cloudOverquotaState)||void 0===e?void 0:e.lockTime)||0,[["day","numeric"],["month","long"]])}},renderUI:function(){var e=this;this.unrenderUI();var t=performance.now(),a=ke.default.user,r=this.is("dark-mode"),n={message:this.get("model"),features:Gt.default,promoDomainPlate:this.get("promoDomainPlate"),sender:this.get("sender"),type:this.get("type"),hasAutoTask:this.get("hasAutoTask")};if(this.get("needSkeleton")&&!this.loadingPlateTimer)this.waitForLoadingPlate();(0,ia.Z)("letter.meta").then((function(t){return e.isMounted()&&t&&t(oa({loadPath:window.require.toUrl("letter.meta.js").replace("letter.meta.js",""),email:a&&a.getEmail(),darkMode:r,MailGettersMessageMeta:be},n))})).then((function(a){if(!a||!e.isMounted())return!1;e.ui=new a(e.refs.container);var r=e.getParams();if(!r)return!1;e.ui.renderWrapper(oa(oa({},r),{timingStart:t,timingNow:function(){return performance.now()}}));var n=e.refs.container.children.length;Ae.default.update(),e.broadcast("render",{showed:n})}))},unrenderUI:function(){this.ui&&this.ui.destroy(),this.ui=null},onPopupToggle:function(e){var t=this;(0,qe.BA)().then((function(a){if("object"==typeof t)(0,qe.qh)(t,(function(){a.setScope(e?"layer-no-shortcuts":"all")}));else l().send("uniqCallbackType",{rlog:"uniqCallbackType",rlog_message:{keyType:typeof t}})}))},onStatusClick:function(e){this.broadcast("letterclick",{uidl:e})},onPromoDomainClose:function(){this.broadcast("promodomainclose")},onBlockPhishingLetter:function(){var e=this.get("model");this.broadcast("spam",{model:e})},onOverQuotaWarningMailBuyClick:function(){var e,t=(0,Xt.$)();if(null===(e=t.cloudOverquotaState)||void 0===e?void 0:e.isOverquota)return(0,ta.g)(t.cloudOverquotaState,"banner-read-letters");(0,ta.y)()},onOverQuotaWarningMailMemoryClick:function(){(0,y.default)(h.OVERQUOTA_LANDING_CLEANER_URL)},onActualFeedback:function(e){var t=this.get("model");na().call("messages/services/ispriority",{ids:[t.get("messages.0.id")],is_priority:e})},onEternalDislike:function(e,t){var a=this.get("model");na().call("messages/services/ispriority",{ids:[a.get("messages.0.id")],is_priority:t,permanent_priority:!0})},onCategoryFeedbackPlateShow:function(e){var t;if(h.USE_QUEUE_CATEGORY_FEEDBACK_PLATE){var a=xe.ZP.get("letter.meta-category-feedback-shows")||{};if(null===(t=this.get("onShowCategoryFeedbackPlate"))||void 0===t||t(),!a.hasOwnProperty(e))a[e]={countShows:0,time:0};a[e].countShows++,a[e].time=(0,ea.V)(),xe.ZP.set("letter.meta-category-feedback-shows",a)}},onNewsletterMailingPlateChoice:function(e){var t=this.get("model"),a=(xe.ZP.get("newsletter-mailing-choiced-list")||"").split(","),r=t.get("correspondents.from.0.email");a.push(r),xe.ZP.set("newsletter-mailing-choiced-list",a.join(","));var n=e?V.Du.NEWSLETTER_CONFIRMED:V.Du.SUCCESS_UNSUBSCRIBE;Se.default.success({text:n,qa:"newsletter-mailing-plate-choice-".concat(e?"sub":"unsub")})},onCategoryFeedback:function(e,t){var a=this.get("model");if(!t)na().call("messages/services/category/feedback",{id:a.get("messages.0.id"),category:e});else na().call("messages/services/category/feedback",{id:a.get("messages.0.id"),other_category:t})},onWindowOpen:function(e){(0,y.default)(e)},onAttachesCloudSave:function(){this.broadcast("attaches-cloud-save",this.get("model").getAttachmentsList())},onBlockFilteredLetter:function(){l().send("rl_btn_block"),this.broadcast("move",{id:h.PARENTAL_CONTROL_DENY_FOLDER_ID,model:this.get("model")})},onApproveFilteredLetter:function(){l().send("rl_btn_approve"),this.broadcast("move",{id:h.PARENTAL_CONTROL_APPROVE_FOLDER_ID,model:this.get("model")})},createSmartCardConfirmPopup:function(e,t){var a=this;Promise.all([(0,ia.Z)("blitz")]).then((function(r){var n=r[0].LayerManager;if(a.isMounted()){var i=a.layerManager||new n;i.setup(a.el,{popup:!1,radarPrefix:"smart-card"});var o=i.openLayer(E.createElement(e,oa(oa({},t),{onClose:function(){if(t.onClose(),i)i.destroyLayer(o)}})),{noPanelWrap:!0,responsive:"auto"}).id}}))},onSmartCardError:function(){Se.default.add({type:h.VKUI_SNACKBAR_NOTIFY&&Se.NotifyType.ERROR,text:V.Du.TRY_LATER,qa:"clnd-smart-card-notify-err"})},onPromoPushPlateShow:function(){if(h.USE_QUEUE_PROMO_PUSH_PLATE){var e=+xe.ZP.get("letter.meta-promo-push-show")||0;xe.ZP.set("letter.meta-promo-push-show",e+1)}},onPromoPush:function(e,t){var a;return null===(a=(0,v.p)().model.swBox.pushManager)||void 0===a?void 0:a.forCurrentEmail().set({active:!0}).then((function(){l().send(["notifications-push","switch","on"],{dwh:{source:"letter-promo"}}),Se.default.success({text:e})})).catch((function(e){l().send(["notifications-push","switch","error"],{rlog:"push-switch-error",rlog_message:{error:e,on:!0}}),Se.default.error({text:t})}))},onPromoPushSettings:function(){aa.default.onSettingsDockBrowserSettingsOpen()},onDeleteMLCardSuccess:function(){Se.default.success({text:V.Du.REMOVED_FROM_CALENDAR,qa:"clnd-ml-card-del-success"}),this.unrenderUI()},onDeleteMLCardError:function(){Se.default.add({type:h.VKUI_SNACKBAR_NOTIFY&&Se.NotifyType.ERROR,text:V.Du.TRY_LATER,qa:"clnd-ml-card-del-err"})},waitForLoadingPlate:function(){this.set("showSkeleton",!0),this.loadingPlateTimer=setTimeout(this.destroyElementOnError,h.LETTER_META_SKELETON_WAIT_TIMEOUT),this.refs.container.addEventListener("letter-meta-loaded",this.destroySkeleton),this.refs.container.addEventListener("letter-meta-loading-err",this.destroyElementOnError)},onSkeletonMount:function(){l().send("lm-skeleton-show")},destroySkeleton:function(){clearTimeout(this.loadingPlateTimer),this.loadingPlateTimer=null,this.set("showSkeleton",!1)},destroyElementOnError:function(){l().send("lm-skeleton-destroy",{rlog:"calendar_smart_card_logs",rlog_message:{message:"skeleton-destroy-on-timeout",letterId:this.get("model").id}}),this.destroySkeleton()},onToggleIcsAttachClick:function(e){this.broadcast("toggle-ics",{isOpen:e})}}),la=a(45069),da=a(48254),ca=a.n(da),ma=O().Block.extend((0,Ce.Z)({events:["close","action"]})({name:"letter-tooltip",isolateEvents:!0,template:ca(),blocks:{button:Je.Z,"button-link":Zt.Z},defaults:{ponymode:!1,mobile:!1,"is-webview":h.WEBVIEW,"is-octavius-mobile":h.OCTAVIUS_MOBILE},isWebviewMobileMode:function(){return this.attrs.mobile&&(this.attrs["is-webview"]||this.attrs["is-octavius-mobile"])}})),ua=a(56302),ha=a(95470),fa=a(52950),pa=a(93798),ba=a.n(pa),ga=(a(88018),a(55426)),va=a(70045),_a=a.n(va),ya=a(5830),Ea=a.n(ya),ka=a(93185),Ta=[{key:Ea().RUSSIAN,text:i18n("Русский")},{key:Ea().ENGLISH,text:i18n("Английский")},{key:Ea().GERMAN,text:i18n("Немецкий")},{key:Ea().FRENCH,text:i18n("Французский")},{key:Ea().SPANISH,text:i18n("Испанский")}],wa={};Ta.forEach(((e,t)=>{e.index=t,wa[e.key]=e}));var Sa=O().Block.extend({name:"translator-select",isolateEvents:!0,template:_a(),blocks:{button2:Je.Z,select:ka.Z},defaults:{selected:null,disabled:!1,"disabled-item":null,ponymode:!1},getText(e){return this.get("containerRef").clientWidth>=660?e:"".concat(e.slice(0,3),".")},getItems(){return Ta},getSelectedIndex(){return this.getIndexByValue(this.get("selected"))},getDisabledIndex(){return this.getIndexByValue(this.get("disabled-item"))},getIndexByValue(e){var t=wa[e];return t&&t.index}}),Aa=O().Block.extend((0,Ce.Z)({events:["hide","close","original","retry","translate","reverse"]})({name:"translator",isolateEvents:!0,template:ba(),blocks:{list:ua.Z,listItem:ha.Z,dropdown:nt.Z,button2:Je.Z,"button-link":Zt.Z,ico:Qe.Z,spinner:ga.Z,"translator-select":Sa},events:{"from:change":"onFromChange","to:change":"onToChange","translate:click":"onTranslateClick","reverse:click":"onReverse","dropdown-close:click":"onTranslatorDropdownClose","button-close:click":"onTranslatorButtonClose","hide:click":"onTranslatorHide","dropdown-change":"onTranslatorCloseDropdownClick"},defaults:{error:!1,"from-selected":"ru","from-default-selected":"ru",loading:!1,ponymode:!1,"to-selected":"en",translated:!1,"is-translator-visible":!1},getText(){if(this.is("error"))return i18n("Попробовать ещё раз");if(this.is("translated"))return i18n("Оригинал");else return i18n("Перевести")},onReverse(){this.broadcast("reverse");var e=this.getTo(),t=this.getFrom();if(!h.DISABLE_AUTOMATED_TRANSLATE)this.set({"from-selected":e,"to-selected":t}),this.translate();else this.set({"from-selected":e,"to-selected":t,translated:!1})},onFromChange(e){var t=e.details;if(!h.DISABLE_AUTOMATED_TRANSLATE)this.set("from-selected",t.key),this.translate();else this.set({"from-selected":t.key,translated:!1})},onToChange(e){var t=e.details;if(!h.DISABLE_AUTOMATED_TRANSLATE)this.set("to-selected",t.key),this.translate();else this.set({translated:!1,"to-selected":t.key})},onTranslatorCloseDropdownClick(e){if(e.details.state)l().send("translator_close-dropdown_click")},onTranslatorButtonClose(){l().send("translator_close-button_click"),this.broadcast("close")},onTranslatorDropdownClose(){l().send("translator_close-dropdown_close_click"),this.broadcast("close")},onTranslatorHide(){l().send("translator_close-dropdown_hide_click"),this.broadcast("hide")},onTranslateClick(){if(!this.is("error"))if(this.is("translated"))this.showOriginal();else l().send("letter_manual_translate",{dwh:{disableAutomatedTranslate:h.DISABLE_AUTOMATED_TRANSLATE,letterId:this.get("letterId")}}),this.translate();else this.retry()},getTo(){return this.get("to-selected")},getEnableHideTranslator(){return h.ENABLE_HIDE_TRANSLATOR&&!this.get("is-translator-visible")},getFrom(){return this.get("from-selected")},retry(){this.broadcast("retry",{tolang:this.getTo(),fromlang:this.getFrom()})},showOriginal(){this.broadcast("original",{tolang:this.getTo(),fromlang:this.getFrom()})},translate(){var e=this.getTo(),t=this.getFrom();if(e&&t)this.broadcast("translate",{tolang:e,fromlang:t})},didMount(){this.set("from-selected",this.get("from-default-selected")),this.set("to-selected",this.get("to-default-selected")),this.render()}})),Ca=a(10794),La=a(85232),xa=a(9901),Ia=a(2979),Ra=a(73794),Ma=new Ra.kZ("html-expander");function Oa(){return k().createElement("div",{className:Ma.root(),ref:this.ref.htmlExpander},this.props.default.call(this,void 0))}var Pa=function(){var e=function(t,a){return e=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(e,t){e.__proto__=t}||function(e,t){for(var a in t)if(Object.prototype.hasOwnProperty.call(t,a))e[a]=t[a]},e(t,a)};return function(t,a){if("function"!=typeof a&&null!==a)throw new TypeError("Class extends value "+String(a)+" is not a constructor or null");function r(){this.constructor=t}e(t,a),t.prototype=null===a?Object.create(a):(r.prototype=a.prototype,new r)}}(),Da=function(e){function t(){var t=null!==e&&e.apply(this,arguments)||this;return t.ref={htmlExpander:k().createRef()},t.render=Oa,t}return Pa(t,e),t.prototype.init=function(){var e=this.ref.htmlExpander.current.getBoundingClientRect().width;if(this.handleImageClick=this.handleImageClick.bind(this),this.handleImageButtonClick=this.handleImageButtonClick.bind(this),this.handleTableClick=this.handleTableClick.bind(this),this.handleTableButtonClick=this.handleTableButtonClick.bind(this),this.handleItemZoom=this.handleItemZoom.bind(this),this.props.tables)this.tablesExpander=new Ia.Z({isTogglerVisible:this.props["tables-popup"],isDefaultZoomOut:this.props["tables-default-zoomout"]}),this.tablesExpander.on("item:click",this.handleTableClick),this.tablesExpander.on("button:click",this.handleTableButtonClick),this.tablesExpander.on("zoomin",this.handleItemZoom),this.tablesExpander.on("zoomout",this.handleItemZoom),this.tablesExpander.prepare(this.ref.htmlExpander.current,e);if(this.props.images)this.imagesExpander=new xa.Z({isTogglerVisible:this.props["images-popup"],isDefaultZoomOut:this.props["images-default-zoomout"]}),this.imagesExpander.on("item:click",this.handleImageClick),this.imagesExpander.on("button:click",this.handleImageButtonClick),this.imagesExpander.on("zoomin",this.handleItemZoom),this.imagesExpander.on("zoomout",this.handleItemZoom),this.imagesExpander.prepare(this.ref.htmlExpander.current,e)},t.prototype.deinit=function(){if(this.imagesExpander)this.imagesExpander.off("item:click",this.handleImageClick),this.imagesExpander.off("button:click",this.handleImageButtonClick),this.imagesExpander.off("zoomin",this.handleItemZoom),this.imagesExpander.off("zoomout",this.handleItemZoom),this.imagesExpander.reset();if(this.tablesExpander)this.tablesExpander.off("item:click",this.handleTableClick),this.tablesExpander.off("button:click",this.handleTableButtonClick),this.tablesExpander.off("zoomin",this.handleItemZoom),this.tablesExpander.off("zoomout",this.handleItemZoom),this.tablesExpander.reset()},t.prototype.handleItemZoom=function(){(0,Ca.pd)(this).broadcast("zoom")},t.prototype.handleTableClick=function(e){if(e.isSmall)this.tablesExpander.zoomIn(e)},t.prototype.handleTableButtonClick=function(e){this.openInLayer(e)},t.prototype.handleImageClick=function(e){if(!e.isLink)this.imagesExpander.toggleZoom(e)},t.prototype.handleImageButtonClick=function(e){this.openInLayer(e)},t.prototype.openInLayer=function(e){we.default.open("html-viewer",{content:e.clone.outerHTML,"dark-mode":this.props["dark-mode"]},{dimmer:!0,"dimmer-color":"dark",fullscreen:!0})},t.defaultProps={images:h.IMAGES_EXPANDER,"images-default-zoomout":!0,"images-popup":h.IMAGES_EXPANDER_POPUP,tables:h.TABLES_EXPANDER,"tables-default-zoomout":!0,"tables-popup":h.TABLES_EXPANDER_POPUP},t}(k().Component),Na=(0,Ca.v$)("html-expander",Da,{syncMediatorsOnRender:!0,skipModelUpdatesSubscription:!1}),Ba=a(49589),qa=a(57579),Ua=new Ra.kZ("html-fishing");function Fa(){return k().createElement("div",{className:Ua.root(),ref:this.ref.bodyFishing},this.props.default.call(this,void 0))}var Ha=function(){var e=function(t,a){return e=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(e,t){e.__proto__=t}||function(e,t){for(var a in t)if(Object.prototype.hasOwnProperty.call(t,a))e[a]=t[a]},e(t,a)};return function(t,a){if("function"!=typeof a&&null!==a)throw new TypeError("Class extends value "+String(a)+" is not a constructor or null");function r(){this.constructor=t}e(t,a),t.prototype=null===a?Object.create(a):(r.prototype=a.prototype,new r)}}(),Za=function(e){function t(){var t=null!==e&&e.apply(this,arguments)||this;return t.render=Fa,t.ref={bodyFishing:k().createRef()},t}return Ha(t,e),t.prototype.init=function(){this.onLinkClick=this.onLinkClick.bind(this),this.onLinkMouseDown=this.onLinkMouseDown.bind(this),this.onFormSubmit=this.onFormSubmit.bind(this),this.ref.bodyFishing.current.addEventListener("click",this.onLinkClick),this.ref.bodyFishing.current.addEventListener("mousedown",this.onLinkMouseDown),this.ref.bodyFishing.current.addEventListener("submit",this.onFormSubmit),this.removeLinksFromBody()},t.prototype.deinit=function(){if("function"==typeof this.onLinkClick||"object"==typeof this.onLinkClick)this.ref.bodyFishing.current.removeEventListener("click",this.onLinkClick),this.ref.bodyFishing.current.removeEventListener("mousedown",this.onLinkMouseDown),this.ref.bodyFishing.current.removeEventListener("submit",this.onFormSubmit);else if(h.LOG_FISHING_DEINIT_ERROR)l().send("fishing_deinit_error",{rlog:"fishing_errors",rlog_message:{onLinkClick:typeof this.onLinkClick,onLinkMouseDown:typeof this.onLinkMouseDown,keys:Object.keys(this)}})},t.prototype.getLink=function(e){for(;e&&e!==this.ref.bodyFishing.current;){if("a"===e.tagName.toLowerCase())return e;e=e.parentElement}},t.prototype.onLinkMouseDown=function(e){if(!(e.which>2)){var t=this.getLink(e.target);if(t)qa.ZP.revertUrl(t)}},t.prototype.onFormSubmit=function(e){e.preventDefault()},t.prototype.onLinkClick=function(e){var t=this.getLink(e.target);if(t){var a=qa.ZP.verify(t,{sync:!0});if(a===qa.ZP.ERROR_HASH_URL||a===qa.ZP.ERROR_EMPTY_URL)return!0;e.preventDefault();var r=this.props.message;qa.ZP.go(t,(0,Ba.D)(r),r.get("correspondents.from")[0].email)}},t.prototype.removeLinksFromBody=function(){var e=this.ref.bodyFishing.current.querySelectorAll("a");qa.ZP.removeRedirectFromLinks(e)},t}(k().Component),za=(0,Ca.v$)("html-fishing",Za,{syncMediatorsOnRender:!0,skipModelUpdatesSubscription:!1}),Wa=function(){return Wa=Object.assign||function(e){for(var t,a=1,r=arguments.length;a<r;a++)for(var n in t=arguments[a])if(Object.prototype.hasOwnProperty.call(t,n))e[n]=t[n];return e},Wa.apply(this,arguments)},Va=new Ra.kZ("html-parser");function ja(){var e=Wa(Wa({},this.props),this.state);return k().createElement(Na,{id:"expander",ref:this.expander,"dark-mode":e["dark-mode"],default:Ga.bind(this)})}function Ga(){var e=Wa(Wa({},this.props),this.state);return k().createElement("div",{dangerouslySetInnerHTML:{__html:e.content}})}function Qa(){var e=Wa(Wa({},this.props),this.state).message;return k().createElement("div",{className:Va.root(),ref:this.ref.parser},k().createElement(za,{id:"fishing",ref:this.fishing,message:e,default:ja.bind(this)}))}var Ya=function(){var e=function(t,a){return e=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(e,t){e.__proto__=t}||function(e,t){for(var a in t)if(Object.prototype.hasOwnProperty.call(t,a))e[a]=t[a]},e(t,a)};return function(t,a){if("function"!=typeof a&&null!==a)throw new TypeError("Class extends value "+String(a)+" is not a constructor or null");function r(){this.constructor=t}e(t,a),t.prototype=null===a?Object.create(a):(r.prototype=a.prototype,new r)}}(),Ka=function(e){function t(t){var a=e.call(this,t)||this;return a.ref={parser:k().createRef()},a.render=Qa,a.fishing=k().createRef(),a.expander=k().createRef(),a}return Ya(t,e),t.prototype.componentDidMount=function(){this.applyDarkosha(),this.modifyImageSrc(),null===gt.Z||void 0===gt.Z||gt.Z.add(this.ref.parser.current)},t.prototype.componentWillUnmount=function(){this.expander.current.deinit(),this.fishing.current.deinit()},t.prototype.applyDarkosha=function(){var e=this.props.darkosha;if(e)e.isolateSubtree(this.ref.parser.current)},t.prototype.modifyImageSrc=function(){if(h.ADD_O2_TOKEN_TO_ATTACHES_PREVIEW)(0,He.Xw)(this.ref.parser.current,h.O2_TOKEN_ATTACHES_WHITELIST_REGEXP_MAP)},t.prototype.rerender=function(){this.expander.current.deinit(),this.fishing.current.deinit(),this.expander.current.init(),this.fishing.current.init(),this.applyDarkosha()},t.defaultProps={content:"",message:null,darkosha:void 0},t}(k().Component),Xa=(0,Ca.v$)("html-parser",Ka,{syncMediatorsOnRender:!0,skipModelUpdatesSubscription:!1}),$a=a(88897),Ja=a(94881),er=function(){return er=Object.assign||function(e){for(var t,a=1,r=arguments.length;a<r;a++)for(var n in t=arguments[a])if(Object.prototype.hasOwnProperty.call(t,n))e[n]=t[n];return e},er.apply(this,arguments)},tr=new Ra.kZ("letter-blockquote"),ar=(0,Ca.kF)((function(){return Promise.resolve().then(a.bind(a,35517))}),"LetterHeader","letterHeader",null);function rr(){var e=er(er({},this.props),this.state),t=e.message,a=e.search,r=e.blockquote,n=e.letterShowEmail,i=e.showBlockquotesCorrespondentsList,o=e.blockquoteCorrespondentsEnabled;return k().createElement("div",{"data-qa-id":(0,dt.qa)("letter-blockquote"),className:tr.root({first:0===e.index,ponymode:e.ponymode}),ref:this.ref.letterBlockquote},!!r.isSenderFully&&k().createElement("div",{className:tr.elem("header",{offset:o})},!i&&k().createElement(k().Fragment,null,k().createElement($a.q,{size:"s",src:r.avatar,anonymous:r.anonymous}),n?k().createElement(k().Fragment,null,!!r.email&&k().createElement("span",{"data-qa-id":(0,dt.qa)("name"),className:tr.elem("name")},r.email),!!r.name&&k().createElement("span",{"data-qa-id":(0,dt.qa)("name"),className:tr.elem("email",{anonymous:r.anonymous})},"( ",r.name,")")):k().createElement(k().Fragment,null,!!r.name&&k().createElement("span",{"data-qa-id":(0,dt.qa)("name"),className:tr.elem("name",{anonymous:r.anonymous})},r.name),!!r.email&&k().createElement("span",{"data-qa-id":(0,dt.qa)("email"),className:tr.elem("email")},this.mods.addBrackets(r.email))),k().createElement("time",{"data-qa-id":(0,dt.qa)("time"),className:tr.elem("time")},this.mods.letterAttachLinkDate(r.timestamp))),!!i&&k().createElement(ar,{"class-name":"header-wrapper",message:t,correspondents:this.getCorrespondents(),compact:e.compact,isOnline:e.isOnline,touch:e.touch,ponyMode:e.ponymode,showFolder:e.showfolder,hasAmp:e.hasAmp,search:a,hasAmpErrors:e.hasAmpErrors,previewMode:e["preview-mode"],disableEdit:e["disable-edit"],disableCategory:e["disable-category"],detailsExpanded:e["details-expanded"],showExtendedCorrespondentsList:!0,currentUser:e["current-user"],avatar:this.getAvatar(),isBlockquote:!0,timestamp:r.timestamp})),k().createElement("div",{"data-qa-id":(0,dt.qa)("body"),className:tr.elem("body")},k().createElement(Xa,{id:"parser",ref:this.parser,content:r.body,darkosha:e.darkosha,message:t,remitEvents:{zoom:"blockquote-zoom"},updateRemitEventsName:!0,broadcastEvent:(0,Ca.Yv)(this)})),k().createElement(Ja.Z,null))}var nr=function(){var e=function(t,a){return e=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(e,t){e.__proto__=t}||function(e,t){for(var a in t)if(Object.prototype.hasOwnProperty.call(t,a))e[a]=t[a]},e(t,a)};return function(t,a){if("function"!=typeof a&&null!==a)throw new TypeError("Class extends value "+String(a)+" is not a constructor or null");function r(){this.constructor=t}e(t,a),t.prototype=null===a?Object.create(a):(r.prototype=a.prototype,new r)}}(),ir=function(){return ir=Object.assign||function(e){for(var t,a=1,r=arguments.length;a<r;a++)for(var n in t=arguments[a])if(Object.prototype.hasOwnProperty.call(t,n))e[n]=t[n];return e},ir.apply(this,arguments)},or=function(e){function t(t){var a=e.call(this,t)||this;return a.state={letterShowEmail:false,showBlockquotesCorrespondentsList:!1,blockquoteCorrespondentsEnabled:h.SHOW_BLOCKQUOTES_EXTENDED_CORRESPONDENTS_LIST},a.ref={letterBlockquote:k().createRef()},a.render=rr,a.mods={letterAttachLinkDate:N.FE,addBrackets:function(e){return"<".concat(e,">")}},a.parser=k().createRef(),a}return nr(t,e),t.prototype.componentDidMount=function(){this.rerender(),this.triggerAttrChanged(ir(ir({},t.defaultProps),this.state))},t.prototype.componentDidUpdate=function(e,t){this.triggerAttrChanged(ir(ir({},e),t))},t.prototype.rerender=function(){(0,bt.u)(this.ref.letterBlockquote.current,"blq"),this.parser.current&&this.parser.current.rerender()},t.prototype.getAvatar=function(){return this.props.blockquote.avatar},t.prototype.getCorrespondents=function(){return{from:[this.props.blockquote.from],to:this.props.blockquote.to,cc:this.props.blockquote.copy}},t.prototype.triggerAttrChanged=function(e){var a=ir(ir({},this.props),this.state);if(e.blockquote!==a.blockquote)t.attrChanged.blockquote.call(this,a.blockquote,e.blockquote)},t.defaultProps={blockquote:{},"dark-mode":!1,index:0,ponymode:!1},t.attrChanged={blockquote:function(e){this.setState({showBlockquotesCorrespondentsList:e.hasExtendedCorrespondents})}},t}(k().Component),sr=(0,Ca.v$)("letter-blockquote",or,{syncMediatorsOnRender:!0,skipModelUpdatesSubscription:!1}),lr=function(){return lr=Object.assign||function(e){for(var t,a=1,r=arguments.length;a<r;a++)for(var n in t=arguments[a])if(Object.prototype.hasOwnProperty.call(t,n))e[n]=t[n];return e},lr.apply(this,arguments)},dr=new Ra.kZ("letter-body");function cr(){var e=this,t=lr(lr({},this.props),this.state),a=!(!t["quotes-raw"]&&!t["quotes-formatted"].length),r=t["body-raw"],n=t["dark-mode"],i=t.message,o=t.search;return k().createElement("div",{"data-qa-id":(0,dt.qa)("letter-body"),ref:this.ref.letterBody,className:dr.root({mobile:t.mobile,"formatted-quotes":!(t["quotes-mode-raw"]||!t["quotes-formatted"].length),"raw-quotes":!(!t["quotes-mode-raw"]||!t["quotes-raw"]),quotes:a,"dark-mode":n,"enable-min-width":t["enable-min-width"]})},k().createElement("div",{"data-qa-id":(0,dt.qa)("body"),className:dr.elem("body",{"no-scroll":t["preview-mode"]})},k().createElement("div",{ref:this.ref.body,className:dr.elem("body-wrapper")},k().createElement("div",{tabIndex:-1,ref:this.ref.jsBody,className:dr.elem("body-content")},!!r&&k().createElement(Xa,{id:"body-parser",ref:this.bodyParser,content:r,darkosha:this.getOrCreateDarkosha(),message:i,"dark-mode":n,analyticsIndex:t.analyticsIndex,remitEvents:{zoom:"letter:zoom"},updateRemitEventsName:!0,broadcastEvent:(0,Ca.Yv)(this)})))),!!a&&k().createElement(k().Fragment,null,!!t.collapsable&&k().createElement("div",{className:dr.elem("badge")},k().createElement(La.S,{badge:!0,secondary:!0,ico:"navigation:more","data-qa-id":(0,dt.qa)("blockquote-toggler"),centered:!0,onClick:this.onBlockquoteToggle.bind(this)})),!t.collapsable&&k().createElement("div",{"data-qa-id":(0,dt.qa)("blockquote-title"),className:dr.elem("title")},i18n("вся переписка")),k().createElement("div",{ref:this.ref.blockquotes,"data-qa-id":(0,dt.qa)("blockquotes"),className:dr.elem("blockquotes")},!(t.collapsable&&this.isCollapsed())&&k().createElement(k().Fragment,null,!!t["quotes-mode-raw"]&&k().createElement("div",{"data-qa-id":(0,dt.qa)("raw"),className:dr.elem("blockquotes-raw")},k().createElement(Xa,{id:"quote-parser",ref:this.quoteParser,content:t["quotes-raw"],darkosha:this.getOrCreateDarkosha(),message:i})),!t["quotes-mode-raw"]&&t["quotes-formatted"].map((function(a,r){return k().createElement(sr,{key:r,index:r,blockquote:a,ponymode:t.ponymode,message:i,search:o,darkosha:e.getOrCreateDarkosha(),useMediators:["user-info"],remitEvents:{"blockquote-zoom":"letter:zoom"},updateRemitEventsName:!0,broadcastEvent:(0,Ca.Yv)(e)})}))))))}var mr=function(){var e=function(t,a){return e=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(e,t){e.__proto__=t}||function(e,t){for(var a in t)if(Object.prototype.hasOwnProperty.call(t,a))e[a]=t[a]},e(t,a)};return function(t,a){if("function"!=typeof a&&null!==a)throw new TypeError("Class extends value "+String(a)+" is not a constructor or null");function r(){this.constructor=t}e(t,a),t.prototype=null===a?Object.create(a):(r.prototype=a.prototype,new r)}}(),ur=function(){return ur=Object.assign||function(e){for(var t,a=1,r=arguments.length;a<r;a++)for(var n in t=arguments[a])if(Object.prototype.hasOwnProperty.call(t,n))e[n]=t[n];return e},ur.apply(this,arguments)},hr=function(e){function t(){var t=null!==e&&e.apply(this,arguments)||this;return t.name="LazyError",t}return mr(t,e),t}(Error);function fr(e){if((0,W.Tg)())(0,Le.ZP)({type:"lttr-opnng-".concat(e)})}var pr=function(e){function t(t){var a=e.call(this,t)||this;return a.state={"quotes-raw":"","quotes-formatted":[],"body-raw":"","quotes-mode-raw":!0,"enable-min-width":!h.DISABLE_MIN_WIDTH,collapsable:!0,collapsed:null,"flags-threads":!1,"features-blockquote":!1,"features-blockquote-threads":!1,mobile:!1},a.render=cr,a.ref={body:k().createRef(),jsBody:k().createRef(),blockquotes:k().createRef(),letterBody:k().createRef()},a.notVisualAttributes={bodyHtml:!1},a.events={"blockquote:toggle":"onBlockquoteToggle","letter:zoom":"onLetterZoom"},a.bodyParser=k().createRef(),a.quoteParser=k().createRef(),a}return mr(t,e),Object.defineProperty(t.prototype,"el",{get:function(){return this.ref.letterBody.current},enumerable:!1,configurable:!0}),Object.defineProperty(t.prototype,"ids",{get:function(){var e={};if(this.bodyParser.current)e["body-parser"]=this.bodyParser.current;if(this.quoteParser.current)e["quote-parser"]=this.quoteParser.current;return e},enumerable:!1,configurable:!0}),t.prototype.componentDidMount=function(){var e,a=this,r=null===(e=this.props.message)||void 0===e?void 0:e.get("size");null===gt.Z||void 0===gt.Z||gt.Z.startFromLetter(r),this.renderBody().then((0,qe.qh)(this,(function(){a.asyncDidMountRender()}))),this.triggerAttrChanged(ur(ur({},t.defaultProps),this.state))},t.prototype.componentDidUpdate=function(e,t){if(this.props["dark-mode"]!=e["dark-mode"])this.applyDarkosha();this.triggerAttrChanged(ur(ur({},e),t))},t.prototype.componentWillUnmount=function(){if(this._darkosha)this._darkosha.destroy()},t.prototype.asyncDidMountRender=function(){var e=this,t=!h.IS_VK_MINI_APP;if(this.highlightCurrentUserMention(),h.IS_VK_TEAMS&&h.IS_IOS)Array.from(this.el.querySelectorAll("a")).forEach((function(t){if(!Object.values(h.LETTER_DATA_WHITE_LIST).some((function(e){return t.matches(e.selector)})))t.addEventListener("click",e.handleClickVktIOSLink)}));if(t)Object.entries(h.LETTER_DATA_WHITE_LIST).forEach((function(t){var a=t[0],r=t[1],n=null;if(r.limit&&r.limit>1)n=Array.from(e.el.querySelectorAll(r.selector)).slice(0,r.limit);else n=[e.el.querySelector(r.selector)];n.filter(Boolean).forEach((function(t){t.addEventListener("click",(function(t){if(r.preventEvent)t.preventDefault(),t.stopImmediatePropagation();(0,Ca.pd)(e).broadcast("data-attr-click",ur(ur({},r),{type:a}),t)}))}))}))},t.prototype.handleClickToMyself=function(e){(0,Ca.pd)(this).broadcast("tomyselfclick",this,e),(0,Le.ZP)({type:"letter-body_myslf-btn_click"})},t.prototype.handleClickVktIOSLink=function(e){e.preventDefault(),e.stopPropagation(),(0,Ca.pd)(this).broadcast("vktioslinkclick",this,e),(0,Le.ZP)({type:"letter-body_vkt-ios-link_click"})},t.prototype.getOrCreateDarkosha=function(){var e=this._createConfiguredDarkosha;if(!this._darkosha&&e)this._darkosha=e(this.el,this.props["dark-mode"]);return this._darkosha},t.prototype.applyDarkosha=function(e){if(void 0===e)e=!1;if(e&&this._darkosha)this._darkosha.destroy(),this._darkosha=void 0;var t=this.getOrCreateDarkosha();if(t)if(this.props["dark-mode"])t.transform();else t.rollback()},t.prototype.highlightHtmlByQuery=function(e,t){var a=e.cloneNode(!0),r=document.createElement("span"),n="data-qa-id",i=(0,dt.qa)("letter-body-search-highlight");if(i)r.setAttribute(n,i);if(pt()(a,{find:t,wrap:r,wrapClass:"letter-body_highlighted"}),i)a.querySelectorAll("[".concat(n,'="').concat(i,'"')).forEach((function(e){e.setAttribute(n,(0,dt.qa)("".concat(i,":").concat(e.textContent)))}));return a},t.prototype.getSearchHighlightedElement=function(e){var t,a=this,r=null===(t=this.props.search)||void 0===t?void 0:t.query.query;if(!r)return e;else return r.split(" ").flatMap(lt.G).reduce((function(e,t){var r=(0,st.x)(t);return a.highlightHtmlByQuery(e,new RegExp(ot(r),"gi"))}),e)},t.prototype.setLetterBodyHtml=function(e){this.setState({"body-raw":e})},t.prototype.renderBody=function(){var e=this,t=(0,v.p)().previousRoute?"warm":"cold";f.yc.time("letter-body-show");var a,r=document.createElement("div"),n=this.props.bodyHtml.replace(/<base .*?>/g,""),i=(a=n.length/1024)<=30?"less_30K":a<=100?"less_100K":a<=500?"less_500K":a<=1e3?"less_1M":"more_1M",o=Promise.resolve((0,qe.Y0)().catch((function(e){return(0,d.coreLoggerDispatchError)(new hr("Lazy init error - darkosha"),{reason:e}),null}))).then((function(t){e._createConfiguredDarkosha=null==t?void 0:t.createConfiguredDarkosha,r.innerHTML=g(n,i,e.props.message),f.yc.time("letter-blockquote-split");var a=yt.ZP.split(r),o=a.bodyEl,s=a.quoteEl,l=a.newQuotesFound;if(f.yc.timeEnd("letter-blockquote-split",{appendix:i,dwh:!0}),e.setLetterBodyHtml(o.innerHTML),e.rerenderParser("body-parser"),s){var d=e.state["flags-threads"],c=e.state["features-blockquote"]&&!d||e.state["features-blockquote-threads"]&&d;return e.el.classList.add((0,X.nZ)(".letter-body_hidden").replace(".","")),new Promise((function(t){(0,u.gl)((function(){var a=l&&c?"new":"old";(0,Le.ZP)(["quotes","show",a]),e.format(a,h.ENABLE_LETTER_BODY_SEARCH_HIGHLIGHT?e.getSearchHighlightedElement(s):s),e.el.classList.remove((0,X.nZ)(".letter-body_hidden").replace(".","")),(0,Ca.pd)(e).broadcast("force-recalc"),t()}))}))}else(0,Ca.pd)(e).broadcast("force-recalc")})).catch((function(e){fr("fail"),(0,d.coreLoggerDispatchError)(e,null,"letter-body")}));return o.then((function(){var a;if(h.ENABLE_LETTER_BODY_SEARCH_HIGHLIGHT){if(null===(a=e.props.search)||void 0===a?void 0:a.query.query){var n=yt.ZP.split(r).bodyEl;e.setLetterBodyHtml(e.getSearchHighlightedElement(n).innerHTML)}}e.applyDarkosha(),(0,bt.u)(e.el,"ltr-body"),(0,u.gl)((function(){var a,r,n,o,s;if(null===gt.Z||void 0===gt.Z||gt.Z.sendRenderRadar(),f.yc.timeEnd("letter-body-render",{score:ut.Z["letter:render"],appendix:i,dwh:!0}),f.yc.timeEnd("letter-body-show",{score:ut.Z["letter:render"],appendix:i,dwh:!0,skipPoor:!0}),f.yc.add("letter-ready",(0,ht.JW)(),void 0,{score:ut.Z["letter:ready"],appendix:t}),fr("ready"),null!=e.props.analyticsIndex){var l=[(0,Y.mw)(e.props.analyticsIndex),{dwh:{collapsed:!1,react:!1,amp:!1,quotesQty:null===(a=e.state["quotes-formatted"])||void 0===a?void 0:a.length,lastQuoteLength:null===(s=null===(o=null===(r=e.state["quotes-formatted"])||void 0===r?void 0:r[(null===(n=e.state["quotes-formatted"])||void 0===n?void 0:n.length)-1])||void 0===o?void 0:o.body)||void 0===s?void 0:s.length,quotesCollapsed:e.isCollapsed()},subAppendix:["exp"]}];(0,Y.Zp)("read-render-mes-self",l.concat({score:"latency"})).commit({router:(0,v.p)(),index:e.props.analyticsIndex}),Y.zZ.timeEnd({index:e.props.analyticsIndex,meta:l}).commit({router:(0,v.p)()})}}))})),o},t.prototype.format=function(e,t){var a=!1;if("new"===e)try{a=this.formatNew(t)}catch(e){(0,Le.ZP)(["quotes","error","format-new"]),a=this.formatFallback(t)}else a=this.formatFallback(t);a&&this.triggerBlockquoteChange()},t.prototype.truncateFormattedQuotes=function(e){var t,a,r=null===(t=this.props.message)||void 0===t?void 0:t.get("body.html").length,n=null===(a=this.props.message)||void 0===a?void 0:a.get("size"),i=e.map((function(e){return e.body.length})),o=i.reduce((function(e,t){return e+t}),0),s={i:ur({body:r,sum:o,eml:n},h.ENABLE_READ_QUOTES_TRUNCATE?{hit_r:1,body_r:r,sum_r:o,eml_r:n}:{hit_d:1,body_d:r,sum_d:o,eml_d:n}),dwh:{dryRun:!h.ENABLE_READ_QUOTES_TRUNCATE,quoteTotalSize:o,bodySize:r,emlSize:n}};if(l().send("read_quote_format",s),o<=h.READ_QUOTES_BYTES_LIMIT&&i.every((function(e){return e<=h.READ_BYTES_LIMIT_PER_QUOTE})))return l().send("read_quote_notrunc",s),e;var d=0,c=0,m=!1,u=!1;for(c=0;c<i.length;c+=1){if(i[c]>h.READ_BYTES_LIMIT_PER_QUOTE){m=!0;break}if(d+i[c]>h.READ_QUOTES_BYTES_LIMIT){u=!0;break}d+=i[c]}var f=o-d,p=i[c-1],b=i[c],g={i:ur(ur(ur({},s.i),{all:u?1:0,one:m?1:0,acc:d,trunc:f,last:null!=p?p:-1,next:b}),h.ENABLE_READ_QUOTES_TRUNCATE?{all_r:u?1:0,one_r:m?1:0,acc_r:d,trunc_r:f,last_r:null!=p?p:-1,next_r:b}:{all_d:u?1:0,one_d:m?1:0,acc_d:d,trunc_d:f,last_d:null!=p?p:-1,next_d:b}),dwh:ur(ur({},s.dwh),{hasLimitOverflow:u,hasTooLargeQuote:m,accQuoteSize:d,truncatedSize:f,lastQuoteSize:p,nextQuoteSize:b,idx:c})};if(l().send("read_quote_trunc",g),h.ENABLE_READ_QUOTES_TRUNCATE)return e.slice(0,c);else return e},t.prototype.formatNew=function(e){var t,a=yt.ZP.format(e);try{var r=null===(t=this.props.message)||void 0===t?void 0:t.get("body.html").length;if((h.ENABLE_READ_QUOTES_TRUNCATE_ONLY_ANALYTICS||h.ENABLE_READ_QUOTES_TRUNCATE)&&r>=h.READ_QUOTES_BYTES_LIMIT)a=this.truncateFormattedQuotes(a)}catch(e){(0,d.coreLoggerDispatchError)(e,null)}return this.setState({collapsable:this.state["flags-threads"],"quotes-mode-raw":!1,"quotes-formatted":a}),0!==a.length},t.prototype.formatFallback=function(e){if(e){var t=yt.ZP.formatFallback(e);return this.setState({collapsable:this.state["flags-threads"],"quotes-mode-raw":!0,"quotes-raw":t}),this.rerenderParser("quote-parser"),""!==t}},t.prototype.rerenderParser=function(e){try{this.ids[e].rerender()}catch(t){(0,Le.ZP)(["letter-body","error",e])}},t.prototype.isCollapsed=function(){var e=this.state.collapsed;if(null==e)return this.props["collapsed-default"];else return e},t.prototype.triggerBlockquoteChange=function(){(0,Ca.pd)(this).broadcast("resize")},t.prototype.onBlockquoteToggle=function(){if(this.setState({collapsed:!this.isCollapsed()}),this.triggerBlockquoteChange(),this.applyDarkosha(!0),!this.isCollapsed())this.asyncDidMountRender()},t.prototype.onLetterZoom=function(){(0,Ca.pd)(this).broadcast("resize")},t.prototype.highlightCurrentUserMention=function(){var e=ke.default.user.getEmail();this.el.querySelectorAll("a[data-mention]").forEach((function(t){if(t.dataset.mentionEmail===e)t.classList.add("highlighted"),t.setAttribute("data-test-highlighted","true")}))},t.prototype.triggerAttrChanged=function(e){var a=ur(ur({},this.props),this.state);if(e.id!==a.id)t.attrChanged.id.call(this,a.id,e.id)},t.defaultProps={"dark-mode":!1,message:null,ponymode:!1,id:null,"collapsed-default":null,bodyHtml:"","current-user":null},t.attrChanged={id:function(e,t){if(e&&t&&e!==t)this.renderBody()}},t}(k().PureComponent),br=(0,Ca.v$)("letter-body",pr,{syncMediatorsOnRender:!0,skipModelUpdatesSubscription:!0}),gr=a(54908),vr=a(83260),_r=a.n(vr),yr=function(){return yr=Object.assign||function(e){for(var t,a=1,r=arguments.length;a<r;a++)for(var n in t=arguments[a])if(Object.prototype.hasOwnProperty.call(t,n))e[n]=t[n];return e},yr.apply(this,arguments)},Er=(0,K.Z)(),kr={head:{offsetSide:"top",offsetPadding:"paddingTop",className:"letter__head"},footer:{offsetSide:"bottom",offsetPadding:"paddingBottom",className:"letter__footer"}},Tr=(0,u.pn)((function(){return a.e(9689).then(a.bind(a,9689))})),wr=(0,u.pn)((function(){return Promise.resolve().then(a.bind(a,35517))})),Sr={name:"letter",template:U(),isolateEvents:!1,updateLastSeenUnsubscribe:null,mods:{correspondent:D.k0,correspondentsCount:D.zW,getLocaleDateFull:N.BY,getAdaptiveCorrespondentsList:D.b5},isFooterHiddenRadarSended:!1,isSmartReplyHiddenRadarSended:!1,isUpmetricPromoParseErrorRadarSended:!1,isUpmetricPromoDeadlineErrorRadarSended:!1,blocks:{avatar:Xe.Z,"attach-list":Ke,badge:$e.Z,button2:Je.Z,"calendar-button":rt,dropdown:nt.Z,"dropdown-actions":it.Z,"letter-calendar":Dt,"letter-body":Ct,"letter-confirm-receipt":Wt,"letter-contact":Vt.Z,"letter-body-amp":It,"letter-category":Ut,"letter-status2":la.Z,"letter-tooltip":ma,translator:Aa,ico:Qe.Z,"letter-meta":sa,list:ua.Z,"list-item":ha.Z,"marusia-rl-button":fa.Z},components:{LetterBody:br,UpmetricPromo:A},lazyBlocks:{unsubscribe:qe.mV},lazyLetterShareDropdown:Tr,events:{"attaches:cloud:all":"onAttachmentsCloud","attaches:cloud:one":"onAttachmentCloud","attaches:open":"onAttachmentClick",clickavatar:"onContactShow","contact:click":"onContactShow","details:expand":"onToggleDetails","letter:body:allowedattrclick":"onAllowedAttrClick","letter:body:data-attr:click":"onLetterDataAttributeClick","letter:body:tomyself":"onToMyselfClick","letter:draft:forward":"onLetterComposeFromDraft","letter:draft:reply":"onLetterComposeFromDraft","letter:draft:replyall":"onLetterComposeFromDraft","letter:revoke":"onLetterRevoke","letter:replace":"onLetterReplace","translator:close:click":"onTranslatorClose","translator:hide:click":"onTranslatorHide","translator:original:click":"onTranslatorOriginal","translator:retry:click":"onTranslatorTranslate","translator:translate:click":"onTranslatorTranslate","letter-tooltip:show-images:click":"onTooltipShowImagesClick","letter-tooltip:close":"onTooltipClose","amp:error":"onAmpError","dark-mode:toggle":"onDarkModeToggle","calls:groupcall":"onCallTo","save:notes":"saveNotes","details:collapse":"onToggleDetails","vk-messenger:open":"onVkMessengerOpen","amp:change-css-selector-theme":"setCssSelectorThemeAMP","chat:create":"onCreateChat","letter:body:vktioslinkclick":"onVktIOSLinkClick"},defaults:{"disable-category":!0,"hover-support":F.Z.capabilities["hover-support"],"native-sticky":!h.IS_READLETTER_NATIVE_STICKY_DISABLED,"is-translator-error":!1,"is-translator-visible":!1,"is-translator-loading":!1,"is-translator-forced-shown":!1,"is-automated-show-translator-radar-send":!1,"is-letter-in-english-radar-send":!1,"is-letter-translated":!1,model:null,"dates-metadata":null,ponymode:!1,"quotes-collapsed-default":!0,"smart-reply-on":!0,sticky:null,"sticky-head":!1,"sticky-footer":!1,"enable-body-scale":!1,"max-scale":.5,"enable-amp":h.ENABLE_AMP,"feature-unsubscribe":h.FEATURE_UNSUBSCRIBE,"enable-notes-button":h.ENABLE_SAVE_NOTE_BUTTON,"default-enable-save-note-button":h.DEFAULT_ENABLE_SAVE_NOTE_BUTTON,"disable-translate":h.DISABLE_TRANSLATE,"disable-create-event":h.DISABLE_CREATE_EVENT,"share-letter":h.ENABLE_LETTER_SHARING_FROM_HEAD,"disable-head-calendar":h.DISABLE_LETTER_HEAD_CALENDAR,"disable-head-print":h.DISABLE_HEAD_PRINT,"disable-calendar-newsletters":h.DISABLE_LETTER_CALENDAR_NEWSLETTERS,"disable-call-newsletters":!1,"disable-footer-calendar":h.DISABLE_LETTER_FOOTER_CALENDAR,"disable-call":!1,"enable-tags":h.ENABLE_TAGS,"enable-revoke-letter":h.ENABLE_REVOKE_LETTER,"translator-default-from":"en","translator-default-to":"ru","amp-error":!1,isThemedAMP:!0,"address-header-calendar":h.ADDRESS_HEADER&&h.ADDRESS_HEADER_CALENDAR,"dark-mode-enabled":!0,"category-feedback":h.CATEGORY_FEEDBACK_SUBMENU,"is-tooltip-visible":!0,"marusia-read-all-letters":h.MARUSIA_READ_ALL_LETTERS,"smart-card-ics":h.SMART_CARD_ICS,"show-attach-safety-status":h.SHOW_ATTACH_SAFETY_STATUS,"has-attach-safety-status-background":h.HAS_ATTACH_SAFETY_STATUS_BACKGROUND,"attach-safety-status-position":h.ATTACH_SAFETY_STATUS_POSITION,"show-extended-correspondents-list":h.SHOW_EXTENDED_CORRESPONDENTS_LIST,"use-react-letter-header":h.USE_REACT_LETTER_HEADER,recipientsData:{showTo:[],showCc:[],moreCountText:""},"offline-mode":!1},attrChanged:{model:function(e){var t=this;if(window.setTimeout((function(){var t=e.get("attaches").list;(0,Le.ZP)("letter_attaches",t.length);try{!function(e){var t=e.map((function(e){var t=e.get("name"),a=e.get("content_type"),r=a===ee||a===te,n=oe,i=!1;switch(!0){case t.endsWith("."+ae):n=ae,i=t===le&&a===ee;break;case t.endsWith("."+re):n=re,i=t===de&&a===te;break;case t.endsWith("."+ne):n=ne,i=t===ce&&a===ee;break;case t.endsWith("."+ie):n=ie,i=t===me&&a===ee}if(r||n!==oe)return{contentType:a,filename:t,extension:n,specCompliant:i};else return null})).filter((function(e){return!!e}));if(0!==t.length)if(!(t.length>1)){var a=t[0],r=[];if(a.specCompliant)r.push("spec");else r.push("nospec");if(r.push(a.extension),ue.includes(a.filename))r.push(a.filename.replace(".",""));switch(a.contentType){case ee:r.push("pkcs7mime_".concat(a.extension));break;case te:r.push("pkcs7sig_".concat(a.extension))}l().send("smime",{i:r})}else l().send("smime",{i:["many"]})}(t)}catch(e){}}),500),this.isSmartRepliesAvailable(e)){this.set("smart_replies_ready",!!e.getSmartReply());var a=e.is("flags.smart_reply_stage")?"_stage":"";(0,Le.ZP)("smart_replies"+a+"_try-show"),e.fetchSmartReply().then((function(e){if(t.set("smart_replies",e.get("replies")),(0,Le.ZP)("smart_replies"+a+"_show"),e.is("is_default"))(0,Le.ZP)("smart_replies_default"+a+"_show");Ae.default.update()}),(function(){(0,Le.ZP)("smart_replies"+a+"_show-fail")}))}},sticky:function(e,t){if(e=e||{},(t=t||{}).head!==e.head)this.updateSticky("head",e.top,e.headFade,!!e.maxWidth);if(t.footer!==e.footer)this.updateSticky("footer",e.bottom,e.footerFade,!!e.maxWidth)},"sticky-position":function(e){var t=this.get("sticky");if(t)this.updateSticky("head",t.top,!1,!!e.maxWidth),this.updateSticky("footer",t.bottom,!1,!!e.maxWidth)},"dates-metadata":function(e){this.get("model").set("dates_metadata.priority_date",e)},"details-expanded":function(){if(this.attrs["show-extended-correspondents-list"]&&this.attrs["current-user"])this.setMessageCorrespondentsAdaptive()},"current-user":function(e){if(this.attrs["show-extended-correspondents-list"]&&e)this.setMessageCorrespondentsAdaptive()}},constructor:function(){if(O().Block.apply(this,arguments),this.texts={to:i18n("Кому"),cc:i18n("Копия"),bcc:h.SHOW_EXTENDED_CORRESPONDENTS_LIST?i18n("СК"):i18n("Скрытая"),more:i18n("и ещё"),hide:i18n("Скрыть список")},null!=this.get("analyticsIndex"))(0,Y.it)("read-render-mes-self").commit({router:(0,v.p)(),index:this.get("analyticsIndex")})},lazyLetterHeader:wr,getOriginalEvent:function(e){return this.reactComponent?e.originalEvent:e.originalEvent.originalEvent||e.originalEvent},updateOnlineStatus:function(e){if(e&&h.LETTER_LASTSEEN_REQUEST){var t=e.status_id===h.LASTSEEN_ONLINE_STATUS;l().send("lastseen-v2-letter-".concat(t?"online":"offline"),{skipdwh:!0}),this.set("isOnline",t)}},updateSenderLastSeen:function(){var e=this;if(h.LETTER_LASTSEEN_REQUEST){var t=this.get("model").get("correspondents.from.0"),a=this.get("getLastSeen");null==a||a([t.email]).then((function(a){var r=a.payload[t.email];e.updateOnlineStatus(r)}))}},_windowResizeListeners:{},didMount:function(){var e=this,t=this.get("model");this.updateSenderLastSeen(),this._showSaveNotesButton();var a=this.getMessageCorrespondents().concat(t.get("correspondents").from||[]).map((function(e){return e.email}));this.broadcast("addressbook:refetchcontacts",a),this._sendVkMessengerEvent("open_mail_with_vk_messenger");var r=this.updateOnlineStatus.bind(this);if(this.updateLastSeenUnsubscribe=c.l.fulfilled.subscribe((function(e){var a=e.payload;if(null==a?void 0:a.contacts){var n=t.get("correspondents.from.0"),i=a.contacts[n.email];if(i)r(i)}})),this.updateStickyStatus=this.updateStickyStatus.bind(this),this.stickyDisabled=!1,!this.is("readonly")){var n=$("scrollable_content"),i=$("panel-with-selected"),o=this.el.closest(n)||this.el.closest(i);if(!o){var s=this.get("router");if(!document.contains(this.el))l().send("lttr-rsz-obsrvr");else(0,d.coreLoggerDispatchSelfError)("lttr-rsz-obsrvr",new Error('element parameter is not of type "Element"'),{routeId:s&&s.route&&s.route.id,smokeScreenServiceEnabled:X.ZP.isEnabled(),isPreviewMode:this.is("preview-mode"),hasScrollableContent:!!this.el.closest(".scrollable_content"),hasPanelWithSelected:!!this.el.closest(".panel-with-selected"),scrollableContentSelector:n,panelWithSelectedSelector:i,hasBlockInDOM:document.contains(this.el)});return void setTimeout((function(){(0,d.coreLoggerDispatchError)(new Error('element parameter is not of type "Element" more'),{hasBlockInDOM:document.contains(e.el)},{category:"lttr-rsz-more",tag:d.Tag.Known})}),1050)}this.adaptiveHandler=new Z.O({pureBreakpoints:!0,breakpoints:[{conditions:function(e){return t.is("attaches.list.length")&&t.checkGrant(pe().SHARE_GRANTS.view_attachment)?e.height<h.MIN_LETTER_HEIGHT_STICKY_WITH_ATTACHES:e.height<h.MIN_LETTER_HEIGHT_STICKY},props:{element:"footer",disableSticky:!0,position:0,fade:!this.get("sticky")}},{props:{element:"footer",disableSticky:!1,position:0,fade:!this.get("sticky")}}],onResize:this.updateStickyStatus,element:o})}if(this.attrs["show-extended-correspondents-list"])this.setMessageCorrespondentsAdaptiveDebounced=_r().debounce(this.setMessageCorrespondentsAdaptive,h.RESIZE_UPDATE_DEBOUNCE_TIME,this),window.addEventListener("resize",this.setMessageCorrespondentsAdaptiveDebounced)},didUnmount:function(){var e,t,a=this;if(Object.keys(this._windowResizeListeners).forEach((function(e){return a._stopStickyTracking(a._windowResizeListeners[e])})),Er.unbind(),null===(e=this.updateLastSeenUnsubscribe)||void 0===e||e.call(this),null===(t=this.adaptiveHandler)||void 0===t||t.destroy(),this.attrs["show-extended-correspondents-list"])window.removeEventListener("resize",this.setMessageCorrespondentsAdaptiveDebounced)},onAttachmentClick:function(e){var t=this.get("model"),a=this.get("router"),r=this.get("route"),n=e.details;if(n.get("flags.eml")){var i=t.get("folder"),o=r.params.part?r.params.letter:"0:".concat(t.id,":").concat(i);(0,y.default)(a.getUrl("#read-letter",{folder:i,letter:o,part:n.id}))}else Ie.Z.open({attachment:n,message:t,router:a,newWindow:!0})},onAttachmentCloud:function(e){this.onAttachmentsCloud(yr(yr({},e),{details:[e.details]}))},onAttachmentsCloud:function(e){if(this.attrs["offline-mode"])return e.preventDefault(),!1;var t=this.get("model"),a=e.details.filter((function(e){return!e.isLink()&&(!e.isCloud()||h.ENABLE_CLONE_CLOUD_ATTACHMENTS)}));this.broadcast("attachments:tocloud",{message:t,attachments:a})},onLetterDataAttributeClick:function(e){var t,a=this,n=e.details,i=this.getOriginalEvent(e);switch(n.type){case h.LETTER_DATA_WHITE_LIST_NAME.shareFolderAccess:this.broadcast(Ee.r.letterActionClick,n,i);break;case h.LETTER_DATA_WHITE_LIST_NAME.mentions:if(!h.ENABLE_MENTIONS)break;e.target=e.target.closest("[data-mention]");var o=e.target.dataset.mentionEmail,s=e.target.dataset.mentionName,l=e;l.originalEvent=i,l.details.email=o,l.details.name=s,l.details.avatars={"50x50":(0,P.Q)(o,s,50),default:(0,P.Q)(o,s,90)},this.onContactShow(l);break;case h.LETTER_DATA_WHITE_LIST_NAME.replaceLetter:if(!h.ENABLE_REVOKE_LETTER)break;var d=e.target.dataset.replaceLetter;if(!d){Se.default.error({text:V.Du.COULD_NOT_FIND_REPLACEMENT_LETTER});break}ve().fetchData({id:d},!0).then((function(e){var t=new(ve())(e);if(t.get("flags.was_replaced"))(0,I.Ll)({id:R.H.letterReplaceError,data:{subject:t.get("subject")}});else a.broadcast("compose:replace",{model:new(ve())({id:d,replace_id:d})})})).catch((function(e){return console.error("Replaced message not found: ",e)}));break;case h.LETTER_DATA_WHITE_LIST_NAME.letterRevokeReport:if(!h.ENABLE_REVOKE_LETTER)break;var c=e.target.dataset.letterRevokeReport;if(!c){Se.default.error({text:V.Du.COULD_NOT_FIND_RECALLED_LETTER});break}(0,I.Ll)({id:R.H.revokeLetterReport,data:{messageId:c}});break;case h.LETTER_DATA_WHITE_LIST_NAME.dataCloudVktRedirect:if(h.IS_VK_TEAMS){var m=i.currentTarget.getAttribute(n.attrName);C.s.bridge().send(r.TeamsSendAction.OpenLink,{url:m}).catch((function(e){return console.error("VKTeamsBridge cloud redirect error: ",e)}))}else(0,y.default)(i.currentTarget.href);break;case h.LETTER_DATA_WHITE_LIST_NAME.vktMailRedirect:if(i.currentTarget.href)(0,y.default)(i.currentTarget.href);else Se.default.error({text:V.Du.COULD_NOT_FIND_RECALLED_LETTER});break;case h.LETTER_DATA_WHITE_LIST_NAME.sentSharedFolderMessageRedirect:var u=function(){var t=e.target.getAttribute("href");(0,y.default)(t)},f=x.default.getData(),p=f.folder,b=f.folders,g=null===(t=p.get("owner"))||void 0===t?void 0:t.email;if(!g){u();break}var v=b.find((function(e){var t;return e.isSent()&&(null===(t=e.get("owner"))||void 0===t?void 0:t.email)===g}));if(!v){u();break}var _=e.target.dataset.sentSharedFolderMessageRedirect,E=new URL(_);E.searchParams.set("folder_id",v.id.toString()),(0,y.default)(E)}},onVktIOSLinkClick:function(e){var t=this.getOriginalEvent(e).currentTarget.href;(0,y.default)(t)},onAllowedAttrClick:function(e){var t=e.details,a=this.getOriginalEvent(e),r=a.target.getAttribute("data-url");if(function(e){return h.SAFE_URL_LETTERS.test(e)}(r)){a.preventDefault(),a.stopImmediatePropagation();var n=t.skin;if(t.uidl){var i=this.get("model").id;r=(0,G.Z)(r,{uidl:i})}we.default.openIframeLayer({paramsKey:n,additionalParams:{url:r},factoryParams:{dimmer:!0,"close-on-esc":!0}})}},onToggleDetails:function(){this.set("details-expanded",!this.get("details-expanded"))},onToMyselfClick:function(){we.default.open("confirm-tomyself-enable",{},{compact:!0,dimmer:!0,resolvable:!0,"close-on-dimmer":!1,"close-on-esc":!1,"reject-on-close":!0}).then((function(){if(!i().get("to-myself").isActive())(0,H.default)({type:"TOGGLE_TO_MYSELF_METATHREAD",state:!0,uid:void 0}),(0,Le.ZP)("letter_myself_on")})).catch((function(e){if(e)throw(0,Le.ZP)("ltr_mslf_open_err_".concat(e)),e}))},onLetterComposeFromDraft:function(e){var t=e.type,a=e.details,r=t.split(":").pop(),n=a.model,i=a.draftId;this.broadcast("compose:draft",{model:new(ve())({id:i}),source:{id:n.get("id"),mode:r}})},onLetterRevoke:function(){var e=this.get("model"),t=e instanceof ye()?e.get("last"):e.get("id");(0,I.Ll)({id:R.H.revokeLetter,data:{messageId:t}})},onLetterReplace:function(e){var t=e.details.model,a=t instanceof ye()?t.get("last"):t.get("id");this.broadcast("compose:replace",{model:new(ve())({id:a,replace_id:a})})},onContactShow:function(e){e.details.type="correspondent",Te.Z.show(e,{mobile:this.get("mobile"),checkContactsProssessing:this.get("checkContactPossessing"),messageModel:this.get("model")})},onTranslatorClose:function(){this.broadcast("translator:close",{model:this.get("model"),block:this})},onTranslatorHide:function(){this.broadcast("translator:hide",{model:this.get("model"),block:this})},onTranslatorOriginal:function(e){var t=e.details;this.broadcast("letter:original",{options:t,model:this.get("model"),block:this})},onTranslatorTranslate:function(e){var t=e.details;this.broadcast("letter:translate",{options:t,model:this.get("model"),block:this})},onTooltipShowImagesClick:function(){var e=this.get("model");ve().fetchData({id:e.get("id"),folder_id:e.get("folder"),bulk_show_images:!0,remove_emoji_opts:(0,z.Yk)()},!0,!0).then((function(t){var a=e.getTranslationLast()||{},r=a.fromlang,n=a.tolang;if(r&&n)e.resetTranslation(r,n,"body.html");var i=t.body;e.setCachedBody(i),e.set(t)}))},onTooltipClose:function(){this.set("is-tooltip-visible",!1)},onVkMessengerOpen:function(e){var t=this,a=e.details;if(this._sendVkMessengerEvent("in_mail_toolbar_click_vk_messenger"),!h.VK_MESSENGER_EXTERNAL)Re.i.open({chatId:a,onShow:function(){t._sendVkMessengerEvent("in_mail_open_vk_messenger")},darkMode:this.is("dark-mode")});else(0,y.default)(a)},onCreateChat:function(){(0,m.P)({message:this.get("model")})},isShowCreateChat:function(){return h.SHOW_CREATE_CHAT},isShareTake:function(){return this.get("model").getFolder().isShareTake()},isLetterTranslated:function(){return this.is("is-letter-translated")},isTranslationLoading:function(){return this.is("is-translator-loading")},isTranslatorVisible:function(){if(this.attrs["offline-mode"])return!1;var e=this.get("model"),t=e.is("flags.in_english"),a=i().get("translator-hide").isActive(),r=this.get("is-translator-forced-shown"),n=L.Z.get("LANG");if(this.get("is-translator-visible"))return!0;if(h.ENABLE_HIDE_TRANSLATOR&&a)return!1;if(t&&!this.get("is-letter-in-english-radar-send"))l().send("letter_in_english",{dwh:{letterId:e.id,user_english:"en_US"===n}}),this.set("is-letter-in-english-radar-send",!0,!0);if(h.AUTOMATED_SHOW_TRANSLATOR&&!r&&!this.is("preview-mode")&&t&&"en_US"!==n){if(!this.get("is-automated-show-translator-radar-send"))l().send("letter_translator_show",{dwh:{letterId:e.id,automated_show:!0,in_english:t}}),this.set("is-automated-show-translator-radar-send",!0,!0);return!0}return!1},isTooltipVisible:function(){return!this.is("preview-mode")&&this.is("is-tooltip-visible")},isImagesHiddenTooltipVisible:function(){var e=this.get("model");return function(e){return!!e&&e.getFolder().isSpam()&&e.get("images.hidden")&&!e.getCachedBody()}(e)&&e.get("images.exists")},isUntrustedSenderForCorp:function(){var e=this.get("model"),t=e.getFolder(),a=e.attributes.flags;return h.TRUSTED_SENDER_FOR_CORP_NOTIFICATION&&!t.isSpam()&&!a.trusted_sender_for_corp},getAttachmentsDowloadLink:function(){var e=this.get("model"),t=e.getAttachmentsDowloadLink();if(!t&&1===e.get("attaches.list.length")){t=e.get("attaches.list.0").getDownloadUrl()}return t},getLetterBody:function(){var e=this.getLetterBodyTranslation(),t=this.get("model"),a=t.get("images"),r=t.getCachedBody();if(a.exists&&a.hidden&&r&&r.html)t.set("body.html",r.html);return e||t.get("body.html")||""},getLetterBodyKey:function(){var e=this.getLetterBodyTranslation(),t=this.get("model"),a=t.getTranslationLast()||{},r=a.fromlang,n=a.tolang,i=this.get("model").id,o=e?"".concat(r,":").concat(n):"",s=t.get("images.hidden")?1:0,l=this.isDarkMode()?1:0;return"".concat(i,"_").concat(o,"_").concat(l,"_").concat(s)},getLetterBodyTranslation:function(){var e=this.get("model"),t=e.getTranslationLast()||{},a=t.fromlang,r=t.tolang;if(!(this.isLetterTranslated()&&this.isTranslatorVisible()&&a&&r))return"";else return e.getTranslation(a,r,"body.html")},setMessageCorrespondentsAdaptive:function(){if(this.isMounted()){var e=(0,D.b5)({container:document.querySelector(".letter__recipients_short"),correspondents:this.get("model").get("correspondents"),currentUserEmail:this.attrs["current-user"]&&this.attrs["current-user"].getEmail(),isTouch:this.attrs.touch,texts:this.texts});this.set("recipientsData",e)}},getMessageCorrespondents:function(){var e=this.get("model").get("correspondents"),t=e.to,a=void 0===t?[]:t,r=e.cc,n=void 0===r?[]:r,i=e.bcc,o=void 0===i?[]:i;return[].concat.call([],a,n,o)},getCorrespondentDirection:function(e){return{from:"from",to:"to",cc:"to",bcc:"to"}[e]||null},isLetterIdEq:function(e){return e===this.get("model").id},saveNotes:function(e){var t=e.details,a=this.get("model").get("id");l().send("p_thread_letter_note_click",{dwh:{letter_id:a,letter_type:t.radarLetterType}}),(0,y.default)("".concat(h.NOTES_URL,"/create-note-from-letter/?letter-id=").concat(a,"&source=read_letter"))},updateStickyStatus:function(e){var t=e.element,a=e.disableSticky,r=e.position,n=e.fade;this.stickyDisabled=a,this.updateSticky(t,r,n)},updateSticky:function(e,t,a,r){var n,i;if(void 0===r)r=!1;var o=this.get("sticky-position");if(null!=o){var s=o.width,l=kr[e],d=l.offsetSide,c=l.offsetPadding,m=l.className,u=this.el.getElementsByClassName(m)[0];if(u){var f=u.getBoundingClientRect().height;if(void 0!==t&&!this.stickyDisabled){if(s)u.style.width=s+"px",u.style.left="",u.style.right="";else u.style.width="";if(!h.IS_READLETTER_NATIVE_STICKY_DISABLED)this.set("sticky-".concat(e),!0),u.style[d]="0px";else u.style[d]=t+"px",this.el.style[c]=f+"px",this.set(((n={})["sticky-".concat(e)]=!0,n["sticky-".concat(e,"-fade")]=a,n)),r?this._startStickyTracking(u,m,o):this._stopStickyTracking(m)}else u.style[d]="",u.style.left="",u.style.right="",u.style.width="",this.el.style[c]="",this.set(((i={})["sticky-".concat(e)]=!1,i["sticky-".concat(e,"-fade")]=!1,i),!1)}}},_startStickyTracking:function(e,t,a){if(this._windowResizeListeners[t])this._stopStickyTracking(t);var r=function(){if(window.innerWidth>a.maxWidth+a.left+a.right)e.style.left="",e.style.right="",e.style.width="".concat(a.maxWidth,"px");else e.style.width=""};window.addEventListener("resize",r),this._windowResizeListeners[t]=r,r()},_stopStickyTracking:function(e){var t=this._windowResizeListeners[e];if(t)delete this._windowResizeListeners[e],window.removeEventListener("resize",t)},_showHeadShareButton:function(){var e=this.get("model"),t=this.get("parentThread"),a=t?t.get("last")===(null==e?void 0:e.get("id")):!0,r=(0,J.Z)(e);return this.is("share-letter")&&!this.isProbablyPhishing()&&r&&a},_getHeadShareIcon:function(){return h.LETTER_SHARING_HEAD_ICON_V2?"share:external_outline":"status:link"},_showSaveNotesButton:function(){var e=this._showUnsubscribeButton(),t=this.get("model").get("correspondents.from.0"),a=ke.default.user.getEmail()===t.email;if(this.is("enable-notes-button")&&(e||a)||this.is("default-enable-save-note-button")){var r=e?"mailings":a?"letters_to_myself":"default";l().send("p_thread_letter_note_show",{dwh:{letter_type:r}})}},_showDropdownCalendarButton:function(){var e=this._showUnsubscribeButton()&&this.is("disable-calendar-newsletters");return!this.is("disable-create-event")&&!e},_showReportSuspiciousEmail:function(){return h.REPORT_SUSPICIOUS_EMAIL},_showHeadCalendarButton:function(){var e=this._showUnsubscribeButton()&&this.is("disable-calendar-newsletters");return!this.is("disable-create-event")&&!this.is("disable-head-calendar")&&!e},_showUnsubscribeButton:function(){if(this.get("mobile"))return!1;var e=this.get("model");if(e.getFolder().isSpam())return!1;else return this.is("feature-unsubscribe")&&e.get("flags.newsletter")},_showVkMessengerButton:function(){var e=this.get("transaction-metadata");if(!e)return!1;if(!e.get("vk_chat_href"))return!1;else return!0},_getVkMessengerParams:function(){var e=this.get("transaction-metadata"),t=null==e?void 0:e.get("vk_chat_href"),a=null==e?void 0:e.get("vk_chat_id"),r=null==e?void 0:e.get("shop_name");return{href:h.VK_MESSENGER_EXTERNAL?t:a,text:r?i18n("Чат с {shopName}",{shopName:r}):i18n("Чат в VK")}},_sendVkMessengerEvent:function(e){if(this._showVkMessengerButton()){var t=this.get("model"),a=this.get("transaction-metadata"),r={is_order:t.get("transaction_category")===o.CategoryTypes.ORDER,letter_id:t.get("id"),partner_email:t.get("correspondents.from.0.email"),partner_name:a.get("shop_name")};if("open_mail_with_vk_messenger"!==e)r.destination=h.VK_MESSENGER_EXTERNAL?"outside":"inside";if("in_mail_open_vk_messenger"===e)r.from="toolbar";l().send(e,{dwh:r})}},_showFilterButton:function(){return!h.FORBID_FILTERS},_showSpam:function(){var e=this.get("model").getFolder();return!h.FORBID_SPAM&&!e.isSpam()},_showUnsubscribeInMoreMenu:function(){var e=this.get("model"),t=e.is("flags.newsletter")&&e.is("flags.show_definitely_spam")&&e.is("flags.have_unsubscribe_list");return h.UNSUBSCRIBE_IN_MORE_DROPDOWN&&t},_stopPropagationDuringOffline:function(e){if(this.attrs["offline-mode"])return e.preventDefault(),e.stopImmediatePropagation(),!1},hasReplyAll:function(e){return(0,W.gA)(e)},isAMPLetter:function(){var e=this.get("model");return h.ENABLE_AMP&&!this.is("amp-error")&&e.get("body.amp")},isAMPLetterWithoutTheme:function(){return this.isAMPLetter()&&!this.is("isThemedAMP")},isDarkMode:function(){return this.isDarkModePossible()&&this.is("dark-mode-enabled")},isDarkModePossible:function(){return!this.isAMPLetterWithoutTheme()&&this.is("dark-mode")},onAmpError:function(){this.set("amp-error",!0)},setCssSelectorThemeAMP:function(e){var t=e.details;this.set("isThemedAMP",t)},onDarkModeToggle:function(){this.radar(["turn-on",this.is("dark-mode-enabled")?"light-mode":"dark-mode"]),this.invert("dark-mode-enabled")},isProbablyPhishing:function(){var e=this.get("model");return h.PHISHING_ALERT&&e.get("flags.maybe_phishing")},checkFolderGrant:function(e){return this.get("model").checkGrant(e)},isEnableReply:function(){if(this.attrs["disable-edit"])return!1;else return this.checkFolderGrant(pe().SHARE_GRANTS.reply)},isFooterControlsSingleLine:function(){return h.LETTER_SMART_REPLIES_SINGLE_LINE},isShowStickyByLetterContext:function(){return h.LETTER_CONTEXT_STICKY&&this.hasUnsubscribeButton()},isShowSmartReplyAndMarusia:function(){var e,t;if(this.isShowStickyByLetterContext())return!1;if(!h.HIDE_MESSAGE_SMART_REPLY&&!h.HIDE_MESSAGE_SMART_REPLY_BY_ONLY_WIDTH)return!0;var a=this.reactComponent?null===(t=null===(e=this.letterBody)||void 0===e?void 0:e.current)||void 0===t?void 0:t.el:this.refs["letter-body"],r=window.innerHeight,n=null==a?void 0:a.clientWidth,i=this.isSmartReplyHiddenRadarSended,o=!1,s="";if(h.HIDE_MESSAGE_SMART_REPLY_BY_ONLY_WIDTH)o=n<650||!n,s="_width";if(h.HIDE_MESSAGE_SMART_REPLY)o=r<800&&n<650||!n;if(o&&!i)l().send("letter_hide_smart-reply".concat(s)),this.isSmartReplyHiddenRadarSended=!0;return!o},isShowFooter:function(){var e,t;if(h.DISABLE_LETTER_FOOTER)return!1;if(!h.HIDE_MESSAGE_FOOTER)return!0;var a=this.reactComponent?null===(t=null===(e=this.letterBody)||void 0===e?void 0:e.current)||void 0===t?void 0:t.el:this.refs["letter-body"],r=window.innerHeight,n=null==a?void 0:a.clientWidth,i=this.isFooterHiddenRadarSended,o=r<800&&n<650||!n;if(o&&!i)l().send("letter_hide_footer"),this.isFooterHiddenRadarSended=!0;return!o},isEnableCall:function(){if(this.attrs["disable-edit"])return!1;if(this.attrs["offline-mode"])return!1;else return this.checkFolderGrant(pe().SHARE_GRANTS.reply)},isEnablePrint:function(){if(this.attrs["offline-mode"])return!1;else return this.isEverySelectedFoldersMine()},isEnableShare:function(){if(this.attrs["disable-edit"])return!1;if(this.attrs["offline-mode"])return!1;else return this.checkFolderGrant(pe().SHARE_GRANTS.forward)&&this.checkFolderGrant(pe().SHARE_GRANTS.reply)},isEnableForward:function(){if(this.attrs["disable-edit"])return!1;else return this.checkFolderGrant(pe().SHARE_GRANTS.forward)},isEnableMark:function(){if(this.attrs["disable-edit"])return!1;else return this.checkFolderGrant(pe().SHARE_GRANTS.mark_as_important)},isEnableAttach:function(){return this.checkFolderGrant(pe().SHARE_GRANTS.view_attachment)},isDatesMetadataEnabled:function(){var e=this.get("dates-metadata");return h.DATES_METADATA&&e},isEnableConfirmationReceipt:function(){var e=this.get("model"),t=e.is("flags.receipt"),a=this.is("preview-mode"),r=!e.getFolder().isShareTake();return Boolean(!a&&t&&r)},getUpmetricCreativeFromMetadata:function(){var e,t=this.get("model");return null===(e=null==t?void 0:t.get("meta"))||void 0===e?void 0:e.find((function(e){return e&&"object"==typeof e&&"Upmetric"===e["@context"]&&"Creative"===e["@type"]}))},isEnableUpmetricPromo:function(){var e=this;if(!h.UPMETRIC_PROMO)return!1;var t=this.getUpmetricCreativeFromMetadata();if(!t)return!1;var a=this.get("model"),r=null==a?void 0:a.get("id"),n=this.get("mobile"),i=function(){if(!e.isUpmetricPromoParseErrorRadarSended)l().send("upmetric_lb_banner_parse_error",{dwh:{letter_id:r,banner_id:t.creativeId,banner_meta:t}}),e.isUpmetricPromoParseErrorRadarSended=!0};if(!t.creativeId||!function(e,t){return t&&e&&Object.entries(e).length>0&&Object.keys(e).every((function(e){return"string"==typeof e&&e.length>0}))&&Object.values(e).every((function(e){return"string"==typeof e&&e.length>0}))}(n?t.bannerMobile:t.bannerWeb,n?t.linkMobile:t.linkWeb))return i(),!1;if(!this.getUpmetricPromoBannerSize(r,t.creativeId,t.bannerMobile,t.bannerWeb,null===h.UPMETRIC_PROMO_SIZE||void 0===h.UPMETRIC_PROMO_SIZE?void 0:h.UPMETRIC_PROMO_SIZE.mobile,null===h.UPMETRIC_PROMO_SIZE||void 0===h.UPMETRIC_PROMO_SIZE?void 0:h.UPMETRIC_PROMO_SIZE.desktop,n,!1))return i(),!1;if(t.activeBefore){var o=new Date(Date.parse(t.activeBefore)),s=!(0,B.zk)(o)&&new Date>o;if(s&&!this.isUpmetricPromoDeadlineErrorRadarSended)l().send("upmetric_lb_banner_deadline",{dwh:{letter_id:r,banner_id:t.creativeId,deadline:t.activeBefore}}),this.isUpmetricPromoDeadlineErrorRadarSended=!0;return!s}return!0},getUpmetricPromoBannerSize:function(e,t,a,r,n,i,o,s){var d,c=o?n:i,m=o?a:r;if(!m||"object"!=typeof m||!Object.entries(m).length)return null;try{var u=void 0,h=void 0;if(c)u=m[h=c];if(!u)if(h=(d=Object.entries(m)[0])[0],u=d[1],c&&s)l().send("upmetric_lb_not_exp_img_showed",{dwh:{showed_image:h,expected_image:c,letter_id:e,banner_id:t}});var f=h.split("x"),p=parseInt(f[0]),b=parseInt(f[1]);if(!p||!b)return null;else return{url:u,size:{width:p,height:b}}}catch(e){return null}},getUpmetricPromoData:function(){var e;if(!this.isEnableUpmetricPromo())return null;var t=this.getUpmetricCreativeFromMetadata(),a=null===(e=this.get("model"))||void 0===e?void 0:e.get("id"),r=this.get("mobile");return{letterId:a,banner:yr({id:t.creativeId,link:r?t.linkMobile:t.linkWeb},this.getUpmetricPromoBannerSize(a,t.creativeId,t.bannerMobile,t.bannerWeb,null===h.UPMETRIC_PROMO_SIZE||void 0===h.UPMETRIC_PROMO_SIZE?void 0:h.UPMETRIC_PROMO_SIZE.mobile,null===h.UPMETRIC_PROMO_SIZE||void 0===h.UPMETRIC_PROMO_SIZE?void 0:h.UPMETRIC_PROMO_SIZE.desktop,r,!0)),ordInfo:t.ordInfo,pixelUrl:t.actionPixel}},isSmartRepliesAvailable:function(e){return this.is("smart-reply-on")&&e.is("flags.smart_reply")&&!this.is("readonly")&&!(0,j.s9)()},isMarusiaReadLetterEnabled:function(){var e,t=this.get("model");return h.MARUSIA_READ_LETTER&&!(null===(e=t.getFolder())||void 0===e?void 0:e.isSecure())&&this.isSmartRepliesAvailable(t)},getMarusiaReadLetterRadarPrefix:function(){return h.MARUSIA_READ_ALL_LETTERS?"all":"smart"},hasCloudStockAttach:function(){var e;return!!(null!==(e=this.get("model").getAttachmentsList())&&void 0!==e?e:[]).find((function(e){return e.isCloudStock()}))},getLetterMetaHeaderType:function(e){if(e.get("flags.maybe_phishing"))return"phishing";if(h.EXPIRED_ATTACHES_DIE&&this.hasCloudStockAttach())return"expired_attaches";else return null},isShowFakeCreateTodo:function(){if(!h.FAKE_CREATE_TODO)return!1;else return!xe.ZP.get("create_todo_fake_button_shown")},isAllExtensionsInWhiteList:function(e){return e.every((function(e){var t,a,r=(t=e.attributes.name,a=t.lastIndexOf(".")+1||t.length,t.slice(a).toLowerCase());return r&&h.EXTENSIONS_WHITE_LIST.includes(r)}))},isEveryStrictlyUnsafe:function(e){return e.map((function(e){return e.attributes.flags.unsafe})).every((function(e){return e}))},isAllScanResolutionsOf:function(e,t){return e.map((function(e){return e.attributes.scan})).every((function(e){return e===t}))},isAllTypesOf:function(e,t){return e.map((function(e){return e.attributes.type})).every((function(e){return t.includes(e)}))},getAttachSafetyStatus:function(){var e=this.get("model").attributes.attaches.list;if(!this.isEveryStrictlyUnsafe(e)&&this.isAllScanResolutionsOf(e,"healthy")&&this.isAllExtensionsInWhiteList(e)){if(this.isAllTypesOf(e,["cloud","cloud_stock"]))return l().send("attaches-status_view",{dwh:{status:"healthy"}}),"healthy";if(this.isAllTypesOf(e,["attach","cloud","cloud_stock"]))return l().send("attaches-status_view",{dwh:{status:"probablyHealthy"}}),"probablyHealthy"}return null},hasSmartCardIcsMeta:function(e){return!!(0,be.getCalendarIcsEvent)(e)},hasUnsubscribeButton:function(){return!(!this._showUnsubscribeButton()||this.isDatesMetadataEnabled())},isRevokeEnabled:function(){if(!h.ENABLE_REVOKE_LETTER)return!1;else return this.get("model").get("folder")===pe().SENT},isEverySelectedFoldersMine:function(){return this.getCurrentFoldersIds().every((function(e){return!pe().all.get(e).isShareTake()}))},useSharingDropdown:function(){return h.LETTER_SHARING_DROPDOWN},useReactMigrLetterBody:function(){return h.REACT_MIGR_LETTER_BODY},remitEvents:{LetterBody:{"data-attr-click":"letter:body:data-attr:click",resize:"resize",blockquote:"blockquote",allowedattrclick:"letter:body:allowedattrclick",tomyselfclick:"letter:body:tomyself","force-recalc":"letter-force-recalc",vktioslinkclick:"letter:body:vktioslinkclick"}},broadcastFromReact:function(e){var t=this.events[Object.keys(this.events).find((function(t){return(0,gr.Co)(t)===e.type}))||e.type];if(t)this[t](e);this.broadcast(e.type,e.details,e.originalEvent)}},Ar=O().Block.extend((0,Ce.Z)({explicit:"radar",events:[{name:"mount",data:Q.tA},{name:"unmount",data:Q.tA},{name:"compose:reply",data:Q.tA},{name:"compose:replyall",data:Q.tA},{name:"compose:forward",data:Q.tA},{name:"compose:smartreply",data:Q.tA},{name:"togglestatus:unread",rename:function(e){return(0,Q.aS)(e,"unread")}},{name:"togglestatus:flagged",rename:function(e){return(0,Q.aS)(e,"flagged")}}]})(Sr))},52950:function(e,t,a){"use strict";a.d(t,{u:function(){return _}});var r=a(39043),n=a(17717),i=a.n(n),o=a(60033),s=a.n(o),l=a(4815),d=a(18440),c=a.n(d),m=a(6073),u=a.n(m),h=a(33440),f=a(93286),p=a(84033),b=a(45114),g=a(12199),v=function(){return v=Object.assign||function(e){for(var t,a=1,r=arguments.length;a<r;a++)for(var n in t=arguments[a])if(Object.prototype.hasOwnProperty.call(t,n))e[n]=t[n];return e},v.apply(this,arguments)},_={name:"marusia-read-letter-button",rootClassName:"marusia-rl-button",template:u(),blocks:{button2:b.Z,ico:g.Z},events:{"marusia:rl:button:click":"onClick"},didMount:function(){if(this.isMounted())this.radarSend("show")},onClick:function(e){var t=e.details.model;if(e.originalEvent.stopImmediatePropagation(),l.MAIL_BIRTHDAY_2023_MISSIONS){var a=i().get("mail-birthday-2023");r.ZP.configure({mailapiRpc:p.O});var n=new r.ZP({helperIndex:a.index,initialHelpers:[{index:a.index,time:a.time,state:a.state,count:v({},a.count)}]}),o=r.q7.readMarusia,d="close";n.checkBit(o,d).then((function(e){if(!e)n.isActive().then((function(e){if(s().send("mail-brthd-23-".concat(e?"on":"off"),{i:"".concat(o)}),e)n.setBit(o,d).then((function(){s().send("mail-brthd-23-complete",{i:"".concat(o)})}))}))}))}this.broadcast("marusia:read:letter:click",{model:t}),this.radarSend("click",t)},radarSend:function(e,t){if(void 0===t)t=this.get("model");var a=(0,h.getCategoriesFromMeta)(t);(0,f.ZP)({type:"marusia-rl-".concat(e,"_").concat(this.get("radar-prefix")),dwh:{categories:a||[]}})},getLogoSrc:function(){return"".concat(l.PACKAGES_URL,"/static.promo/marusia/marusia-shadow.png")}};t.Z=c().Block.extend(_)}}]);